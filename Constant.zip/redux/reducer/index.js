// redux/reducer/index.js
import { combineReducers } from 'redux';
import authReducer from '../slice/authSlice';
import vendorReducer from '../slice/Vendor';
import analyticsReducer from '../slice/analyticsSlice';
import bookingHistoryReducer from '../slice/BookingHistory';


const rootReducer = combineReducers({
  auth: authReducer,
  vendor: vendorReducer,
  analytics: analyticsReducer,
  bookingHistory: bookingHistoryReducer,
});

export default rootReducer;