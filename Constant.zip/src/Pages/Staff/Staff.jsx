// import { useState, useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   Button, IconButton, Tooltip, Dialog, DialogTitle,
//   DialogContent, DialogContentText, DialogActions,
//   Chip, Avatar, TextField, InputAdornment, CircularProgress,
//   Alert, Snackbar,
// } from "@mui/material";
// import {
//   Add, Search, Visibility, Edit, Delete, People, Close,
//   WarningAmberRounded, ViewModule, ViewList,
//   Phone, Lock, Person, VisibilityOff,
// } from "@mui/icons-material";

// // Redux actions and selectors
// import {
//   getAllWorkers,
//   addWorker,
//   updateWorker,
//   deleteWorker,
//   getWorkerByMobile,
//   selectAllWorkers,
//   selectWorkersLoading,
//   selectWorkersError,
//   selectAddWorkerLoading,
//   selectUpdateWorkerLoading,
//   selectDeleteWorkerLoading,
//   selectCurrentWorker,
//   selectWorkerLoading,
//   selectSuccessMessage,
//   clearWorkersError,
//   clearSuccessMessage,
//   clearCurrentWorker,
// } from "../../../redux/slice/Vendor";

// const statusColors = {
//   Active:    { bg: "#d4edda", color: "#1e7e34" },
//   "On Leave":{ bg: "#fff3cd", color: "#d39e00" },
//   Inactive:  { bg: "#f8d7da", color: "#bd2130" },
// };

// const avatarBgMap = {
//   "Human Resources": "#b3d1f0",
//   Engineering:       "#a5d6a7",
//   Design:            "#f48fb1",
//   Finance:           "#ffe082",
//   Marketing:         "#ce93d8",
//   General:           "#b0bec5",
// };

// const emptyForm = { name: "", mobile: "", password: "" };

// function getInitials(name) {
//   return name.trim().split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
// }

// // ── Shared Form Fields ─────────────────────────────────────────
// function StaffFormFields({ form, setForm, errors, setErrors, showPass, setShowPass, loading }) {
//   const handle = (field) => (e) => {
//     setForm((prev) => ({ ...prev, [field]: e.target.value }));
//     setErrors((prev) => ({ ...prev, [field]: "" }));
//   };
//   const sx = { mb: "18px", "& .MuiOutlinedInput-root": { borderRadius: "10px" } };
//   return (
//     <div>
//       <TextField 
//         fullWidth 
//         label="Full Name" 
//         value={form.name} 
//         onChange={handle("name")}
//         error={!!errors.name} 
//         helperText={errors.name} 
//         disabled={loading}
//         sx={sx}
//         InputProps={{
//           startAdornment: <InputAdornment position="start"><Person style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment>
//         }} 
//       />
//       <TextField 
//         fullWidth 
//         label="Mobile Number" 
//         value={form.mobile} 
//         onChange={handle("mobile")}
//         error={!!errors.mobile} 
//         helperText={errors.mobile} 
//         placeholder="10-digit number" 
//         disabled={loading}
//         sx={sx}
//         InputProps={{
//           startAdornment: <InputAdornment position="start"><Phone style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment>
//         }} 
//       />
//       <TextField 
//         fullWidth 
//         label="Password" 
//         type={showPass ? "text" : "password"} 
//         value={form.password}
//         onChange={handle("password")} 
//         error={!!errors.password} 
//         helperText={errors.password} 
//         disabled={loading}
//         sx={{ mb: 0, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}
//         InputProps={{
//           startAdornment: <InputAdornment position="start"><Lock style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment>,
//           endAdornment: (
//             <InputAdornment position="end">
//               <IconButton size="small" onClick={() => setShowPass((v) => !v)} edge="end" disabled={loading}>
//                 {showPass ? <VisibilityOff style={{ fontSize: 18 }} /> : <Visibility style={{ fontSize: 18 }} />}
//               </IconButton>
//             </InputAdornment>
//           ),
//         }} 
//       />
//     </div>
//   );
// }

// // ── Main Component ─────────────────────────────────────────────
// export default function StaffPage() {
//   const dispatch = useDispatch();
  
//   // Redux state
//   const workers = useSelector(selectAllWorkers);
//   const loading = useSelector(selectWorkersLoading);
//   const addLoading = useSelector(selectAddWorkerLoading);
//   const updateLoading = useSelector(selectUpdateWorkerLoading);
//   const deleteLoading = useSelector(selectDeleteWorkerLoading);
//   const workerLoading = useSelector(selectWorkerLoading);
//   const error = useSelector(selectWorkersError);
//   const currentWorker = useSelector(selectCurrentWorker);
//   const successMessage = useSelector(selectSuccessMessage);

//   // Local state
//   const [search, setSearch] = useState("");
//   const [viewMode, setViewMode] = useState("list");
//   const [deleteTarget, setDeleteTarget] = useState(null);
//   const [viewTarget, setViewTarget] = useState(null);
//   const [addOpen, setAddOpen] = useState(false);
//   const [editTarget, setEditTarget] = useState(null);
//   const [form, setForm] = useState(emptyForm);
//   const [showPass, setShowPass] = useState(false);
//   const [errors, setErrors] = useState({});
//   const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

//   // Fetch workers on component mount
//   useEffect(() => {
//     dispatch(getAllWorkers());
//     console.log(getAllWorkers());
    
//   }, [dispatch]);

//   // Handle success messages
//   useEffect(() => {
//     if (successMessage) {
//       setSnackbar({ open: true, message: successMessage, severity: 'success' });
//       dispatch(clearSuccessMessage());
//     }
//   }, [successMessage, dispatch]);

//   // Handle errors
//   useEffect(() => {
//     if (error) {
//       setSnackbar({ open: true, message: error, severity: 'error' });
//       dispatch(clearWorkersError());
//     }
//   }, [error, dispatch]);

//   // Filter workers based on search
//   const filtered = workers.filter(
//     (s) =>
//       s.name?.toLowerCase().includes(search.toLowerCase()) ||
//       s.mobile?.includes(search)
//   );

//   const validate = (f) => {
//     const e = {};
//     if (!f.name?.trim()) e.name = "Name is required";
//     if (!f.mobile?.trim()) e.mobile = "Mobile is required";
//     else if (!/^\d{10}$/.test(f.mobile.replace(/\s/g, ""))) e.mobile = "Enter valid 10-digit number";
//     if (!f.password?.trim() && !editTarget) e.password = "Password is required";
//     else if (f.password?.trim() && f.password.length < 6) e.password = "Minimum 6 characters";
//     return e;
//   };

//   const handleAdd = async () => {
//     const e = validate(form);
//     if (Object.keys(e).length) { setErrors(e); return; }
    
//     const result = await dispatch(addWorker({
//       name: form.name.trim(),
//       mobile: parseInt(form.mobile.replace(/\s/g, "")),
//       password: form.password,
//       isActive: true
//     }));
    
//     if (!result.error) {
//       setAddOpen(false);
//       setForm(emptyForm);
//       setErrors({});
//       setShowPass(false);
//     }
//   };

//   const handleEditOpen = (member) => { 
//     setEditTarget(member); 
//     setForm({ 
//       name: member.name, 
//       mobile: member.mobile.toString(), 
//       password: "" 
//     }); 
//     setErrors({}); 
//     setShowPass(false); 
//   };

//   const handleEditSave = async () => {
//     const e = validate(form);
//     if (Object.keys(e).length) { setErrors(e); return; }
    
//     const workerData = {
//       name: form.name.trim(),
//       mobile: parseInt(form.mobile.replace(/\s/g, "")),
//       ...(form.password.trim() && { password: form.password }),
//     };
    
//     const result = await dispatch(updateWorker({ 
//       workerId: editTarget._id, 
//       workerData 
//     }));
    
//     if (!result.error) {
//       setEditTarget(null);
//       setForm(emptyForm);
//       setErrors({});
//       setShowPass(false);
//     }
//   };

//   const handleDelete = async () => {
//     const result = await dispatch(deleteWorker(deleteTarget._id));
//     if (!result.error) {
//       setDeleteTarget(null);
//     }
//   };

//   const handleView = async (member) => {
//     setViewTarget(member);
//     // Optional: Fetch fresh data if needed
//     // await dispatch(getWorkerByMobile(member.mobile));
//   };

//   const closeAdd = () => { 
//     setAddOpen(false); 
//     setForm(emptyForm); 
//     setErrors({}); 
//     setShowPass(false); 
//   };

//   const closeEdit = () => { 
//     setEditTarget(null); 
//     setForm(emptyForm); 
//     setErrors({}); 
//     setShowPass(false); 
//   };

//   // ── Dialog Paper style ──
//   const paperRound = { borderRadius: "18px", width: "100%", maxWidth: 440, padding: "4px" };

//   if (loading && !workers.length) {
//     return (
//       <div className="min-h-screen flex items-center justify-center" style={{ background: "#f8f9fa" }}>
//         <CircularProgress />
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen" style={{ background: "#f8f9fa", fontFamily: "'Inter', system-ui, sans-serif" }}>
//       <div className="max-w-7xl mx-auto px-6 py-8">

//         {/* ── Header ── */}
//         <div className="flex items-center justify-between mb-8">
//           <div className="flex items-center gap-3">
//             <div className="flex items-center justify-center rounded-xl"
//               style={{ width: 44, height: 44, background: "#0066cc", boxShadow: "0 4px 12px rgba(0,102,204,0.3)" }}>
//               <People style={{ color: "#fff", fontSize: 22 }} />
//             </div>
//             <div>
//               <h1 style={{ fontFamily: "'Poppins', sans-serif", fontSize: "1.75rem", fontWeight: 700, color: "#212121", letterSpacing: "-0.025em", lineHeight: 1.2, margin: 0 }}>
//                 Staff Management
//               </h1>
//               <p style={{ fontSize: "0.875rem", color: "#757575", margin: 0 }}>{workers.length} total members</p>
//             </div>
//           </div>
//           <Button 
//             variant="contained" 
//             startIcon={<Add />}
//             onClick={() => { setAddOpen(true); setForm(emptyForm); setErrors({}); }}
//             disabled={addLoading}
//             style={{ 
//               background: "#0066cc", 
//               color: "#fff", 
//               fontFamily: "'Poppins', sans-serif", 
//               fontWeight: 600, 
//               fontSize: "0.875rem", 
//               padding: "10px 22px", 
//               borderRadius: "10px", 
//               textTransform: "none", 
//               boxShadow: "0 4px 14px rgba(0,102,204,0.35)" 
//             }}>
//             {addLoading ? <CircularProgress size={20} color="inherit" /> : "Add Staff"}
//           </Button>
//         </div>

//         {/* ── Search + Toggle ── */}
//         <div className="flex items-center gap-3 mb-6">
//           <div className="flex items-center gap-3 flex-1"
//             style={{ background: "#fff", border: "1.5px solid #e0e0e0", borderRadius: "12px", padding: "10px 16px", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
//             <Search style={{ color: "#9e9e9e", fontSize: 20 }} />
//             <input 
//               type="text" 
//               placeholder="Search by name or mobile..." 
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               style={{ 
//                 border: "none", 
//                 outline: "none", 
//                 flex: 1, 
//                 fontSize: "0.9375rem", 
//                 color: "#212121", 
//                 background: "transparent", 
//                 fontFamily: "'Inter', system-ui, sans-serif" 
//               }} />
//             {search && <IconButton size="small" onClick={() => setSearch("")} style={{ padding: 4 }}><Close style={{ fontSize: 16, color: "#9e9e9e" }} /></IconButton>}
//           </div>

//           {/* View Toggle */}
//           <div style={{ display: "flex", background: "#fff", border: "1.5px solid #e0e0e0", borderRadius: "10px", overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
//             {[{ mode: "list", Icon: ViewList, tip: "List View" }, { mode: "card", Icon: ViewModule, tip: "Card View" }].map(({ mode, Icon, tip }) => (
//               <Tooltip key={mode} title={tip} arrow>
//                 <button 
//                   onClick={() => setViewMode(mode)}
//                   style={{ 
//                     padding: "9px 14px", 
//                     border: "none", 
//                     cursor: "pointer", 
//                     background: viewMode === mode ? "#0066cc" : "transparent", 
//                     color: viewMode === mode ? "#fff" : "#9e9e9e", 
//                     transition: "all 0.2s", 
//                     display: "flex", 
//                     alignItems: "center" 
//                   }}>
//                   <Icon style={{ fontSize: 20 }} />
//                 </button>
//               </Tooltip>
//             ))}
//           </div>
//         </div>

//         {search && <p style={{ fontSize: "0.8125rem", color: "#757575", marginBottom: "1rem" }}>Showing {filtered.length} result{filtered.length !== 1 ? "s" : ""} for &ldquo;{search}&rdquo;</p>}

//         {/* ══ LIST VIEW ══ */}
//         {viewMode === "list" && (
//           <div style={{ borderRadius: "14px", overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.08)", background: "#fff" }}>
//             <div style={{ display: "grid", gridTemplateColumns: "2.5fr 1.5fr 120px", padding: "13px 24px", background: "#f5f7fa", borderBottom: "1px solid #e0e0e0" }}>
//               {["Staff Member", "Mobile", "Actions"].map((h) => (
//                 <span key={h} style={{ fontSize: "0.75rem", fontWeight: 600, color: "#757575", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'Poppins', sans-serif" }}>{h}</span>
//               ))}
//             </div>
//             {filtered.length === 0 ? (
//               <EmptyState />
//             ) : (
//               filtered.map((member, idx) => (
//                 <div key={member._id}
//                   style={{ display: "grid", gridTemplateColumns: "2.5fr 1.5fr 120px", padding: "14px 24px", borderBottom: idx < filtered.length - 1 ? "1px solid #f0f0f0" : "none", alignItems: "center", transition: "background 0.15s" }}
//                   onMouseOver={(e) => (e.currentTarget.style.background = "#fafbff")}
//                   onMouseOut={(e) => (e.currentTarget.style.background = "transparent")}>
//                   <div className="flex items-center gap-3">
//                     <MemberAvatar member={member} size={38} />
//                     <p style={{ margin: 0, fontSize: "0.9375rem", fontWeight: 600, color: "#212121" }}>{member.name}</p>
//                   </div>
//                   <div className="flex items-center gap-2">
//                     <Phone style={{ fontSize: 14, color: "#9e9e9e" }} />
//                     <span style={{ fontSize: "0.875rem", color: "#616161" }}>{member.mobile}</span>
//                   </div>
//                   <ActionBtns 
//                     member={member} 
//                     onView={() => handleView(member)} 
//                     onEdit={() => handleEditOpen(member)} 
//                     onDelete={() => setDeleteTarget(member)} 
//                     size={32} 
//                     iconSize={15} 
//                     loading={deleteLoading && deleteTarget?._id === member._id}
//                   />
//                 </div>
//               ))
//             )}
//           </div>
//         )}

//         {/* ══ CARD VIEW ══ */}
//         {viewMode === "card" && (
//           filtered.length === 0 ? <EmptyState /> : (
//             <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(210px, 1fr))", gap: "16px" }}>
//               {filtered.map((member) => (
//                 <div key={member._id}
//                   style={{ background: "#fff", borderRadius: "16px", overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,0.08)", transition: "transform 0.18s, box-shadow 0.18s" }}
//                   onMouseOver={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.12)"; }}
//                   onMouseOut={(e)  => { e.currentTarget.style.transform = "translateY(0)";    e.currentTarget.style.boxShadow = "0 1px 4px rgba(0,0,0,0.08)"; }}>
//                   <div style={{ background: member.isActive ? "#d4edda" : "#f8d7da", padding: "24px 0 16px", display: "flex", flexDirection: "column", alignItems: "center" }}>
//                     <MemberAvatar member={member} size={60} fontSize="1.1rem" bgOverride="#fff" colorOverride="#0066cc" shadow />
//                     <p style={{ margin: "10px 0 0", fontWeight: 700, fontSize: "0.9375rem", color: "#212121", fontFamily: "'Poppins', sans-serif", textAlign: "center", padding: "0 12px" }}>{member.name}</p>
//                   </div>
//                   <div style={{ padding: "14px 16px" }}>
//                     <div className="flex items-center gap-2 mb-3">
//                       <Phone style={{ fontSize: 13, color: "#9e9e9e" }} />
//                       <span style={{ fontSize: "0.8125rem", color: "#616161" }}>{member.mobile}</span>
//                     </div>
//                     <div className="flex items-center justify-between">
//                       <Chip 
//                         label={member.isActive ? "Active" : "Inactive"} 
//                         size="small"
//                         style={{ 
//                           background: member.isActive ? "#d4edda" : "#f8d7da", 
//                           color: member.isActive ? "#1e7e34" : "#bd2130", 
//                           fontWeight: 600, 
//                           fontSize: "0.7rem", 
//                           height: 22 
//                         }} />
//                       <ActionBtns 
//                         member={member} 
//                         onView={() => handleView(member)} 
//                         onEdit={() => handleEditOpen(member)} 
//                         onDelete={() => setDeleteTarget(member)} 
//                         size={28} 
//                         iconSize={13} 
//                         gap={4} 
//                         borderRadius="6px"
//                         loading={deleteLoading && deleteTarget?._id === member._id}
//                       />
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           )
//         )}

//         <p style={{ textAlign: "right", fontSize: "0.8125rem", color: "#9e9e9e", marginTop: "1rem" }}>
//           {filtered.length} of {workers.length} staff members
//         </p>
//       </div>

//       {/* ══ ADD DIALOG ══ */}
//       <Dialog open={addOpen} onClose={closeAdd} PaperProps={{ style: paperRound }}>
//         <DialogTitle style={{ paddingBottom: 4 }}>
//           <div className="flex items-center justify-between">
//             <div className="flex items-center gap-3">
//               <div style={{ width: 40, height: 40, borderRadius: "10px", background: "#e6f0fa", display: "flex", alignItems: "center", justifyContent: "center" }}>
//                 <Add style={{ color: "#0066cc", fontSize: 20 }} />
//               </div>
//               <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: "1.0625rem", color: "#212121" }}>Add New Staff</span>
//             </div>
//             <IconButton size="small" onClick={closeAdd}><Close style={{ fontSize: 18, color: "#9e9e9e" }} /></IconButton>
//           </div>
//         </DialogTitle>
//         <DialogContent style={{ paddingTop: 20 }}>
//           <StaffFormFields 
//             form={form} 
//             setForm={setForm} 
//             errors={errors} 
//             setErrors={setErrors} 
//             showPass={showPass} 
//             setShowPass={setShowPass}
//             loading={addLoading}
//           />
//         </DialogContent>
//         <DialogActions style={{ padding: "8px 24px 20px", gap: 8 }}>
//           <Button onClick={closeAdd} disabled={addLoading} style={{ color: "#616161", textTransform: "none", fontWeight: 500, borderRadius: "8px", padding: "8px 20px" }}>Cancel</Button>
//           <Button 
//             onClick={handleAdd} 
//             variant="contained"
//             disabled={addLoading}
//             style={{ 
//               background: "#0066cc", 
//               color: "#fff", 
//               textTransform: "none", 
//               fontWeight: 600, 
//               borderRadius: "8px", 
//               padding: "8px 24px", 
//               boxShadow: "0 4px 12px rgba(0,102,204,0.3)" 
//             }}>
//             {addLoading ? <CircularProgress size={20} color="inherit" /> : "Add Staff"}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* ══ EDIT DIALOG ══ */}
//       <Dialog open={!!editTarget} onClose={closeEdit} PaperProps={{ style: paperRound }}>
//         <DialogTitle style={{ paddingBottom: 4 }}>
//           <div className="flex items-center justify-between">
//             <div className="flex items-center gap-3">
//               <div style={{ width: 40, height: 40, borderRadius: "10px", background: "#fff3e0", display: "flex", alignItems: "center", justifyContent: "center" }}>
//                 <Edit style={{ color: "#ff9900", fontSize: 18 }} />
//               </div>
//               <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: "1.0625rem", color: "#212121" }}>Edit Staff</span>
//             </div>
//             <IconButton size="small" onClick={closeEdit}><Close style={{ fontSize: 18, color: "#9e9e9e" }} /></IconButton>
//           </div>
//         </DialogTitle>
//         <DialogContent style={{ paddingTop: 20 }}>
//           <StaffFormFields 
//             form={form} 
//             setForm={setForm} 
//             errors={errors} 
//             setErrors={setErrors} 
//             showPass={showPass} 
//             setShowPass={setShowPass}
//             loading={updateLoading}
//           />
//         </DialogContent>
//         <DialogActions style={{ padding: "8px 24px 20px", gap: 8 }}>
//           <Button onClick={closeEdit} disabled={updateLoading} style={{ color: "#616161", textTransform: "none", fontWeight: 500, borderRadius: "8px", padding: "8px 20px" }}>Cancel</Button>
//           <Button 
//             onClick={handleEditSave} 
//             variant="contained"
//             disabled={updateLoading}
//             style={{ 
//               background: "#ff9900", 
//               color: "#fff", 
//               textTransform: "none", 
//               fontWeight: 600, 
//               borderRadius: "8px", 
//               padding: "8px 24px", 
//               boxShadow: "0 4px 12px rgba(255,153,0,0.3)" 
//             }}>
//             {updateLoading ? <CircularProgress size={20} color="inherit" /> : "Save Changes"}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* ══ VIEW DIALOG ══ */}
//       <Dialog open={!!viewTarget} onClose={() => setViewTarget(null)}
//         PaperProps={{ style: { borderRadius: "18px", maxWidth: 360, width: "100%" } }}>
//         {viewTarget && (
//           <>
//             <div style={{ background: viewTarget.isActive ? "#d4edda" : "#f8d7da", padding: "32px 24px 24px", position: "relative" }}>
//               <IconButton size="small" onClick={() => setViewTarget(null)}
//                 style={{ position: "absolute", top: 12, right: 12, background: "rgba(255,255,255,0.7)", padding: 4 }}>
//                 <Close style={{ fontSize: 16, color: "#616161" }} />
//               </IconButton>
//               <div className="flex flex-col items-center">
//                 <MemberAvatar member={viewTarget} size={72} fontSize="1.4rem" bgOverride="#fff" colorOverride="#0066cc" shadow />
//                 <h2 style={{ margin: "14px 0 0", fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "#212121", textAlign: "center" }}>
//                   {viewTarget.name}
//                 </h2>
//               </div>
//             </div>
//             <DialogContent style={{ padding: "20px 24px 24px" }}>
//               {/* Mobile row */}
//               <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid #f0f0f0" }}>
//                 <div style={{ width: 36, height: 36, borderRadius: "9px", background: "#e6f0fa", display: "flex", alignItems: "center", justifyContent: "center" }}>
//                   <Phone style={{ fontSize: 16, color: "#0066cc" }} />
//                 </div>
//                 <div>
//                   <p style={{ margin: 0, fontSize: "0.75rem", color: "#9e9e9e", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>Mobile</p>
//                   <p style={{ margin: 0, fontSize: "0.9375rem", color: "#212121", fontWeight: 500 }}>{viewTarget.mobile}</p>
//                 </div>
//               </div>
//               {/* Status row */}
//               <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0" }}>
//                 <div style={{ width: 36, height: 36, borderRadius: "9px", background: viewTarget.isActive ? "#d4edda" : "#f8d7da", display: "flex", alignItems: "center", justifyContent: "center" }}>
//                   <span style={{ width: 10, height: 10, borderRadius: "50%", background: viewTarget.isActive ? "#1e7e34" : "#bd2130", display: "block" }} />
//                 </div>
//                 <div>
//                   <p style={{ margin: 0, fontSize: "0.75rem", color: "#9e9e9e", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>Status</p>
//                   <Chip 
//                     label={viewTarget.isActive ? "Active" : "Inactive"} 
//                     size="small"
//                     style={{ 
//                       background: viewTarget.isActive ? "#d4edda" : "#f8d7da", 
//                       color: viewTarget.isActive ? "#1e7e34" : "#bd2130", 
//                       fontWeight: 600, 
//                       fontSize: "0.75rem", 
//                       marginTop: 4 
//                     }} />
//                 </div>
//               </div>
//             </DialogContent>
//           </>
//         )}
//       </Dialog>

//       {/* ══ DELETE DIALOG ══ */}
//       <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)}
//         PaperProps={{ style: { borderRadius: "16px", padding: "8px", maxWidth: 420, width: "100%" } }}>
//         <DialogTitle style={{ paddingBottom: 0 }}>
//           <div className="flex items-center gap-3">
//             <div style={{ width: 44, height: 44, borderRadius: "12px", background: "#f8d7da", display: "flex", alignItems: "center", justifyContent: "center" }}>
//               <WarningAmberRounded style={{ color: "#dc3545", fontSize: 22 }} />
//             </div>
//             <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: "1.0625rem", color: "#212121" }}>Delete Staff Member</span>
//           </div>
//         </DialogTitle>
//         <DialogContent style={{ paddingTop: 16 }}>
//           <DialogContentText style={{ color: "#616161", fontSize: "0.9375rem", lineHeight: 1.6 }}>
//             Are you sure you want to delete <strong style={{ color: "#212121" }}>{deleteTarget?.name}</strong>? This action cannot be undone.
//           </DialogContentText>
//         </DialogContent>
//         <DialogActions style={{ padding: "8px 24px 16px", gap: 8 }}>
//           <Button 
//             onClick={() => setDeleteTarget(null)} 
//             disabled={deleteLoading}
//             style={{ color: "#616161", textTransform: "none", fontWeight: 500, borderRadius: "8px", padding: "8px 20px" }}>
//             Cancel
//           </Button>
//           <Button 
//             onClick={handleDelete} 
//             variant="contained"
//             disabled={deleteLoading}
//             style={{ 
//               background: "#dc3545", 
//               color: "#fff", 
//               textTransform: "none", 
//               fontWeight: 600, 
//               borderRadius: "8px", 
//               padding: "8px 20px", 
//               boxShadow: "0 4px 12px rgba(220,53,69,0.35)" 
//             }}>
//             {deleteLoading ? <CircularProgress size={20} color="inherit" /> : "Yes, Delete"}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* Snackbar for notifications */}
//       <Snackbar
//         open={snackbar.open}
//         autoHideDuration={3000}
//         onClose={() => setSnackbar({ ...snackbar, open: false })}
//         anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
//       >
//         <Alert 
//           onClose={() => setSnackbar({ ...snackbar, open: false })} 
//           severity={snackbar.severity}
//           sx={{ borderRadius: 2 }}
//         >
//           {snackbar.message}
//         </Alert>
//       </Snackbar>
//     </div>
//   );
// }

// // ── Helper Sub-components ──────────────────────────────────────
// function MemberAvatar({ member, size = 40, fontSize = "0.8125rem", bgOverride, colorOverride, shadow }) {
//   const initials = getInitials(member.name);
//   const bg = bgOverride || (member.isActive ? "#d4edda" : "#f8d7da");
//   return (
//     <Avatar style={{
//       width: size, height: size,
//       background: bg,
//       color: colorOverride || (member.isActive ? "#1e7e34" : "#bd2130"),
//       fontWeight: 700,
//       fontSize,
//       fontFamily: "'Poppins', sans-serif",
//       border: "2px solid rgba(255,255,255,0.8)",
//       boxShadow: shadow ? "0 4px 14px rgba(0,0,0,0.15)" : undefined,
//     }}>
//       {initials}
//     </Avatar>
//   );
// }

// function ActionBtns({ onView, onEdit, onDelete, size = 34, iconSize = 16, gap = 4, borderRadius = "8px", loading }) {
//   const btn = (onClick, bg, color, Icon, tip) => (
//     <Tooltip title={tip} arrow>
//       <IconButton 
//         size="small" 
//         onClick={onClick}
//         disabled={loading}
//         style={{ 
//           background: bg, 
//           color, 
//           borderRadius, 
//           width: size, 
//           height: size,
//           opacity: loading ? 0.6 : 1
//         }}>
//         {loading ? <CircularProgress size={iconSize} /> : <Icon style={{ fontSize: iconSize }} />}
//       </IconButton>
//     </Tooltip>
//   );
//   return (
//     <div style={{ display: "flex", alignItems: "center", gap }}>
//       {btn(onView,   "#e6f0fa", "#0066cc", Visibility, "View")}
//       {btn(onEdit,   "#fff3e0", "#ff9900", Edit,       "Edit")}
//       {btn(onDelete, "#f8d7da", "#dc3545", Delete,     "Delete")}
//     </div>
//   );
// }

// function EmptyState() {
//   return (
//     <div className="flex flex-col items-center justify-center py-20" style={{ color: "#9e9e9e" }}>
//       <People style={{ fontSize: 48, marginBottom: 12, opacity: 0.3 }} />
//       <p style={{ fontSize: "1rem", fontWeight: 500 }}>No staff found</p>
//       <p style={{ fontSize: "0.875rem", marginTop: 4 }}>Try adjusting your search</p>
//     </div>
//   );
// }


import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Button, IconButton, Tooltip, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions,
  Chip, Avatar, TextField, InputAdornment, CircularProgress,
  Alert, Snackbar,
} from "@mui/material";
import {
  Add, Search, Visibility, Edit, Delete, People, Close,
  WarningAmberRounded, ViewModule, ViewList,
  Phone, Lock, Person, VisibilityOff,
} from "@mui/icons-material";

import {
  getAllWorkers, addWorker, updateWorker, deleteWorker,
  selectAllWorkers, selectWorkersLoading, selectWorkersError,
  selectAddWorkerLoading, selectUpdateWorkerLoading, selectDeleteWorkerLoading,
  selectSuccessMessage, clearWorkersError, clearSuccessMessage,
} from "../../../redux/slice/Vendor";

const emptyForm = { name: "", mobile: "", password: "" };

function getInitials(name) {
  return name.trim().split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
}

const AVATAR_COLORS = [
  { bg: "#dbeafe", text: "#1d4ed8" },
  { bg: "#fce7f3", text: "#be185d" },
  { bg: "#d1fae5", text: "#065f46" },
  { bg: "#fef3c7", text: "#92400e" },
  { bg: "#ede9fe", text: "#5b21b6" },
  { bg: "#fee2e2", text: "#991b1b" },
];
const getAvatarColor = (str) =>
  AVATAR_COLORS[(str ? str.charCodeAt(0) : 0) % AVATAR_COLORS.length];

// ── Shared Form Fields ─────────────────────────────────────────
function StaffFormFields({ form, setForm, errors, setErrors, showPass, setShowPass, loading }) {
  const handle = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };
  const sx = { mb: "18px", "& .MuiOutlinedInput-root": { borderRadius: "10px" } };
  return (
    <div>
      <TextField
        fullWidth label="Full Name" value={form.name} onChange={handle("name")}
        error={!!errors.name} helperText={errors.name} disabled={loading} sx={sx}
        InputProps={{ startAdornment: <InputAdornment position="start"><Person style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment> }}
      />
      <TextField
        fullWidth label="Mobile Number" value={form.mobile} onChange={handle("mobile")}
        error={!!errors.mobile} helperText={errors.mobile} placeholder="10-digit number"
        disabled={loading} sx={sx}
        InputProps={{ startAdornment: <InputAdornment position="start"><Phone style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment> }}
      />
      <TextField
        fullWidth label="Password" type={showPass ? "text" : "password"} value={form.password}
        onChange={handle("password")} error={!!errors.password} helperText={errors.password}
        disabled={loading} sx={{ mb: 0, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}
        InputProps={{
          startAdornment: <InputAdornment position="start"><Lock style={{ fontSize: 18, color: "#9e9e9e" }} /></InputAdornment>,
          endAdornment: (
            <InputAdornment position="end">
              <IconButton size="small" onClick={() => setShowPass((v) => !v)} edge="end" disabled={loading}>
                {showPass ? <VisibilityOff style={{ fontSize: 18 }} /> : <Visibility style={{ fontSize: 18 }} />}
              </IconButton>
            </InputAdornment>
          ),
        }}
      />
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────
export default function StaffPage() {
  const dispatch = useDispatch();

  const workers     = useSelector(selectAllWorkers);
  const loading     = useSelector(selectWorkersLoading);
  const addLoading  = useSelector(selectAddWorkerLoading);
  const updateLoading = useSelector(selectUpdateWorkerLoading);
  const deleteLoading = useSelector(selectDeleteWorkerLoading);
  const error       = useSelector(selectWorkersError);
  const successMessage = useSelector(selectSuccessMessage);

  const [search, setSearch]         = useState("");
  const [viewMode, setViewMode]     = useState("list");
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [viewTarget, setViewTarget] = useState(null);
  const [addOpen, setAddOpen]       = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [form, setForm]             = useState(emptyForm);
  const [showPass, setShowPass]     = useState(false);
  const [errors, setErrors]         = useState({});
  const [snackbar, setSnackbar]     = useState({ open: false, message: "", severity: "success" });

  useEffect(() => { dispatch(getAllWorkers()); }, [dispatch]);

  useEffect(() => {
    if (successMessage) {
      setSnackbar({ open: true, message: successMessage, severity: "success" });
      dispatch(clearSuccessMessage());
    }
  }, [successMessage, dispatch]);

  useEffect(() => {
    if (error) {
      setSnackbar({ open: true, message: error, severity: "error" });
      dispatch(clearWorkersError());
    }
  }, [error, dispatch]);

  const filtered = workers.filter(
    (s) =>
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.mobile?.toString().includes(search)
  );

  const validate = (f) => {
    const e = {};
    if (!f.name?.trim()) e.name = "Name is required";
    if (!f.mobile?.trim()) e.mobile = "Mobile is required";
    else if (!/^\d{10}$/.test(f.mobile.replace(/\s/g, ""))) e.mobile = "Enter valid 10-digit number";
    if (!f.password?.trim() && !editTarget) e.password = "Password is required";
    else if (f.password?.trim() && f.password.length < 6) e.password = "Minimum 6 characters";
    return e;
  };

  const handleAdd = async () => {
    const e = validate(form);
    if (Object.keys(e).length) { setErrors(e); return; }
    const result = await dispatch(addWorker({
      name: form.name.trim(),
      mobile: parseInt(form.mobile.replace(/\s/g, "")),
      password: form.password,
      isActive: true,
    }));
    if (!result.error) { setAddOpen(false); setForm(emptyForm); setErrors({}); setShowPass(false); }
  };

  const handleEditOpen = (member) => {
    setEditTarget(member);
    setForm({ name: member.name, mobile: member.mobile.toString(), password: "" });
    setErrors({}); setShowPass(false);
  };

  const handleEditSave = async () => {
    const e = validate(form);
    if (Object.keys(e).length) { setErrors(e); return; }
    const result = await dispatch(updateWorker({
      workerId: editTarget._id,
      workerData: {
        name: form.name.trim(),
        mobile: parseInt(form.mobile.replace(/\s/g, "")),
        ...(form.password.trim() && { password: form.password }),
      },
    }));
    if (!result.error) { setEditTarget(null); setForm(emptyForm); setErrors({}); setShowPass(false); }
  };

  const handleDelete = async () => {
    const result = await dispatch(deleteWorker(deleteTarget._id));
    if (!result.error) setDeleteTarget(null);
  };

  const closeAdd  = () => { setAddOpen(false);   setForm(emptyForm); setErrors({}); setShowPass(false); };
  const closeEdit = () => { setEditTarget(null);  setForm(emptyForm); setErrors({}); setShowPass(false); };

  const paperRound = { borderRadius: "18px", width: "100%", maxWidth: 440, padding: "4px" };

  // ── Loading ──
  if (loading && !workers.length) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#1a3c5e] flex items-center justify-center animate-bounce shadow-lg">
            <People sx={{ fontSize: 26, color: "#fff" }} />
          </div>
          <p className="text-sm text-gray-400 animate-pulse font-medium">Loading staff...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @media (max-width: 640px) {
          .hide-on-mobile { display: none; }
        }
      `}</style>

      <div
        className="min-h-screen bg-[#f1f4f8] px-4 py-4 sm:px-6 lg:px-8"
        style={{ animation: "fadeIn 0.25s ease" }}
      >
        <div className="max-w-screen-xl mx-auto space-y-4 sm:space-y-5">

          {/* ── Header ── */}
          <div
            className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
            style={{ animation: "fadeSlideUp 0.35s ease both" }}
          >
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-[#1a3c5e] tracking-tight leading-tight">
                Staff Management
              </h1>
              <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
                {workers.length} total members
              </p>
            </div>

            <button
              onClick={() => { setAddOpen(true); setForm(emptyForm); setErrors({}); }}
              disabled={addLoading}
              className="flex items-center gap-2 px-4 py-2 sm:py-2.5 rounded-xl bg-[#1a3c5e] text-white text-sm font-semibold hover:bg-[#0f2a44] transition-all shadow-sm disabled:opacity-50 self-start sm:self-auto"
            >
              {addLoading
                ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : <Add sx={{ fontSize: 18 }} />}
              Add Staff
            </button>
          </div>

          {/* ── Search + View Toggle ── */}
          <div
            className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-3 sm:p-4"
            style={{ animation: "fadeSlideUp 0.4s ease both" }}
          >
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
              {/* Search */}
              <div className="relative flex-1">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                  <Search sx={{ fontSize: 19 }} />
                </span>
                <input
                  type="text"
                  placeholder="Search by name or mobile..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-9 pr-9 py-2 sm:py-2.5 text-sm rounded-xl border border-gray-200 bg-gray-50 outline-none focus:ring-2 focus:ring-[#1a3c5e]/25 focus:border-[#1a3c5e] transition-all placeholder:text-gray-400"
                />
                {search && (
                  <button
                    onClick={() => setSearch("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <Close sx={{ fontSize: 16 }} />
                  </button>
                )}
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between sm:justify-end gap-3">
                <span className="text-xs sm:text-sm text-gray-500 hide-on-mobile">
                  {filtered.length} member{filtered.length !== 1 ? "s" : ""}
                </span>

                {/* View toggle */}
                <div className="flex rounded-xl overflow-hidden border border-gray-200">
                  {[
                    { mode: "list", Icon: ViewList,   label: "List" },
                    { mode: "card", Icon: ViewModule,  label: "Cards" },
                  ].map(({ mode, Icon, label }) => (
                    <button
                      key={mode}
                      onClick={() => setViewMode(mode)}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 text-xs font-semibold transition-all duration-200 flex items-center gap-1 sm:gap-2 ${
                        viewMode === mode
                          ? "bg-[#1a3c5e] text-white"
                          : "bg-white text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      <Icon sx={{ fontSize: { xs: 16, sm: 18 } }} />
                      <span className="hide-on-mobile">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {search && (
              <p className="text-xs text-gray-400 mt-2">
                {filtered.length} result{filtered.length !== 1 ? "s" : ""} for &ldquo;{search}&rdquo;
              </p>
            )}
          </div>

          {/* ══ LIST VIEW ══ */}
          {viewMode === "list" && (
            <div
              className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
              style={{ animation: "fadeSlideUp 0.45s ease both" }}
            >
              {filtered.length === 0 ? (
                <EmptyState search={search} onClear={() => setSearch("")} />
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">#</th>
                        <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">Staff Member</th>
                        <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Mobile</th>
                        <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Status</th>
                        <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((member, idx) => {
                        const av = getAvatarColor(member.name);
                        return (
                          <tr
                            key={member._id}
                            className="border-b border-gray-100 hover:bg-slate-50 transition-colors duration-150"
                          >
                            <td className="px-3 sm:px-5 py-2 sm:py-4 text-xs sm:text-sm text-gray-400">{idx + 1}</td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4">
                              <div className="flex items-center gap-3">
                                <div
                                  className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                                  style={{ background: av.bg, color: av.text }}
                                >
                                  {getInitials(member.name)}
                                </div>
                                <div>
                                  <p className="text-sm font-semibold text-gray-900">{member.name}</p>
                                  <p className="text-xs text-gray-400 sm:hidden">{member.mobile}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 hide-on-mobile">
                              <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Phone sx={{ fontSize: 14, color: "#9e9e9e" }} />
                                {member.mobile}
                              </div>
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 hide-on-mobile">
                              <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                                member.isActive
                                  ? "bg-green-100 text-green-700"
                                  : "bg-red-100 text-red-700"
                              }`}>
                                {member.isActive ? "Active" : "Inactive"}
                              </span>
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4">
                              <ActionBtns
                                onView={() => setViewTarget(member)}
                                onEdit={() => handleEditOpen(member)}
                                onDelete={() => setDeleteTarget(member)}
                                deleting={deleteLoading && deleteTarget?._id === member._id}
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ══ CARD VIEW ══ */}
          {viewMode === "card" && (
            filtered.length === 0
              ? <EmptyState search={search} onClear={() => setSearch("")} />
              : (
                <div
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
                  style={{ animation: "fadeSlideUp 0.45s ease both" }}
                >
                  {filtered.map((member, idx) => {
                    const av = getAvatarColor(member.name);
                    return (
                      <div
                        key={member._id}
                        className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col gap-3 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5"
                        style={{ animation: "fadeSlideUp 0.4s ease both", animationDelay: `${idx * 50}ms` }}
                      >
                        {/* Avatar + name */}
                        <div className="flex items-center gap-3">
                          <div
                            className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                            style={{ background: av.bg, color: av.text }}
                          >
                            {getInitials(member.name)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-gray-900 text-sm leading-tight truncate">{member.name}</p>
                            <div className="flex items-center gap-1 mt-0.5">
                              <Phone sx={{ fontSize: 11, color: "#9e9e9e" }} />
                              <p className="text-xs text-gray-400 truncate">{member.mobile}</p>
                            </div>
                          </div>
                        </div>

                        <div className="h-px bg-gray-100" />

                        {/* Status */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Status</span>
                          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                            member.isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                          }`}>
                            {member.isActive ? "Active" : "Inactive"}
                          </span>
                        </div>

                        <div className="h-px bg-gray-100" />

                        {/* Actions */}
                        <div className="flex items-center justify-end">
                          <ActionBtns
                            onView={() => setViewTarget(member)}
                            onEdit={() => handleEditOpen(member)}
                            onDelete={() => setDeleteTarget(member)}
                            deleting={deleteLoading && deleteTarget?._id === member._id}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )
          )}

          {/* Footer count */}
          <p className="text-right text-xs sm:text-sm text-gray-400">
            {filtered.length} of {workers.length} staff members
          </p>
        </div>
      </div>

      {/* ══ ADD DIALOG ══ */}
      <Dialog open={addOpen} onClose={closeAdd} PaperProps={{ style: paperRound }}>
        <DialogTitle style={{ paddingBottom: 4 }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div style={{ width: 40, height: 40, borderRadius: "10px", background: "#e6f0fa", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Add style={{ color: "#1a3c5e", fontSize: 20 }} />
              </div>
              <span style={{ fontWeight: 700, fontSize: "1.0625rem", color: "#1a3c5e" }}>Add New Staff</span>
            </div>
            <IconButton size="small" onClick={closeAdd}><Close style={{ fontSize: 18, color: "#9e9e9e" }} /></IconButton>
          </div>
        </DialogTitle>
        <DialogContent style={{ paddingTop: 20 }}>
          <StaffFormFields form={form} setForm={setForm} errors={errors} setErrors={setErrors} showPass={showPass} setShowPass={setShowPass} loading={addLoading} />
        </DialogContent>
        <DialogActions style={{ padding: "8px 24px 20px", gap: 8 }}>
          <button onClick={closeAdd} disabled={addLoading}
            className="px-5 py-2 rounded-xl border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 transition-all disabled:opacity-50">
            Cancel
          </button>
          <button onClick={handleAdd} disabled={addLoading}
            className="px-6 py-2 rounded-xl bg-[#1a3c5e] text-white text-sm font-semibold hover:bg-[#0f2a44] transition-all shadow-sm disabled:opacity-50 flex items-center gap-2">
            {addLoading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : null}
            Add Staff
          </button>
        </DialogActions>
      </Dialog>

      {/* ══ EDIT DIALOG ══ */}
      <Dialog open={!!editTarget} onClose={closeEdit} PaperProps={{ style: paperRound }}>
        <DialogTitle style={{ paddingBottom: 4 }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div style={{ width: 40, height: 40, borderRadius: "10px", background: "#fef3c7", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Edit style={{ color: "#92400e", fontSize: 18 }} />
              </div>
              <span style={{ fontWeight: 700, fontSize: "1.0625rem", color: "#1a3c5e" }}>Edit Staff</span>
            </div>
            <IconButton size="small" onClick={closeEdit}><Close style={{ fontSize: 18, color: "#9e9e9e" }} /></IconButton>
          </div>
        </DialogTitle>
        <DialogContent style={{ paddingTop: 20 }}>
          <StaffFormFields form={form} setForm={setForm} errors={errors} setErrors={setErrors} showPass={showPass} setShowPass={setShowPass} loading={updateLoading} />
        </DialogContent>
        <DialogActions style={{ padding: "8px 24px 20px", gap: 8 }}>
          <button onClick={closeEdit} disabled={updateLoading}
            className="px-5 py-2 rounded-xl border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 transition-all disabled:opacity-50">
            Cancel
          </button>
          <button onClick={handleEditSave} disabled={updateLoading}
            className="px-6 py-2 rounded-xl bg-amber-500 text-white text-sm font-semibold hover:bg-amber-600 transition-all shadow-sm disabled:opacity-50 flex items-center gap-2">
            {updateLoading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : null}
            Save Changes
          </button>
        </DialogActions>
      </Dialog>

      {/* ══ VIEW DIALOG ══ */}
      <Dialog open={!!viewTarget} onClose={() => setViewTarget(null)}
        PaperProps={{ style: { borderRadius: "18px", maxWidth: 360, width: "100%" } }}>
        {viewTarget && (
          <>
            <div style={{
              background: viewTarget.isActive ? "#d1fae5" : "#fee2e2",
              padding: "32px 24px 24px",
              position: "relative",
            }}>
              <IconButton size="small" onClick={() => setViewTarget(null)}
                style={{ position: "absolute", top: 12, right: 12, background: "rgba(255,255,255,0.7)", padding: 4 }}>
                <Close style={{ fontSize: 16, color: "#616161" }} />
              </IconButton>
              <div className="flex flex-col items-center">
                {(() => {
                  const av = getAvatarColor(viewTarget.name);
                  return (
                    <div className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold shadow-lg"
                      style={{ background: "#fff", color: av.text }}>
                      {getInitials(viewTarget.name)}
                    </div>
                  );
                })()}
                <h2 className="mt-3 font-bold text-lg text-gray-900 text-center">{viewTarget.name}</h2>
              </div>
            </div>
            <DialogContent style={{ padding: "20px 24px 24px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid #f0f0f0" }}>
                <div style={{ width: 36, height: 36, borderRadius: "9px", background: "#dbeafe", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Phone style={{ fontSize: 16, color: "#1d4ed8" }} />
                </div>
                <div>
                  <p style={{ margin: 0, fontSize: "0.75rem", color: "#9e9e9e", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>Mobile</p>
                  <p style={{ margin: 0, fontSize: "0.9375rem", color: "#212121", fontWeight: 500 }}>{viewTarget.mobile}</p>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0" }}>
                <div style={{ width: 36, height: 36, borderRadius: "9px", background: viewTarget.isActive ? "#d1fae5" : "#fee2e2", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ width: 10, height: 10, borderRadius: "50%", background: viewTarget.isActive ? "#065f46" : "#991b1b", display: "block" }} />
                </div>
                <div>
                  <p style={{ margin: 0, fontSize: "0.75rem", color: "#9e9e9e", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>Status</p>
                  <span className={`inline-block mt-1 text-xs font-semibold px-3 py-1 rounded-full ${
                    viewTarget.isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}>
                    {viewTarget.isActive ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
            </DialogContent>
          </>
        )}
      </Dialog>

      {/* ══ DELETE DIALOG ══ */}
      <Dialog open={!!deleteTarget} onClose={() => !deleteLoading && setDeleteTarget(null)}
        PaperProps={{ style: { borderRadius: "16px", padding: "8px", maxWidth: 420, width: "100%" } }}>
        <DialogTitle style={{ paddingBottom: 0 }}>
          <div className="flex items-center gap-3">
            <div style={{ width: 44, height: 44, borderRadius: "12px", background: "#fee2e2", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <WarningAmberRounded style={{ color: "#dc2626", fontSize: 22 }} />
            </div>
            <span style={{ fontWeight: 700, fontSize: "1.0625rem", color: "#1a3c5e" }}>Delete Staff Member</span>
          </div>
        </DialogTitle>
        <DialogContent style={{ paddingTop: 16 }}>
          <DialogContentText style={{ color: "#616161", fontSize: "0.9375rem", lineHeight: 1.6 }}>
            Are you sure you want to delete{" "}
            <strong style={{ color: "#1a3c5e" }}>{deleteTarget?.name}</strong>?{" "}
            This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions style={{ padding: "8px 24px 16px", gap: 8 }}>
          <button onClick={() => setDeleteTarget(null)} disabled={deleteLoading}
            className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all text-sm disabled:opacity-50">
            Cancel
          </button>
          <button onClick={handleDelete} disabled={deleteLoading}
            className="flex-1 px-4 py-2 bg-red-600 text-white rounded-xl font-medium hover:bg-red-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm flex items-center justify-center gap-2">
            {deleteLoading
              ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : null}
            {deleteLoading ? "Deleting..." : "Yes, Delete"}
          </button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
          severity={snackbar.severity}
          sx={{ borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

// ── Helper Sub-components ──────────────────────────────────────
function ActionBtns({ onView, onEdit, onDelete, deleting }) {
  return (
    <div className="flex items-center gap-1.5">
      <Tooltip title="View" arrow>
        <button onClick={onView}
          className="w-8 h-8 rounded-lg flex items-center justify-center bg-blue-50 text-blue-600 hover:bg-blue-100 transition-all">
          <Visibility sx={{ fontSize: 15 }} />
        </button>
      </Tooltip>
      <Tooltip title="Edit" arrow>
        <button onClick={onEdit}
          className="w-8 h-8 rounded-lg flex items-center justify-center bg-amber-50 text-amber-600 hover:bg-amber-100 transition-all">
          <Edit sx={{ fontSize: 15 }} />
        </button>
      </Tooltip>
      <Tooltip title="Delete" arrow>
        <button onClick={onDelete} disabled={deleting}
          className="w-8 h-8 rounded-lg flex items-center justify-center bg-red-50 text-red-500 hover:bg-red-100 transition-all disabled:opacity-50">
          {deleting
            ? <div className="w-3.5 h-3.5 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
            : <Delete sx={{ fontSize: 15 }} />}
        </button>
      </Tooltip>
    </div>
  );
}

function EmptyState({ search, onClear }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 sm:py-24 text-center">
      <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
        <People sx={{ fontSize: 32, color: "#93c5fd" }} />
      </div>
      {search ? (
        <>
          <p className="text-base font-bold text-gray-700">No results for &ldquo;{search}&rdquo;</p>
          <p className="text-sm text-gray-400 mt-1">Try a different search term</p>
          <button onClick={onClear} className="mt-3 text-sm text-[#1a3c5e] hover:underline font-semibold">
            Clear search
          </button>
        </>
      ) : (
        <>
          <p className="text-base font-bold text-gray-700">No Staff Members</p>
          <p className="text-sm text-gray-400 mt-1">Add your first staff member to get started</p>
        </>
      )}
    </div>
  );
}