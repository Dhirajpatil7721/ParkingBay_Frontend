// import React, { useState, useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import {
//   Button,
//   IconButton,
//   Tooltip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Chip,
//   CircularProgress,
//   Alert,
//   Snackbar,
//   Avatar,
//   Badge,
// } from '@mui/material';
// import {
//   TrendingUp as TrendingUpIcon,
//   TrendingDown as TrendingDownIcon,
//   CalendarToday as CalendarIcon,
//   DirectionsCar as CarIcon,
//   CreditCard as CreditCardIcon,
//   AccessTime as ClockIcon,
//   WarningAmber as WarningIcon,
//   Refresh as RefreshIcon,
//   KeyboardArrowDown as ArrowDownIcon,
//   KeyboardArrowUp as ArrowUpIcon,
//   TwoWheeler as TwoWheelerIcon,
//   DirectionsBus as BusIcon,
//   LocalShipping as TruckIcon,
//   Assessment as AssessmentIcon,
//   BarChart as BarChartIcon,
//   PieChart as PieChartIcon,
//   ShowChart as ShowChartIcon,
//   Close as CloseIcon,
//   Star as StarIcon,
//   StarBorder as StarBorderIcon,
//   EmojiEvents as TrophyIcon,
//   Speed as SpeedIcon,
//   Info as InfoIcon,
//   CheckCircle as CheckCircleIcon,
//   Cancel as CancelIcon,
//   Download as DownloadIcon,
//   Print as PrintIcon,
//   Share as ShareIcon,
//   MoreVert as MoreVertIcon,
// } from '@mui/icons-material';
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip as ChartTooltip,
//   Legend,
//   ArcElement,
// } from 'chart.js';
// import { Bar, Pie } from 'react-chartjs-2';
// import { useTheme } from '@mui/material/styles';
// import useMediaQuery from '@mui/material/useMediaQuery';
// import Theme from '../../../Constant/Theme';

// // Redux imports
// import { getMonthlyAnalytics } from '../../../redux/slice/analyticsSlice';
// // import { useDispatch, useSelector } from 'react-redux';

// // Register ChartJS components
// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   ChartTooltip,
//   Legend,
//   ArcElement
// );

// // ─── Month Picker Modal ──────────────────────────────────────────────────
// const MonthPickerModal = ({ open, onClose, selectedMonthYear, onSelect }) => {
//   const currentYear = new Date().getFullYear();
//   const lastYear = currentYear - 1;
//   const [selectedYear, setSelectedYear] = useState(currentYear);

//   const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

//   const handleMonthSelect = (monthNumber) => {
//     const formattedMonth = monthNumber.toString().padStart(2, '0');
//     onSelect(`${selectedYear}-${formattedMonth}`);
//     onClose();
//   };

//   return (
//     <Dialog
//       open={open}
//       onClose={onClose}
//       maxWidth="xs"
//       fullWidth
//       PaperProps={{
//         style: {
//           borderRadius: Theme.borderRadius.xl,
//           width: '100%',
//           maxWidth: 440,
//           padding: '4px',
//           boxShadow: Theme.shadows.lg,
//         }
//       }}
//     >
//       <DialogTitle className="pb-1">
//         <div className="flex items-center justify-between">
//           <div className="flex items-center gap-3">
//             <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//               <CalendarIcon className="text-lg" style={{ color: Theme.colors.primary.main }} />
//             </div>
//             <span className="font-heading font-bold text-lg" style={{ color: Theme.colors.text.primary }}>Select Month</span>
//           </div>
//           <IconButton size="small" onClick={onClose}>
//             <CloseIcon className="text-lg" style={{ color: Theme.colors.text.secondary }} />
//           </IconButton>
//         </div>
//       </DialogTitle>
//       <DialogContent className="pt-5">
//         <div className="flex justify-center gap-3 mb-5">
//           <Button
//             variant={selectedYear === lastYear ? 'contained' : 'outlined'}
//             onClick={() => setSelectedYear(lastYear)}
//             className="flex-1 py-2 font-semibold"
//             style={{
//               background: selectedYear === lastYear ? Theme.colors.primary.main : 'transparent',
//               color: selectedYear === lastYear ? Theme.colors.common.white : Theme.colors.text.secondary,
//               borderColor: Theme.colors.border.main,
//               borderRadius: Theme.borderRadius.md,
//               textTransform: 'none',
//             }}
//           >
//             {lastYear}
//           </Button>
//           <Button
//             variant={selectedYear === currentYear ? 'contained' : 'outlined'}
//             onClick={() => setSelectedYear(currentYear)}
//             className="flex-1 py-2 font-semibold"
//             style={{
//               background: selectedYear === currentYear ? Theme.colors.primary.main : 'transparent',
//               color: selectedYear === currentYear ? Theme.colors.common.white : Theme.colors.text.secondary,
//               borderColor: Theme.colors.border.main,
//               borderRadius: Theme.borderRadius.md,
//               textTransform: 'none',
//             }}
//           >
//             {currentYear}
//           </Button>
//         </div>

//         <div className="grid grid-cols-3 gap-2">
//           {MONTHS.map((month, index) => {
//             const monthNumber = index + 1;
//             const formattedMonth = monthNumber.toString().padStart(2, '0');
//             const isSelected = selectedMonthYear === `${selectedYear}-${formattedMonth}`;

//             return (
//               <Button
//                 key={index}
//                 variant={isSelected ? 'contained' : 'outlined'}
//                 onClick={() => handleMonthSelect(monthNumber)}
//                 className="py-2.5 font-semibold text-sm"
//                 style={{
//                   background: isSelected ? Theme.colors.primary.main : 'transparent',
//                   color: isSelected ? Theme.colors.common.white : Theme.colors.text.secondary,
//                   borderColor: Theme.colors.border.main,
//                   borderRadius: Theme.borderRadius.md,
//                   textTransform: 'none',
//                 }}
//               >
//                 {month}
//               </Button>
//             );
//           })}
//         </div>
//       </DialogContent>
//     </Dialog>
//   );
// };

// // ─── No Data Modal ───────────────────────────────────────────────────────
// const NoDataModal = ({ open, onClose, onSelectMonth }) => {
//   return (
//     <Dialog
//       open={open}
//       onClose={onClose}
//       maxWidth="xs"
//       fullWidth
//       PaperProps={{
//         style: {
//           borderRadius: Theme.borderRadius.xl,
//           width: '100%',
//           maxWidth: 400,
//           padding: '4px',
//           boxShadow: Theme.shadows.lg,
//         }
//       }}
//     >
//       <DialogContent className="p-6 text-center">
//         <div className="flex justify-end mb-2">
//           <IconButton size="small" onClick={onClose} className="p-1">
//             <CloseIcon className="text-lg" style={{ color: Theme.colors.text.secondary }} />
//           </IconButton>
//         </div>

//         <div className="w-[70px] h-[70px] rounded-[20px] mx-auto mb-4 flex items-center justify-center" style={{ background: Theme.colors.warning.light }}>
//           <WarningIcon className="text-3xl" style={{ color: Theme.colors.warning.main }} />
//         </div>

//         <h3 className="font-heading font-bold text-xl mb-2" style={{ color: Theme.colors.text.primary }}>
//           No Data Available
//         </h3>

//         <p className="text-sm mb-6 leading-relaxed" style={{ color: Theme.colors.text.secondary }}>
//           No booking data found for this month. Please select a different month.
//         </p>

//         <div className="flex gap-3">
//           <Button
//             fullWidth
//             variant="outlined"
//             onClick={onClose}
//             className="py-2.5 font-semibold"
//             style={{
//               color: Theme.colors.text.secondary,
//               borderColor: Theme.colors.border.main,
//               borderRadius: Theme.borderRadius.md,
//               textTransform: 'none',
//             }}
//           >
//             Close
//           </Button>
//           <Button
//             fullWidth
//             variant="contained"
//             onClick={onSelectMonth}
//             className="py-2.5 font-semibold"
//             style={{
//               background: Theme.colors.primary.main,
//               color: Theme.colors.common.white,
//               borderRadius: Theme.borderRadius.md,
//               textTransform: 'none',
//               boxShadow: Theme.shadows.md,
//             }}
//           >
//             Select Month
//           </Button>
//         </div>
//       </DialogContent>
//     </Dialog>
//   );
// };

// // ─── Main Component ──────────────────────────────────────────────────────
// export default function Analytics() {
//   const dispatch = useDispatch();
//   const theme = useTheme();
//   const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

//   // State for fetched data
//   const [analyticsData, setAnalyticsData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   // Local state
//   const [selectedMonthYear, setSelectedMonthYear] = useState(() => {
//     const now = new Date();
//     const year = now.getFullYear();
//     const month = String(now.getMonth() + 1).padStart(2, '0');
//     return `${year}-${month}`;
//   });
//   const [showMonthPicker, setShowMonthPicker] = useState(false);
//   const [showNoDataModal, setShowNoDataModal] = useState(false);
//   const [refreshing, setRefreshing] = useState(false);
//   const [hoveredCard, setHoveredCard] = useState(null);
//   const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

//   // Fetch data when month/year changes
//   const fetchAnalyticsData = async (year, month) => {
//     setLoading(true);
//     setError(null);

//     try {
//       console.log('📊 ========== FETCHING ANALYTICS DATA ==========');
//       console.log('📊 Request Parameters:', { year, month });

//       const result = await dispatch(getMonthlyAnalytics({ year, month }));

//       console.log('📊 API Response:', result);

//       if (result.payload?.success && result.payload?.data) {
//         const data = result.payload.data;
//         setAnalyticsData(data);

//         console.log('📊 ===== FETCHED DATA =====');
//         console.log('📊 Booking Count:', data.BookingCount);
//         console.log('📊 Average per day:', data.Avrage);
//         console.log('📊 Month:', data.monthName, data.year);
//         console.log('📊 Days in Month:', data.daysInMonth);
//         console.log('📊 Days with Bookings:', data.daysWithBookings);
//         console.log('📊 Vehicle Types:', data.VehicalType);
//         console.log('📊 Payment Methods:', data.PymentMethod);
//         console.log('📊 Peak Hours:', data.PeakHours);
//         console.log('📊 Revenue:', data.Revenue);
//         console.log('📊 Total Revenue:', data.totalRevenue);
//         console.log('📊 Vehicle Type Summary:', data.vehicleTypeSummary);
//         console.log('📊 ===== END FETCHED DATA =====');

//         if (data.BookingCount === 0) {
//           setShowNoDataModal(true);
//         }
//       } else if (result.error) {
//         setError(result.error);
//         setSnackbar({ open: true, message: result.error, severity: 'error' });
//         console.error('📊 API Error:', result.error);
//       }
//     } catch (err) {
//       console.error('📊 Fetch Error:', err);
//       setError('Failed to fetch analytics data');
//       setSnackbar({ open: true, message: 'Failed to fetch analytics data', severity: 'error' });
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   };

//   useEffect(() => {
//     const [year, month] = selectedMonthYear.split('-').map(Number);
//     fetchAnalyticsData(year, month);
//   }, [dispatch, selectedMonthYear]);

//   // Calculate stats from fetched data
//   const hasData = analyticsData && analyticsData.BookingCount > 0;

//   const peakDay = hasData && analyticsData.daysWithBookings?.length > 0
//     ? analyticsData.daysWithBookings.reduce((max, day) =>
//       day.bookingCount > max.bookingCount ? day : max,
//       { day: 0, bookingCount: 0 }
//     )
//     : { day: 0, bookingCount: 0 };

//   const totalDaysWithBookings = analyticsData?.daysWithBookings?.length || 0;
//   const bookingRate = analyticsData?.daysInMonth
//     ? ((totalDaysWithBookings / analyticsData.daysInMonth) * 100).toFixed(1)
//     : '0.0';

//   // Transform data for charts
//   const vehicleTypes = analyticsData?.VehicalType
//     ? Object.entries(analyticsData.VehicalType).map(([type, count], index) => ({
//       label: type === '2' ? '2-Wheeler' : type === '4' ? '4-Wheeler' : `${type}-Wheeler`,
//       value: count,
//       color: [Theme.colors.primary.main, Theme.colors.secondary.main, Theme.colors.success.main, '#8B5CF6'][index],
//       icon: type === '2' ? TwoWheelerIcon : type === '4' ? CarIcon : type === '17' ? TruckIcon : BusIcon,
//     }))
//     : [];

//   // Payment Methods Data
//   const paymentMethods = analyticsData?.PymentMethod
//     ? (() => {
//       let upiTotal = 0;
//       let cashTotal = 0;
//       Object.values(analyticsData.PymentMethod).forEach(week => {
//         if (week.UPI) upiTotal += week.UPI;
//         if (week.CASH) cashTotal += week.CASH;
//       });
//       return [
//         { label: 'UPI', value: upiTotal, color: '#8B5CF6' },
//         { label: 'Cash', value: cashTotal, color: '#10B981' },
//       ];
//     })()
//     : [];

//   // Daily Bookings Chart Data
//   const dailyChartData = {
//     labels: analyticsData?.daysWithBookings?.map(d => d.day.toString()) || [],
//     datasets: [
//       {
//         label: 'Bookings',
//         data: analyticsData?.daysWithBookings?.map(d => d.bookingCount) || [],
//         backgroundColor: analyticsData?.daysWithBookings?.map(d =>
//           d.bookingCount > 20 ? Theme.colors.success.main :
//             d.bookingCount > 15 ? Theme.colors.primary.main :
//               d.bookingCount > 10 ? Theme.colors.secondary.main : Theme.colors.error.main
//         ) || [],
//         borderRadius: 8,
//         borderSkipped: false,
//       },
//     ],
//   };

//   // Vehicle Types Chart Data
//   const vehicleChartData = {
//     labels: vehicleTypes.map(v => v.label),
//     datasets: [
//       {
//         data: vehicleTypes.map(v => v.value),
//         backgroundColor: vehicleTypes.map(v => v.color),
//         borderWidth: 0,
//       },
//     ],
//   };

//   // Payment Methods Chart Data
//   const paymentChartData = {
//     labels: paymentMethods.map(p => p.label),
//     datasets: [
//       {
//         label: 'Transactions',
//         data: paymentMethods.map(p => p.value),
//         backgroundColor: paymentMethods.map(p => p.color),
//         borderRadius: 8,
//       },
//     ],
//   };

//   const chartOptions = {
//     responsive: true,
//     maintainAspectRatio: false,
//     plugins: {
//       legend: { display: false },
//       tooltip: {
//         backgroundColor: Theme.colors.text.primary,
//         titleColor: Theme.colors.common.white,
//         bodyColor: Theme.colors.common.white,
//         padding: 12,
//         cornerRadius: 8,
//       },
//     },
//     scales: {
//       y: {
//         beginAtZero: true,
//         grid: { color: Theme.colors.border.light, drawBorder: false },
//         ticks: { stepSize: 5, color: Theme.colors.text.disabled },
//       },
//       x: {
//         grid: { display: false },
//         ticks: { color: Theme.colors.text.disabled },
//       },
//     },
//   };

//   const pieOptions = {
//     responsive: true,
//     maintainAspectRatio: false,
//     plugins: {
//       legend: { display: false },
//       tooltip: {
//         backgroundColor: Theme.colors.text.primary,
//         titleColor: Theme.colors.common.white,
//         bodyColor: Theme.colors.common.white,
//         padding: 12,
//         cornerRadius: 8,
//       },
//     },
//   };

//   const handleRefresh = () => {
//     setRefreshing(true);
//     const [year, month] = selectedMonthYear.split('-').map(Number);
//     fetchAnalyticsData(year, month);
//   };

//   const stats = [
//     {
//       id: 'bookings',
//       icon: TrendingUpIcon,
//       iconBg: Theme.colors.primary[50],
//       iconColor: Theme.colors.primary.main,
//       label: 'Total Bookings',
//       value: analyticsData?.BookingCount || 0,
//       trend: `${analyticsData?.Avrage?.toFixed(1) || 0} avg/day`,
//       trendUp: true,
//       subtitle: `${analyticsData?.BookingCount || 0} bookings`,
//     },
//     {
//       id: 'peak',
//       icon: TrophyIcon,
//       iconBg: Theme.colors.secondary[50],
//       iconColor: Theme.colors.secondary.main,
//       label: 'Peak Day',
//       value: peakDay?.bookingCount || 0,
//       trend: peakDay?.day ? `Day ${peakDay.day}` : 'No data',
//       trendUp: true,
//       subtitle: `${bookingRate}% active days`,
//     },
//     {
//       id: 'active',
//       icon: CheckCircleIcon,
//       iconBg: Theme.colors.success.light,
//       iconColor: Theme.colors.success.dark,
//       label: 'Active Days',
//       value: totalDaysWithBookings,
//       trend: `${analyticsData?.daysInMonth || 0} total days`,
//       trendUp: true,
//       subtitle: `${((totalDaysWithBookings / (analyticsData?.daysInMonth || 1)) * 100).toFixed(0)}% of month`,
//     },
//     {
//       id: 'types',
//       icon: PieChartIcon,
//       iconBg: '#f3e8ff',
//       iconColor: '#8B5CF6',
//       label: 'Vehicle Types',
//       value: vehicleTypes.length,
//       trend: `${vehicleTypes.length} categories`,
//       trendUp: true,
//       subtitle: 'active types',
//     },
//   ];

//   if (loading && !analyticsData) {
//     return (
//       <div className="min-h-screen flex items-center justify-center" style={{ background: Theme.colors.background.body }}>
//         <div className="text-center">
//           <CircularProgress size={60} thickness={4} style={{ color: Theme.colors.primary.main }} />
//           <p className="mt-4 text-sm" style={{ color: Theme.colors.text.secondary }}>Loading analytics data...</p>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen" style={{ background: Theme.colors.background.body, fontFamily: Theme.typography.fontFamily.body.join(',') }}>
//       <div className="max-w-7xl mx-auto px-6 py-8">

//         {/* ── Header Card ── */}
//         <div
//           className="relative overflow-hidden mb-8 p-8 rounded-2xl"
//           style={{
//             background: `linear-gradient(135deg, ${Theme.colors.primary.main}, ${Theme.colors.primary.dark})`,
//             boxShadow: Theme.shadows.lg,
//           }}
//         >
//           <div className="relative z-10 flex items-center justify-between">
//             <div className="flex items-center gap-4">
//               <div className="w-14 h-14 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-white/30" style={{ background: 'rgba(255,255,255,0.2)' }}>
//                 <AssessmentIcon className="text-3xl" style={{ color: Theme.colors.common.white }} />
//               </div>
//               <div>
//                 <h1 className="font-heading font-bold text-3xl mb-1" style={{ color: Theme.colors.common.white }}>
//                   Analytics Dashboard
//                 </h1>
//                 <p className="text-sm" style={{ color: 'rgba(255,255,255,0.8)' }}>
//                   {analyticsData?.monthName} {analyticsData?.year} • {analyticsData?.daysInMonth || 0} days
//                 </p>
//               </div>
//             </div>
//             <button
//               className="flex items-center gap-2 px-6 py-2.5 rounded-xl backdrop-blur-sm border border-white/30 transition-all hover:bg-white/10"
//               style={{ color: Theme.colors.common.white }}
//               onClick={() => setShowMonthPicker(true)}
//             >
//               <CalendarIcon className="text-lg" />
//               <span className="font-heading font-semibold text-sm">
//                 {new Date(`${selectedMonthYear}-01`).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
//               </span>
//               <ArrowDownIcon className="text-base" />
//             </button>
//           </div>
//         </div>

//         {/* ── Stats Grid ── */}
//         {hasData && (
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
//             {stats.map((stat) => {
//               const Icon = stat.icon;
//               const isHovered = hoveredCard === stat.id;

//               return (
//                 <div
//                   key={stat.id}
//                   className="bg-white rounded-2xl p-6 border transition-all cursor-pointer"
//                   style={{
//                     borderColor: isHovered ? Theme.colors.primary.main : Theme.colors.border.light,
//                     boxShadow: isHovered ? Theme.shadows.md : Theme.shadows.sm,
//                     transform: isHovered ? 'translateY(-4px)' : 'none',
//                   }}
//                   onMouseEnter={() => setHoveredCard(stat.id)}
//                   onMouseLeave={() => setHoveredCard(null)}
//                 >
//                   <div className="flex items-center gap-3 mb-4">
//                     <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: stat.iconBg }}>
//                       <Icon style={{ color: stat.iconColor, fontSize: 24 }} />
//                     </div>
//                     <span className="text-sm font-semibold" style={{ color: Theme.colors.text.secondary }}>{stat.label}</span>
//                   </div>
//                   <h3 className="text-3xl font-extrabold mb-1" style={{ color: Theme.colors.text.primary }}>{stat.value}</h3>
//                   <p className="text-xs font-medium" style={{ color: Theme.colors.text.hint }}>{stat.subtitle}</p>
//                   <div className="flex items-center gap-1 mt-3 pt-3 border-t" style={{ borderColor: Theme.colors.border.light }}>
//                     {stat.trendUp ? (
//                       <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: Theme.colors.success.main }}>
//                         <TrendingUpIcon className="text-sm" />
//                         {stat.trend}
//                       </span>
//                     ) : (
//                       <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: Theme.colors.error.main }}>
//                         <TrendingDownIcon className="text-sm" />
//                         {stat.trend}
//                       </span>
//                     )}
//                   </div>
//                 </div>
//               );
//             })}
//           </div>
//         )}

//         {/* No Data State */}
//         {!hasData && analyticsData && (
//           <div className="bg-white rounded-2xl p-12 mb-6 border text-center" style={{ borderColor: Theme.colors.border.light }}>
//             <WarningIcon style={{ fontSize: 48, color: Theme.colors.warning.main, marginBottom: 16 }} />
//             <h3 className="text-xl font-bold mb-2" style={{ color: Theme.colors.text.primary }}>No Data Available</h3>
//             <p className="text-sm" style={{ color: Theme.colors.text.secondary }}>
//               No booking data found for {analyticsData.monthName} {analyticsData.year}
//             </p>
//           </div>
//         )}

//         {/* ── Daily Bookings Chart ── */}
//         {hasData && dailyChartData.labels.length > 0 && (
//           <div className="bg-white rounded-2xl p-6 mb-6 border" style={{ borderColor: Theme.colors.border.light, boxShadow: Theme.shadows.sm }}>
//             <div className="flex items-center justify-between mb-5">
//               <div className="flex items-center gap-2.5">
//                 <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//                   <ShowChartIcon style={{ color: Theme.colors.primary.main, fontSize: 20 }} />
//                 </div>
//                 <h3 className="font-heading font-semibold text-lg" style={{ color: Theme.colors.text.primary }}>Daily Bookings Trend</h3>
//               </div>
//               <Badge badgeContent={analyticsData?.BookingCount || 0} color="primary" showZero>
//                 <Chip
//                   label={`Avg: ${analyticsData?.Avrage?.toFixed(1) || 0}`}
//                   size="small"
//                   className="font-semibold rounded-full"
//                   style={{ background: Theme.colors.primary[50], color: Theme.colors.primary.main }}
//                 />
//               </Badge>
//             </div>
//             <div className="h-[300px] w-full">
//               <Bar data={dailyChartData} options={chartOptions} />
//             </div>
//             <div className="flex justify-center gap-6 flex-wrap mt-5 pt-5 border-t" style={{ borderColor: Theme.colors.border.light }}>
//               <div className="flex items-center gap-2">
//                 <div className="w-2.5 h-2.5 rounded-sm" style={{ background: Theme.colors.error.main }} />
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Low (0-10)</span>
//               </div>
//               <div className="flex items-center gap-2">
//                 <div className="w-2.5 h-2.5 rounded-sm" style={{ background: Theme.colors.secondary.main }} />
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Medium (11-15)</span>
//               </div>
//               <div className="flex items-center gap-2">
//                 <div className="w-2.5 h-2.5 rounded-sm" style={{ background: Theme.colors.primary.main }} />
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>High (16-20)</span>
//               </div>
//               <div className="flex items-center gap-2">
//                 <div className="w-2.5 h-2.5 rounded-sm" style={{ background: Theme.colors.success.main }} />
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Very High (21+)</span>
//               </div>
//             </div>
//           </div>
//         )}

//         {/* ── Vehicle Type Distribution ── */}
//         {hasData && vehicleTypes.length > 0 && (
//           <div className="bg-white rounded-2xl p-6 mb-6 border" style={{ borderColor: Theme.colors.border.light, boxShadow: Theme.shadows.sm }}>
//             <div className="flex items-center justify-between mb-5">
//               <div className="flex items-center gap-2.5">
//                 <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//                   <CarIcon style={{ color: Theme.colors.primary.main, fontSize: 20 }} />
//                 </div>
//                 <h3 className="font-heading font-semibold text-lg" style={{ color: Theme.colors.text.primary }}>Vehicle Type Distribution</h3>
//               </div>
//               <Chip
//                 label={`Total: ${analyticsData?.BookingCount || 0}`}
//                 size="small"
//                 className="font-semibold rounded-full"
//                 style={{ background: Theme.colors.primary[50], color: Theme.colors.primary.main }}
//               />
//             </div>

//             <div className="flex flex-col lg:flex-row gap-8">
//               <div className="flex-1 min-w-[250px] h-[250px]">
//                 <Pie data={vehicleChartData} options={pieOptions} />
//               </div>
//               <div className="flex-1 min-w-[250px]">
//                 <div className="flex flex-col gap-3">
//                   {vehicleTypes.map((item, index) => {
//                     const Icon = item.icon;
//                     const percentage = analyticsData?.BookingCount
//                       ? ((item.value / analyticsData.BookingCount) * 100).toFixed(1)
//                       : '0';

//                     return (
//                       <div key={index} className="flex items-center justify-between py-3 border-b last:border-0" style={{ borderColor: Theme.colors.border.light }}>
//                         <div className="flex items-center gap-3">
//                           <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${item.color}15` }}>
//                             <Icon style={{ color: item.color, fontSize: 18 }} />
//                           </div>
//                           <span className="text-sm font-semibold" style={{ color: Theme.colors.text.primary }}>{item.label}</span>
//                         </div>
//                         <div className="flex items-center gap-4">
//                           <span className="text-sm font-bold" style={{ color: Theme.colors.text.primary }}>{item.value}</span>
//                           <span className="text-xs px-2 py-1 rounded-full" style={{ background: Theme.colors.neutral[100], color: Theme.colors.text.disabled }}>
//                             {percentage}%
//                           </span>
//                         </div>
//                       </div>
//                     );
//                   })}
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}

//         {/* ── Two Column Layout for Payment Methods and Monthly Summary ── */}
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
//           {/* Payment Methods */}
//           {hasData && paymentMethods.length > 0 && (
//             <div className="bg-white rounded-2xl p-6 border" style={{ borderColor: Theme.colors.border.light, boxShadow: Theme.shadows.sm }}>
//               <div className="flex items-center justify-between mb-5">
//                 <div className="flex items-center gap-2.5">
//                   <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//                     <CreditCardIcon style={{ color: Theme.colors.primary.main, fontSize: 20 }} />
//                   </div>
//                   <h3 className="font-heading font-semibold text-lg" style={{ color: Theme.colors.text.primary }}>Payment Methods</h3>
//                 </div>
//                 <Chip
//                   label={`${paymentMethods.reduce((sum, p) => sum + p.value, 0)} transactions`}
//                   size="small"
//                   className="font-semibold rounded-full"
//                   style={{ background: '#f3e8ff', color: '#8B5CF6' }}
//                 />
//               </div>
//               <div className="h-[250px] w-full">
//                 <Bar data={paymentChartData} options={chartOptions} />
//               </div>
//             </div>
//           )}

//           {/* Monthly Summary */}
//           <div className="bg-white rounded-2xl p-6 border" style={{ borderColor: Theme.colors.border.light, boxShadow: Theme.shadows.sm }}>
//             <div className="flex items-center justify-between mb-5">
//               <div className="flex items-center gap-2.5">
//                 <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//                   <AssessmentIcon style={{ color: Theme.colors.primary.main, fontSize: 20 }} />
//                 </div>
//                 <h3 className="font-heading font-semibold text-lg" style={{ color: Theme.colors.text.primary }}>Monthly Summary</h3>
//               </div>
//               <Chip
//                 label={`${analyticsData?.monthName || ''} ${analyticsData?.year || ''}`}
//                 size="small"
//                 className="font-semibold rounded-full"
//                 style={{ background: Theme.colors.primary[50], color: Theme.colors.primary.main }}
//               />
//             </div>

//             <div className="grid grid-cols-2 gap-3 mt-3">
//               <div className="p-4 text-center rounded-xl border" style={{ background: Theme.colors.background.body, borderColor: Theme.colors.border.light }}>
//                 <h4 className="text-2xl font-extrabold mb-1" style={{ color: Theme.colors.primary.main }}>{analyticsData?.BookingCount || 0}</h4>
//                 <p className="text-xs" style={{ color: Theme.colors.text.disabled }}>Total Bookings</p>
//               </div>
//               <div className="p-4 text-center rounded-xl border" style={{ background: Theme.colors.background.body, borderColor: Theme.colors.border.light }}>
//                 <h4 className="text-2xl font-extrabold mb-1" style={{ color: Theme.colors.primary.main }}>{analyticsData?.Avrage?.toFixed(1) || 0}</h4>
//                 <p className="text-xs" style={{ color: Theme.colors.text.disabled }}>Daily Avg</p>
//               </div>
//               <div className="p-4 text-center rounded-xl border" style={{ background: Theme.colors.background.body, borderColor: Theme.colors.border.light }}>
//                 <h4 className="text-2xl font-extrabold mb-1" style={{ color: Theme.colors.primary.main }}>{totalDaysWithBookings}</h4>
//                 <p className="text-xs" style={{ color: Theme.colors.text.disabled }}>Active Days</p>
//               </div>
//               <div className="p-4 text-center rounded-xl border" style={{ background: Theme.colors.background.body, borderColor: Theme.colors.border.light }}>
//                 <h4 className="text-2xl font-extrabold mb-1" style={{ color: Theme.colors.primary.main }}>{vehicleTypes.length}</h4>
//                 <p className="text-xs" style={{ color: Theme.colors.text.disabled }}>Vehicle Types</p>
//               </div>
//             </div>

//             {/* Additional Stats */}
//             <div className="mt-4 pt-4 border-t" style={{ borderColor: Theme.colors.border.light }}>
//               <div className="flex justify-between items-center mb-2">
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Days in Month</span>
//                 <span className="text-sm font-semibold" style={{ color: Theme.colors.text.primary }}>{analyticsData?.daysInMonth || 0} days</span>
//               </div>
//               <div className="flex justify-between items-center mb-2">
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Active Days</span>
//                 <span className="text-sm font-semibold" style={{ color: Theme.colors.text.primary }}>{totalDaysWithBookings} days</span>
//               </div>
//               <div className="flex justify-between items-center">
//                 <span className="text-xs" style={{ color: Theme.colors.text.hint }}>Utilization Rate</span>
//                 <span className="text-sm font-semibold" style={{ color: Theme.colors.success.main }}>{bookingRate}%</span>
//               </div>
//             </div>
//           </div>
//         </div>

//         {/* ── Top Performing Days ── */}
//         {hasData && analyticsData?.daysWithBookings?.length > 0 && (
//           <div className="bg-white rounded-2xl p-6 mb-6 border" style={{ borderColor: Theme.colors.border.light, boxShadow: Theme.shadows.sm }}>
//             <div className="flex items-center justify-between mb-5">
//               <div className="flex items-center gap-2.5">
//                 <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: Theme.colors.primary[50] }}>
//                   <TrophyIcon style={{ color: Theme.colors.primary.main, fontSize: 20 }} />
//                 </div>
//                 <h3 className="font-heading font-semibold text-lg" style={{ color: Theme.colors.text.primary }}>Top Performing Days</h3>
//               </div>
//               <Badge badgeContent="Peak" color="warning">
//                 <Chip
//                   label={`Day ${peakDay?.day || 0} • ${peakDay?.bookingCount || 0} bookings`}
//                   size="small"
//                   className="font-semibold rounded-full"
//                   style={{ background: Theme.colors.secondary[50], color: Theme.colors.secondary.main }}
//                 />
//               </Badge>
//             </div>

//             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
//               {[...(analyticsData?.daysWithBookings || [])]
//                 .sort((a, b) => b.bookingCount - a.bookingCount)
//                 .slice(0, 5)
//                 .map((day, index) => {
//                   const colors = [Theme.colors.success.main, Theme.colors.primary.main, '#8B5CF6', Theme.colors.secondary.main, Theme.colors.error.main];
//                   const progressPercentage = peakDay?.bookingCount ? (day.bookingCount / peakDay.bookingCount) * 100 : 0;

//                   return (
//                     <div key={index} className="p-4 text-center rounded-2xl border" style={{ borderColor: Theme.colors.border.light }}>
//                       <div className="w-7 h-7 rounded-full mx-auto mb-3 flex items-center justify-center text-xs font-bold text-white" style={{ background: colors[index] }}>
//                         #{index + 1}
//                       </div>
//                       <h4 className="text-sm font-semibold mb-2" style={{ color: Theme.colors.text.primary }}>Day {day.day}</h4>
//                       <p className="text-2xl font-extrabold mb-3" style={{ color: Theme.colors.text.primary }}>{day.bookingCount}</p>
//                       <div className="w-full h-1 rounded-full overflow-hidden mb-2" style={{ background: Theme.colors.border.light }}>
//                         <div className="h-full rounded-full" style={{ width: `${progressPercentage}%`, background: colors[index] }} />
//                       </div>
//                       <span className="text-xs font-semibold" style={{ color: colors[index] }}>
//                         {progressPercentage.toFixed(0)}% of peak
//                       </span>
//                     </div>
//                   );
//                 })}
//             </div>
//           </div>
//         )}
//       </div>

//       {/* Modals */}
//       <MonthPickerModal
//         open={showMonthPicker}
//         onClose={() => setShowMonthPicker(false)}
//         selectedMonthYear={selectedMonthYear}
//         onSelect={setSelectedMonthYear}
//       />

//       <NoDataModal
//         open={showNoDataModal}
//         onClose={() => setShowNoDataModal(false)}
//         onSelectMonth={() => {
//           setShowNoDataModal(false);
//           setShowMonthPicker(true);
//         }}
//       />

//       {/* Snackbar */}
//       <Snackbar
//         open={snackbar.open}
//         autoHideDuration={3000}
//         onClose={() => setSnackbar({ ...snackbar, open: false })}
//         anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
//       >
//         <Alert
//           onClose={() => setSnackbar({ ...snackbar, open: false })}
//           severity={snackbar.severity}
//           sx={{ borderRadius: 2 }}
//         >
//           {snackbar.message}
//         </Alert>
//       </Snackbar>
//     </div>
//   );
// }

import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Chip,
  CircularProgress,
  Alert,
  Snackbar,
  Badge,
  IconButton,
  Button,
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  CalendarToday as CalendarIcon,
  DirectionsCar as CarIcon,
  CreditCard as CreditCardIcon,
  WarningAmber as WarningIcon,
  Refresh as RefreshIcon,
  KeyboardArrowDown as ArrowDownIcon,
  TwoWheeler as TwoWheelerIcon,
  DirectionsBus as BusIcon,
  LocalShipping as TruckIcon,
  Assessment as AssessmentIcon,
  PieChart as PieChartIcon,
  ShowChart as ShowChartIcon,
  Close as CloseIcon,
  EmojiEvents as TrophyIcon,
  CheckCircle as CheckCircleIcon,
} from '@mui/icons-material';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';

import { getMonthlyAnalytics } from '../../../redux/slice/analyticsSlice';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, ChartTooltip, Legend, ArcElement);

// ─── Month Picker Modal ──────────────────────────────────────────────────
const MonthPickerModal = ({ open, onClose, selectedMonthYear, onSelect }) => {
  const currentYear = new Date().getFullYear();
  const lastYear = currentYear - 1;
  const [selectedYear, setSelectedYear] = useState(currentYear);

  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  const handleMonthSelect = (monthNumber) => {
    const formattedMonth = monthNumber.toString().padStart(2, '0');
    onSelect(`${selectedYear}-${formattedMonth}`);
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{ style: { borderRadius: '20px', maxWidth: 400, padding: '4px' } }}
    >
      <DialogTitle className="pb-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
              <CalendarIcon sx={{ color: '#1a3c5e', fontSize: 20 }} />
            </div>
            <span className="font-bold text-lg text-[#1a3c5e]">Select Month</span>
          </div>
          <IconButton size="small" onClick={onClose}>
            <CloseIcon sx={{ fontSize: 18, color: '#9ca3af' }} />
          </IconButton>
        </div>
      </DialogTitle>
      <DialogContent className="pt-4">
        <div className="flex justify-center gap-3 mb-5">
          {[lastYear, currentYear].map((yr) => (
            <button
              key={yr}
              onClick={() => setSelectedYear(yr)}
              className={`flex-1 py-2 text-sm font-semibold rounded-xl border transition-all ${
                selectedYear === yr
                  ? 'bg-[#1a3c5e] text-white border-[#1a3c5e]'
                  : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
              }`}
            >
              {yr}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 pb-2">
          {MONTHS.map((month, index) => {
            const monthNumber = index + 1;
            const formattedMonth = monthNumber.toString().padStart(2, '0');
            const isSelected = selectedMonthYear === `${selectedYear}-${formattedMonth}`;
            return (
              <button
                key={index}
                onClick={() => handleMonthSelect(monthNumber)}
                className={`py-2.5 text-sm font-semibold rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-[#1a3c5e] text-white border-[#1a3c5e]'
                    : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                }`}
              >
                {month}
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
};

// ─── No Data Modal ───────────────────────────────────────────────────────
const NoDataModal = ({ open, onClose, onSelectMonth }) => (
  <Dialog
    open={open}
    onClose={onClose}
    maxWidth="xs"
    fullWidth
    PaperProps={{ style: { borderRadius: '20px', maxWidth: 380, padding: '4px' } }}
  >
    <DialogContent className="p-6 text-center">
      <div className="flex justify-end mb-2">
        <IconButton size="small" onClick={onClose}>
          <CloseIcon sx={{ fontSize: 18, color: '#9ca3af' }} />
        </IconButton>
      </div>
      <div className="w-16 h-16 rounded-2xl mx-auto mb-4 bg-amber-50 flex items-center justify-center">
        <WarningIcon sx={{ fontSize: 32, color: '#f59e0b' }} />
      </div>
      <h3 className="font-bold text-xl mb-2 text-gray-800">No Data Available</h3>
      <p className="text-sm mb-6 text-gray-500 leading-relaxed">
        No booking data found for this month. Please select a different month.
      </p>
      <div className="flex gap-3">
        <button
          onClick={onClose}
          className="flex-1 py-2.5 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all text-sm"
        >
          Close
        </button>
        <button
          onClick={onSelectMonth}
          className="flex-1 py-2.5 bg-[#1a3c5e] text-white rounded-xl font-semibold hover:bg-[#0f2a44] transition-all text-sm shadow-sm"
        >
          Select Month
        </button>
      </div>
    </DialogContent>
  </Dialog>
);

// ─── Main Component ──────────────────────────────────────────────────────
export default function Analytics() {
  const dispatch = useDispatch();

  const [analyticsData, setAnalyticsData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedMonthYear, setSelectedMonthYear] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [showMonthPicker, setShowMonthPicker] = useState(false);
  const [showNoDataModal, setShowNoDataModal] = useState(false);
  const [hoveredCard, setHoveredCard] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const fetchAnalyticsData = async (year, month) => {
    setLoading(true);
    setError(null);
    try {
      const result = await dispatch(getMonthlyAnalytics({ year, month }));
      if (result.payload?.success && result.payload?.data) {
        const data = result.payload.data;
        setAnalyticsData(data);
        if (data.BookingCount === 0) setShowNoDataModal(true);
      } else if (result.error) {
        setError(result.error);
        setSnackbar({ open: true, message: result.error, severity: 'error' });
      }
    } catch (err) {
      setError('Failed to fetch analytics data');
      setSnackbar({ open: true, message: 'Failed to fetch analytics data', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const [year, month] = selectedMonthYear.split('-').map(Number);
    fetchAnalyticsData(year, month);
  }, [dispatch, selectedMonthYear]);

  const hasData = analyticsData && analyticsData.BookingCount > 0;

  const peakDay = hasData && analyticsData.daysWithBookings?.length > 0
    ? analyticsData.daysWithBookings.reduce((max, day) =>
        day.bookingCount > max.bookingCount ? day : max,
        { day: 0, bookingCount: 0 }
      )
    : { day: 0, bookingCount: 0 };

  const totalDaysWithBookings = analyticsData?.daysWithBookings?.length || 0;
  const bookingRate = analyticsData?.daysInMonth
    ? ((totalDaysWithBookings / analyticsData.daysInMonth) * 100).toFixed(1)
    : '0.0';

  const vehicleTypes = analyticsData?.VehicalType
    ? Object.entries(analyticsData.VehicalType).map(([type, count], index) => ({
        label: type === '2' ? '2-Wheeler' : type === '4' ? '4-Wheeler' : `${type}-Wheeler`,
        value: count,
        color: ['#1a3c5e', '#2563eb', '#10b981', '#8b5cf6'][index % 4],
        icon: type === '2' ? TwoWheelerIcon : type === '4' ? CarIcon : type === '17' ? TruckIcon : BusIcon,
      }))
    : [];

  const paymentMethods = analyticsData?.PymentMethod
    ? (() => {
        let upiTotal = 0, cashTotal = 0;
        Object.values(analyticsData.PymentMethod).forEach(week => {
          if (week.UPI) upiTotal += week.UPI;
          if (week.CASH) cashTotal += week.CASH;
        });
        return [
          { label: 'UPI', value: upiTotal, color: '#6366f1' },
          { label: 'Cash', value: cashTotal, color: '#10b981' },
        ];
      })()
    : [];

  const dailyChartData = {
    labels: analyticsData?.daysWithBookings?.map(d => d.day.toString()) || [],
    datasets: [{
      label: 'Bookings',
      data: analyticsData?.daysWithBookings?.map(d => d.bookingCount) || [],
      backgroundColor: analyticsData?.daysWithBookings?.map(d =>
        d.bookingCount > 20 ? '#10b981' :
        d.bookingCount > 15 ? '#1a3c5e' :
        d.bookingCount > 10 ? '#3b82f6' : '#ef4444'
      ) || [],
      borderRadius: 8,
      borderSkipped: false,
    }],
  };

  const vehicleChartData = {
    labels: vehicleTypes.map(v => v.label),
    datasets: [{
      data: vehicleTypes.map(v => v.value),
      backgroundColor: vehicleTypes.map(v => v.color),
      borderWidth: 0,
    }],
  };

  const paymentChartData = {
    labels: paymentMethods.map(p => p.label),
    datasets: [{
      label: 'Transactions',
      data: paymentMethods.map(p => p.value),
      backgroundColor: paymentMethods.map(p => p.color),
      borderRadius: 8,
    }],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1a3c5e',
        titleColor: '#fff',
        bodyColor: '#fff',
        padding: 12,
        cornerRadius: 8,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: '#f1f5f9', drawBorder: false },
        ticks: { stepSize: 5, color: '#9ca3af' },
      },
      x: {
        grid: { display: false },
        ticks: { color: '#9ca3af' },
      },
    },
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1a3c5e',
        titleColor: '#fff',
        bodyColor: '#fff',
        padding: 12,
        cornerRadius: 8,
      },
    },
  };

  const stats = [
    {
      id: 'bookings',
      icon: TrendingUpIcon,
      iconBg: '#e8eef4',
      iconColor: '#1a3c5e',
      label: 'Total Bookings',
      value: analyticsData?.BookingCount || 0,
      trend: `${analyticsData?.Avrage?.toFixed(1) || 0} avg/day`,
      trendUp: true,
      subtitle: 'Completed transactions',
    },
    {
      id: 'peak',
      icon: TrophyIcon,
      iconBg: '#fef3c7',
      iconColor: '#d97706',
      label: 'Peak Day',
      value: peakDay?.bookingCount || 0,
      trend: peakDay?.day ? `Day ${peakDay.day}` : 'No data',
      trendUp: true,
      subtitle: `${bookingRate}% active days`,
    },
    {
      id: 'active',
      icon: CheckCircleIcon,
      iconBg: '#d1fae5',
      iconColor: '#059669',
      label: 'Active Days',
      value: totalDaysWithBookings,
      trend: `${analyticsData?.daysInMonth || 0} total days`,
      trendUp: true,
      subtitle: `${((totalDaysWithBookings / (analyticsData?.daysInMonth || 1)) * 100).toFixed(0)}% of month`,
    },
    {
      id: 'types',
      icon: PieChartIcon,
      iconBg: '#ede9fe',
      iconColor: '#7c3aed',
      label: 'Vehicle Types',
      value: vehicleTypes.length,
      trend: `${vehicleTypes.length} categories`,
      trendUp: true,
      subtitle: 'Active types',
    },
  ];

  if (loading && !analyticsData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#1a3c5e] flex items-center justify-center animate-bounce shadow-lg">
            <AssessmentIcon sx={{ fontSize: 26, color: '#fff' }} />
          </div>
          <p className="text-sm text-gray-400 animate-pulse font-medium">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (error && !analyticsData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="text-center p-8 bg-white rounded-2xl shadow border border-red-100 max-w-sm mx-4">
          <div className="w-12 h-12 mx-auto rounded-xl bg-red-50 flex items-center justify-center mb-3">
            <WarningIcon sx={{ fontSize: 26, color: '#ef4444' }} />
          </div>
          <p className="font-semibold text-gray-800">Error loading analytics</p>
          <p className="text-sm text-gray-400 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @media (max-width: 640px) {
          .hide-on-mobile { display: none; }
        }
      `}</style>

      <div
        className="min-h-screen bg-[#f1f4f8] px-4 py-4 sm:px-6 lg:px-8"
        style={{ animation: 'fadeIn 0.25s ease' }}
      >
        <div className="max-w-screen-xl mx-auto space-y-4 sm:space-y-5">

          {/* ── Header ── */}
          <div
            className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4"
            style={{ animation: 'fadeSlideUp 0.35s ease both' }}
          >
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-[#1a3c5e] tracking-tight leading-tight">
                Analytics Dashboard
              </h1>
              {analyticsData?.monthName && (
                <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
                  {analyticsData.monthName} {analyticsData.year} • {analyticsData.daysInMonth || 0} days
                </p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const [year, month] = selectedMonthYear.split('-').map(Number);
                  fetchAnalyticsData(year, month);
                }}
                className="p-1.5 sm:p-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-500 transition-all shadow-sm"
                title="Refresh"
              >
                <RefreshIcon sx={{ fontSize: { xs: 18, sm: 20 } }} />
              </button>

              <button
                onClick={() => setShowMonthPicker(true)}
                className="flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-[#1a3c5e] text-white text-xs sm:text-sm font-semibold hover:bg-[#0f2a44] transition-all shadow-sm"
              >
                <CalendarIcon sx={{ fontSize: { xs: 16, sm: 18 } }} />
                <span>
                  {new Date(`${selectedMonthYear}-01`).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                </span>
                <ArrowDownIcon sx={{ fontSize: { xs: 14, sm: 16 } }} />
              </button>
            </div>
          </div>

          {/* ── Stats Cards ── */}
          {hasData && (
            <div
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
              style={{ animation: 'fadeSlideUp 0.4s ease both' }}
            >
              {stats.map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <div
                    key={stat.id}
                    className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 p-4 sm:p-5 shadow-sm transition-all duration-300 cursor-default hover:-translate-y-0.5 hover:shadow-md"
                    style={{ animationDelay: `${i * 60}ms` }}
                    onMouseEnter={() => setHoveredCard(stat.id)}
                    onMouseLeave={() => setHoveredCard(null)}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ background: stat.iconBg }}
                      >
                        <Icon style={{ color: stat.iconColor, fontSize: 20 }} />
                      </div>
                      <span className="text-xs sm:text-sm text-gray-500 font-medium">{stat.label}</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-extrabold text-[#1a3c5e] mb-1">{stat.value}</p>
                    <p className="text-xs text-gray-400">{stat.subtitle}</p>
                    <div className="flex items-center gap-1 mt-3 pt-3 border-t border-gray-100">
                      {stat.trendUp ? (
                        <span className="flex items-center gap-1 text-xs font-semibold text-green-600">
                          <TrendingUpIcon sx={{ fontSize: 14 }} />
                          {stat.trend}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs font-semibold text-red-500">
                          <TrendingDownIcon sx={{ fontSize: 14 }} />
                          {stat.trend}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* No Data State */}
          {!hasData && analyticsData && (
            <div
              className="flex flex-col items-center justify-center py-16 sm:py-24 bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm text-center"
              style={{ animation: 'fadeSlideUp 0.4s ease both' }}
            >
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-amber-50 flex items-center justify-center mb-4">
                <WarningIcon sx={{ fontSize: { xs: 28, sm: 34 }, color: '#f59e0b' }} />
              </div>
              <p className="text-base sm:text-lg font-bold text-gray-700">No Data Available</p>
              <p className="text-xs sm:text-sm text-gray-400 mt-1">
                No booking data found for {analyticsData.monthName} {analyticsData.year}
              </p>
              <button
                onClick={() => setShowMonthPicker(true)}
                className="mt-4 px-4 py-2 text-sm font-semibold rounded-xl bg-[#1a3c5e] text-white hover:bg-[#0f2a44] transition-all shadow-sm"
              >
                Select Another Month
              </button>
            </div>
          )}

          {/* ── Daily Bookings Chart ── */}
          {hasData && dailyChartData.labels.length > 0 && (
            <div
              className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6"
              style={{ animation: 'fadeSlideUp 0.45s ease both' }}
            >
              <div className="flex items-center justify-between mb-4 sm:mb-5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
                    <ShowChartIcon sx={{ color: '#1a3c5e', fontSize: { xs: 18, sm: 20 } }} />
                  </div>
                  <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">Daily Bookings Trend</h3>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#e8eef4] text-[#1a3c5e]">
                  Avg: {analyticsData?.Avrage?.toFixed(1) || 0}/day
                </span>
              </div>

              <div className="h-[240px] sm:h-[300px] w-full">
                <Bar data={dailyChartData} options={chartOptions} />
              </div>

              <div className="flex justify-center gap-4 sm:gap-6 flex-wrap mt-4 sm:mt-5 pt-4 sm:pt-5 border-t border-gray-100">
                {[
                  { color: '#ef4444', label: 'Low (0–10)' },
                  { color: '#3b82f6', label: 'Medium (11–15)' },
                  { color: '#1a3c5e', label: 'High (16–20)' },
                  { color: '#10b981', label: 'Very High (21+)' },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ background: item.color }} />
                    <span className="text-xs text-gray-400">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Vehicle Type Distribution ── */}
          {hasData && vehicleTypes.length > 0 && (
            <div
              className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6"
              style={{ animation: 'fadeSlideUp 0.5s ease both' }}
            >
              <div className="flex items-center justify-between mb-4 sm:mb-5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
                    <CarIcon sx={{ color: '#1a3c5e', fontSize: { xs: 18, sm: 20 } }} />
                  </div>
                  <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">Vehicle Type Distribution</h3>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#e8eef4] text-[#1a3c5e]">
                  Total: {analyticsData?.BookingCount || 0}
                </span>
              </div>

              <div className="flex flex-col lg:flex-row gap-6 sm:gap-8">
                <div className="flex-1 min-w-[220px] h-[220px] sm:h-[250px]">
                  <Pie data={vehicleChartData} options={pieOptions} />
                </div>
                <div className="flex-1 min-w-[220px]">
                  {vehicleTypes.map((item, index) => {
                    const Icon = item.icon;
                    const percentage = analyticsData?.BookingCount
                      ? ((item.value / analyticsData.BookingCount) * 100).toFixed(1)
                      : '0';
                    return (
                      <div
                        key={index}
                        className="flex items-center justify-between py-3 border-b last:border-0 border-gray-100"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center"
                            style={{ background: `${item.color}18` }}
                          >
                            <Icon style={{ color: item.color, fontSize: 18 }} />
                          </div>
                          <span className="text-sm font-semibold text-gray-800">{item.label}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-[#1a3c5e]">{item.value}</span>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">
                            {percentage}%
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ── Payment Methods + Monthly Summary ── */}
          <div
            className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4"
            style={{ animation: 'fadeSlideUp 0.55s ease both' }}
          >
            {/* Payment Methods */}
            {hasData && paymentMethods.length > 0 && (
              <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6">
                <div className="flex items-center justify-between mb-4 sm:mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
                      <CreditCardIcon sx={{ color: '#1a3c5e', fontSize: { xs: 18, sm: 20 } }} />
                    </div>
                    <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">Payment Methods</h3>
                  </div>
                  <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-50 text-indigo-600">
                    {paymentMethods.reduce((sum, p) => sum + p.value, 0)} txns
                  </span>
                </div>
                <div className="h-[220px] sm:h-[250px] w-full">
                  <Bar data={paymentChartData} options={chartOptions} />
                </div>
              </div>
            )}

            {/* Monthly Summary */}
            <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4 sm:mb-5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
                    <AssessmentIcon sx={{ color: '#1a3c5e', fontSize: { xs: 18, sm: 20 } }} />
                  </div>
                  <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">Monthly Summary</h3>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#e8eef4] text-[#1a3c5e]">
                  {analyticsData?.monthName || ''} {analyticsData?.year || ''}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                {[
                  { label: 'Total Bookings', value: analyticsData?.BookingCount || 0 },
                  { label: 'Daily Avg', value: analyticsData?.Avrage?.toFixed(1) || 0 },
                  { label: 'Active Days', value: totalDaysWithBookings },
                  { label: 'Vehicle Types', value: vehicleTypes.length },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="p-3 sm:p-4 text-center rounded-xl border border-gray-100 bg-[#f8fafc]"
                  >
                    <p className="text-xl sm:text-2xl font-extrabold text-[#1a3c5e] mb-1">{item.value}</p>
                    <p className="text-xs text-gray-400">{item.label}</p>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-gray-100 space-y-2">
                {[
                  { label: 'Days in Month', value: `${analyticsData?.daysInMonth || 0} days` },
                  { label: 'Active Days', value: `${totalDaysWithBookings} days` },
                  { label: 'Utilization Rate', value: `${bookingRate}%`, highlight: true },
                ].map((row) => (
                  <div key={row.label} className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">{row.label}</span>
                    <span
                      className={`text-sm font-semibold ${row.highlight ? 'text-green-600' : 'text-gray-700'}`}
                    >
                      {row.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── Top Performing Days ── */}
          {hasData && analyticsData?.daysWithBookings?.length > 0 && (
            <div
              className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6"
              style={{ animation: 'fadeSlideUp 0.6s ease both' }}
            >
              <div className="flex items-center justify-between mb-4 sm:mb-5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
                    <TrophyIcon sx={{ color: '#1a3c5e', fontSize: { xs: 18, sm: 20 } }} />
                  </div>
                  <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">Top Performing Days</h3>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-amber-50 text-amber-600">
                  Peak: Day {peakDay?.day || 0} • {peakDay?.bookingCount || 0} bookings
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                {[...(analyticsData?.daysWithBookings || [])]
                  .sort((a, b) => b.bookingCount - a.bookingCount)
                  .slice(0, 5)
                  .map((day, index) => {
                    const colors = ['#10b981', '#1a3c5e', '#7c3aed', '#f59e0b', '#ef4444'];
                    const progressPercentage = peakDay?.bookingCount
                      ? (day.bookingCount / peakDay.bookingCount) * 100
                      : 0;
                    return (
                      <div
                        key={index}
                        className="p-4 text-center rounded-xl border border-gray-100 hover:shadow-sm transition-all duration-200"
                        style={{ animation: `fadeSlideUp 0.4s ease both`, animationDelay: `${index * 60}ms` }}
                      >
                        <div
                          className="w-7 h-7 rounded-full mx-auto mb-3 flex items-center justify-center text-xs font-bold text-white"
                          style={{ background: colors[index] }}
                        >
                          #{index + 1}
                        </div>
                        <p className="text-xs font-semibold text-gray-500 mb-1">Day {day.day}</p>
                        <p className="text-2xl font-extrabold text-[#1a3c5e] mb-3">{day.bookingCount}</p>
                        <div className="w-full h-1.5 rounded-full overflow-hidden bg-gray-100 mb-2">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${progressPercentage}%`, background: colors[index] }}
                          />
                        </div>
                        <span className="text-xs font-semibold" style={{ color: colors[index] }}>
                          {progressPercentage.toFixed(0)}% of peak
                        </span>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Modals */}
      <MonthPickerModal
        open={showMonthPicker}
        onClose={() => setShowMonthPicker(false)}
        selectedMonthYear={selectedMonthYear}
        onSelect={setSelectedMonthYear}
      />

      <NoDataModal
        open={showNoDataModal}
        onClose={() => setShowNoDataModal(false)}
        onSelectMonth={() => {
          setShowNoDataModal(false);
          setShowMonthPicker(true);
        }}
      />

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert severity={snackbar.severity} sx={{ borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

