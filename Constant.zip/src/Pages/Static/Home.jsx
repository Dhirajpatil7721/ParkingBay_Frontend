// src/Pages/Static/Home.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  Clock, 
  CreditCard, 
  MapPin, 
  Star, 
  ChevronRight,
  Car,
  Smartphone,
  Users
} from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: <Clock className="w-8 h-8" />,
      title: 'Real-time Availability',
      description: 'Check parking space availability in real-time and book instantly.'
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Secure Parking',
      description: 'All parking locations are secure with 24/7 surveillance.'
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: 'Easy Payment',
      description: 'Multiple payment options including cards, UPI, and wallets.'
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: 'Multiple Locations',
      description: 'Find parking spots across 100+ locations in the city.'
    },
  ];

  const steps = [
    {
      number: '01',
      title: 'Find Parking',
      description: 'Search for available parking spots near your destination.'
    },
    {
      number: '02',
      title: 'Book Slot',
      description: 'Select your preferred time slot and book instantly.'
    },
    {
      number: '03',
      title: 'Pay Online',
      description: 'Secure online payment with multiple options.'
    },
    {
      number: '04',
      title: 'Park & Go',
      description: 'Scan QR code at entry and enjoy hassle-free parking.'
    },
  ];

  const testimonials = [
    {
      name: 'John Smith',
      role: 'Regular Customer',
      content: 'ParkingWeb has made my daily commute so much easier. No more circling around for parking!',
      rating: 5,
      image: 'https://i.pravatar.cc/100?img=1'
    },
    {
      name: 'Sarah Johnson',
      role: 'Business Professional',
      content: 'The best parking solution in town. Reliable, secure, and great customer service.',
      rating: 5,
      image: 'https://i.pravatar.cc/100?img=2'
    },
    {
      name: 'Mike Wilson',
      role: 'Frequent Traveler',
      content: 'I use ParkingWeb at the airport every time. Never disappointed with their service.',
      rating: 5,
      image: 'https://i.pravatar.cc/100?img=3'
    },
  ];

  return (
    <div className="font-body">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-50 to-secondary-50 pt-20 pb-16 md:pt-28 md:pb-24 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-secondary-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
        </div>

        <div className="container-custom relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-right">
              <h1 className="font-heading font-bold text-4xl md:text-5xl lg:text-6xl leading-tight mb-6">
                Find & Book Parking{' '}
                <span className="text-primary-600">Spots</span>{' '}
                <span className="text-secondary-500">Instantly</span>
              </h1>
              <p className="text-text-secondary text-lg mb-8 max-w-lg">
                Never waste time finding parking again. Book your spot in advance and enjoy a stress-free parking experience.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link to="/find-parking" className="btn-primary">
                  Find Parking Now
                </Link>
                <Link to="/how-it-works" className="btn-outline">
                  How It Works
                </Link>
              </div>

              <div className="flex items-center gap-8 mt-12">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <img
                      key={i}
                      src={`https://i.pravatar.cc/40?img=${i}`}
                      alt="User"
                      className="w-10 h-10 rounded-full border-2 border-white"
                    />
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-secondary-500 text-secondary-500" />
                    ))}
                  </div>
                  <p className="text-text-secondary text-sm">Trusted by 50,000+ customers</p>
                </div>
              </div>
            </div>

            <div className="relative animate-slide-left">
              <div className="relative bg-white rounded-2xl shadow-2xl p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                    <Car className="w-6 h-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold">Quick Search</h3>
                    <p className="text-text-secondary text-sm">Find parking near you</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Enter location"
                    className="input-field"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="date"
                      className="input-field"
                    />
                    <input
                      type="time"
                      className="input-field"
                    />
                  </div>
                  <button className="btn-primary w-full">
                    Search Parking
                  </button>
                </div>

                {/* Decorative elements */}
                <div className="absolute -top-4 -right-4 w-20 h-20 bg-secondary-100 rounded-full -z-10"></div>
                <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-primary-100 rounded-full -z-10"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-background-body">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
              Why Choose{' '}
              <span className="text-primary-600">Parking</span>
              <span className="text-secondary-500">Web</span>
            </h2>
            <p className="text-text-secondary">
              We provide the best parking experience with cutting-edge technology and customer-first approach.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className="card p-6 text-center group hover:shadow-xl transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-16 h-16 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-primary-100 transition-colors">
                  <div className="text-primary-600 group-hover:scale-110 transition-transform">
                    {feature.icon}
                  </div>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-text-secondary text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="section-padding bg-gradient-to-br from-primary-50 to-secondary-50">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
              How It{' '}
              <span className="text-primary-600">Works</span>
            </h2>
            <p className="text-text-secondary">
              Book your parking spot in four simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
                <div className="text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-2xl flex items-center justify-center mx-auto mb-4 transform rotate-12 hover:rotate-0 transition-all duration-500">
                    <span className="text-primary-contrast font-heading font-bold text-2xl">
                      {step.number}
                    </span>
                  </div>
                  <h3 className="font-heading font-semibold text-lg mb-2">{step.title}</h3>
                  <p className="text-text-secondary text-sm">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <ChevronRight className="hidden lg:block absolute top-10 -right-4 w-6 h-6 text-primary-400" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background-card">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-heading font-bold text-primary-600 mb-2">50K+</div>
              <div className="text-text-secondary">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-heading font-bold text-secondary-500 mb-2">100+</div>
              <div className="text-text-secondary">Parking Locations</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-heading font-bold text-primary-600 mb-2">24/7</div>
              <div className="text-text-secondary">Customer Support</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-heading font-bold text-secondary-500 mb-2">4.9★</div>
              <div className="text-text-secondary">Average Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section-padding bg-background-body">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
              What Our{' '}
              <span className="text-primary-600">Customers</span>{' '}
              <span className="text-secondary-500">Say</span>
            </h2>
            <p className="text-text-secondary">
              Don't just take our word for it - hear from our satisfied customers
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="card p-6 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-14 h-14 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-heading font-semibold">{testimonial.name}</h4>
                    <p className="text-text-secondary text-sm">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-secondary-500 text-secondary-500" />
                  ))}
                </div>
                <p className="text-text-secondary italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-600 text-primary-contrast">
        <div className="container-custom text-center">
          <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
            Ready to Park Hassle-Free?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of happy customers who never worry about parking again
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link
              to="/register"
              className="px-8 py-4 bg-white text-primary-600 rounded-lg font-semibold hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              Get Started Now
            </Link>
            <Link
              to="/contact"
              className="px-8 py-4 border-2 border-white text-white rounded-lg font-semibold hover:bg-white/10 transition-all duration-300"
            >
              Contact Sales
            </Link>
          </div>
        </div>
      </section>

      <style jsx>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </div>
  );
};

export default Home;