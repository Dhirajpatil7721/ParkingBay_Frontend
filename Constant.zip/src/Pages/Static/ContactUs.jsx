// src/Pages/Static/ContactUs.jsx
import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Send,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const contactInfo = [
    {
      icon: <MapPin className="w-6 h-6" />,
      title: 'Visit Us',
      details: ['123 Parking Street', 'City, State 12345', 'United States'],
      color: 'primary'
    },
    {
      icon: <Phone className="w-6 h-6" />,
      title: 'Call Us',
      details: ['+1 (234) 567-8900', '+1 (234) 567-8901', '24/7 Support'],
      color: 'secondary'
    },
    {
      icon: <Mail className="w-6 h-6" />,
      title: 'Email Us',
      details: ['support@parkingweb.com', 'info@parkingweb.com', 'careers@parkingweb.com'],
      color: 'primary'
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: 'Working Hours',
      details: ['Monday - Friday: 9am - 6pm', 'Saturday: 10am - 4pm', 'Sunday: Closed'],
      color: 'secondary'
    }
  ];

  const faqs = [
    {
      question: 'How do I book a parking spot?',
      answer: 'Simply search for your desired location, select your time slot, and complete the payment. You\'ll receive a confirmation email with a QR code.'
    },
    {
      question: 'Can I cancel my booking?',
      answer: 'Yes, you can cancel your booking up to 2 hours before the scheduled time for a full refund.'
    },
    {
      question: 'Is my payment secure?',
      answer: 'Absolutely! We use industry-standard encryption and secure payment gateways to protect your information.'
    },
    {
      question: 'What if I arrive late?',
      answer: 'You have a 30-minute grace period after your booked time slot. After that, additional charges may apply.'
    }
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'Please enter a valid 10-digit number';
    }
    
    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }
    
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    
    if (Object.keys(newErrors).length === 0) {
      setIsLoading(true);
      // Simulate API call
      setTimeout(() => {
        setIsLoading(false);
        setIsSubmitted(true);
        setFormData({
          name: '',
          email: '',
          phone: '',
          subject: '',
          message: ''
        });
        // Reset success message after 5 seconds
        setTimeout(() => setIsSubmitted(false), 5000);
      }, 1500);
    } else {
      setErrors(newErrors);
    }
  };

  return (
    <div className="font-body">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-50 to-secondary-50 pt-24 pb-16">
        <div className="container-custom text-center">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            Get in{' '}
            <span className="text-primary-600">Touch</span>
          </h1>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">
            Have questions? We're here to help. Send us a message and we'll respond within 24 hours.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="section-padding bg-background-body">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 -mt-20">
            {contactInfo.map((info, index) => (
              <div
                key={index}
                className={`card p-6 text-center animate-slide-up`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-14 h-14 bg-${info.color}-50 rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <div className={`text-${info.color}-600`}>{info.icon}</div>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-3">{info.title}</h3>
                {info.details.map((detail, i) => (
                  <p key={i} className="text-text-secondary text-sm">{detail}</p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="section-padding bg-background-body pt-0">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="card p-8 animate-slide-right">
              <h2 className="font-heading font-bold text-2xl md:text-3xl mb-6">
                Send us a{' '}
                <span className="text-primary-600">Message</span>
              </h2>

              {isSubmitted && (
                <div className="mb-6 p-4 bg-success-light border border-success-main/20 rounded-lg flex items-center gap-3 animate-fade-in">
                  <CheckCircle className="w-5 h-5 text-success-main" />
                  <p className="text-success-dark text-sm">
                    Thank you for contacting us! We'll get back to you soon.
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-text-primary font-medium mb-2">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`input-field ${errors.name ? 'border-error-main' : ''}`}
                    placeholder="John Doe"
                  />
                  {errors.name && (
                    <p className="text-error-main text-sm mt-1 flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> {errors.name}
                    </p>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-text-primary font-medium mb-2">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`input-field ${errors.email ? 'border-error-main' : ''}`}
                      placeholder="john@example.com"
                    />
                    {errors.email && (
                      <p className="text-error-main text-sm mt-1 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> {errors.email}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-text-primary font-medium mb-2">Phone</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className={`input-field ${errors.phone ? 'border-error-main' : ''}`}
                      placeholder="1234567890"
                      maxLength="10"
                    />
                    {errors.phone && (
                      <p className="text-error-main text-sm mt-1 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> {errors.phone}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-text-primary font-medium mb-2">Subject</label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`input-field ${errors.subject ? 'border-error-main' : ''}`}
                    placeholder="How can we help?"
                  />
                  {errors.subject && (
                    <p className="text-error-main text-sm mt-1 flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> {errors.subject}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-text-primary font-medium mb-2">Message</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="5"
                    className={`input-field resize-none ${errors.message ? 'border-error-main' : ''}`}
                    placeholder="Write your message here..."
                  ></textarea>
                  {errors.message && (
                    <p className="text-error-main text-sm mt-1 flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> {errors.message}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="btn-primary w-full flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Message
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Map */}
            <div className="space-y-6 animate-slide-left">
              <div className="card p-6">
                <h3 className="font-heading font-semibold text-xl mb-4">Our Location</h3>
                <div className="aspect-video bg-neutral-200 rounded-lg overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343008!2d-73.98510768458415!3d40.75889697932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    title="Office Location"
                    className="w-full h-full"
                  ></iframe>
                </div>
              </div>

              {/* FAQs */}
              <div className="card p-6">
                <h3 className="font-heading font-semibold text-xl mb-4">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  {faqs.map((faq, index) => (
                    <div key={index} className="border-b border-border-light last:border-0 last:pb-0 pb-4">
                      <h4 className="font-heading font-medium text-text-primary mb-2">{faq.question}</h4>
                      <p className="text-text-secondary text-sm">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-600 to-secondary-600 text-primary-contrast">
        <div className="container-custom text-center">
          <h2 className="font-heading font-bold text-3xl mb-4">Prefer to call?</h2>
          <p className="text-xl mb-6 opacity-90">Our support team is available 24/7</p>
          <a
            href="tel:+12345678900"
            className="inline-flex items-center gap-3 text-3xl font-heading font-bold hover:underline"
          >
            <Phone className="w-8 h-8" />
            +1 (234) 567-8900
          </a>
        </div>
      </section>
    </div>
  );
};

export default ContactUs;