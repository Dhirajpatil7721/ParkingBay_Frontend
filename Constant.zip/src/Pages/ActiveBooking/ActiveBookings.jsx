import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import {
  CircularProgress,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Box,
  Avatar,
  TextField,
  InputAdornment,
  IconButton,
  ButtonGroup,
  Button,
  Grid,
  Card,
  CardContent,
  Pagination,
  PaginationItem,
  Select,
  MenuItem,
  FormControl,
} from '@mui/material';
import {
  DirectionsCar as CarIcon,
  TwoWheeler as BikeIcon,
  AirportShuttle as BusIcon,
  AccessTime as ClockIcon,
  Receipt as ReceiptIcon,
  LocalParking as ParkingIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  ViewList as ListIcon,
  GridView as GridIcon,
  ElectricRickshaw as RickshawIcon,
  LocalShipping as TruckIcon,
  CheckCircle as CheckCircleIcon,
  DirectionsBus as DirectionsBusIcon,
  TrendingUp as TrendingUpIcon,
  FilterList as FilterListIcon,
  Refresh as RefreshIcon,
  FileDownload as DownloadIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Visibility as ViewIcon,
  Edit as EditIcon,
  CalendarMonth as CalendarIcon,
  SwapVert as SortIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
} from '@mui/icons-material';
import { getActiveBookingsForDashboard } from '../../../redux/slice/BookingHistory';
import Theme from '../../../Constant/Theme';

// ── Helpers ────────────────────────────────────────────────────────────────────

const getVehicleIcon = (vehicleType, size = 20) => {
  if (vehicleType === '2') return <BikeIcon sx={{ fontSize: size }} />;
  if (vehicleType === '3') return <RickshawIcon sx={{ fontSize: size }} />;
  if (vehicleType === '45') return <DirectionsBusIcon sx={{ fontSize: size }} />;
  if (vehicleType === '17') return <TruckIcon sx={{ fontSize: size }} />;
  return <CarIcon sx={{ fontSize: size }} />;
};

const getVehicleLabel = (vehicleType) => {
  const map = { '2': '2-Wheeler', '3': '3-Wheeler', '4': '4-Wheeler', '17': 'Heavy Vehicle', '45': 'Bus' };
  return map[vehicleType] || `${vehicleType}-Wheeler`;
};

const formatTime = (dateString) => {
  if (!dateString) return '--';
  const date = new Date(dateString);
  return date.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};

const AVATAR_COLORS = [
  { bg: '#dbeafe', text: '#1d4ed8' },
  { bg: '#fce7f3', text: '#be185d' },
  { bg: '#d1fae5', text: '#065f46' },
  { bg: '#fef3c7', text: '#92400e' },
  { bg: '#ede9fe', text: '#5b21b6' },
  { bg: '#fee2e2', text: '#991b1b' },
];
const getAvatarColor = (str) => AVATAR_COLORS[(str ? str.charCodeAt(0) : 0) % AVATAR_COLORS.length];

// ── Booking Card ───────────────────────────────────────────────────────────────
const BookingCard = ({ booking, index }) => {
  const av = getAvatarColor(booking.vehicleNo);
  const initial = booking.vehicleNo ? booking.vehicleNo[0].toUpperCase() : '?';

  return (
    <div
      className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col gap-3 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 cursor-default"
      style={{ animation: 'fadeSlideUp 0.4s ease both', animationDelay: `${index * 55}ms` }}
    >
      {/* Avatar + name */}
      <div className="flex items-center gap-3">
        <div
          className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0 select-none"
          style={{ background: av.bg, color: av.text }}
        >
          {initial}
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-gray-900 text-sm leading-tight truncate">{booking.vehicleNo}</p>
          <p className="text-xs text-gray-400 truncate mt-0.5">{getVehicleLabel(booking.vehicleType)}</p>
        </div>
      </div>

      <div className="h-px bg-gray-100" />

      {/* Status */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">Status</span>
        <span className="inline-flex items-center text-xs font-semibold px-3 py-1 rounded-full bg-green-100 text-green-700">
          Active
        </span>
      </div>

      {/* Advance */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">Advance</span>
        <span className="text-sm font-bold text-gray-900">₹{booking.advance || 0}</span>
      </div>

      {/* In Time */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">In Time</span>
        <span className="text-sm font-semibold text-gray-700">{formatTime(booking.createdAt)}</span>
      </div>

      <div className="h-px bg-gray-100" />
    </div>
  );
};

// ── Booking List Row ───────────────────────────────────────────────────────────
const BookingRow = ({ booking, index }) => {
  const av = getAvatarColor(booking.vehicleNo);
  const initial = booking.vehicleNo ? booking.vehicleNo[0].toUpperCase() : '?';

  return (
    <tr
      className="border-b border-gray-100 hover:bg-slate-50 transition-colors duration-150"
      style={{ animation: 'fadeSlideUp 0.35s ease both', animationDelay: `${index * 40}ms` }}
    >
      <td className="px-5 py-4">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
            style={{ background: av.bg, color: av.text }}
          >
            {initial}
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-900">{booking.vehicleNo}</p>
            <p className="text-xs text-gray-400">{getVehicleLabel(booking.vehicleType)}</p>
          </div>
        </div>
      </td>
      <td className="px-5 py-4">
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-green-100 text-green-700">Active</span>
      </td>
      <td className="px-5 py-4">
        <span className="text-sm font-bold text-gray-900">₹{booking.advance || 0}</span>
      </td>
      <td className="px-5 py-4">
        <span className="text-sm text-gray-600">{formatTime(booking.createdAt)}</span>
      </td>
    </tr>
  );
};

// ── Main Component ─────────────────────────────────────────────────────────────
export default function ActiveBookings() {
  const dispatch = useDispatch();
  const [bookings, setBookings] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('cards');

  // Pagination states
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(12);
  const [paginatedBookings, setPaginatedBookings] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await dispatch(getActiveBookingsForDashboard());
        const data = result.payload?.activeBookings || [];
        setBookings(data);
        setFilteredBookings(data);
        setLoading(false);
      } catch (err) {
        console.error('Error:', err);
        setError(err.message);
        setLoading(false);
      }
    };
    fetchData();
  }, [dispatch]);

  // Update filtered bookings when search changes
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredBookings(bookings);
    } else {
      setFilteredBookings(
        bookings.filter((b) => b.vehicleNo?.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    setPage(1); // Reset to first page when search changes
  }, [searchTerm, bookings]);

  // Update paginated data when filtered bookings, page, or rows per page change
  useEffect(() => {
    const startIndex = (page - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    setPaginatedBookings(filteredBookings.slice(startIndex, endIndex));
  }, [filteredBookings, page, rowsPerPage]);

  const handleSearchChange = (e) => setSearchTerm(e.target.value);
  const clearSearch = () => setSearchTerm('');

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
    // Smooth scroll to top of content
    document.querySelector('.pagination-container')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleRowsPerPageChange = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1); // Reset to first page
  };

  const totalPages = Math.ceil(filteredBookings.length / rowsPerPage);
  const startEntry = (page - 1) * rowsPerPage + 1;
  const endEntry = Math.min(page * rowsPerPage, filteredBookings.length);

  // Loading
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#1a3c5e] flex items-center justify-center animate-bounce shadow-lg">
            <ParkingIcon sx={{ fontSize: 26, color: '#fff' }} />
          </div>
          <p className="text-sm text-gray-400 animate-pulse font-medium">Loading bookings…</p>
        </div>
      </div>
    );
  }

  // Error
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="text-center p-8 bg-white rounded-2xl shadow border border-red-100 max-w-sm mx-4">
          <div className="w-12 h-12 mx-auto rounded-xl bg-red-50 flex items-center justify-center mb-3">
            <ClearIcon sx={{ fontSize: 26, color: '#ef4444' }} />
          </div>
          <p className="font-semibold text-gray-800">Error loading bookings</p>
          <p className="text-sm text-gray-400 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
      `}</style>

      <div
        className="min-h-screen bg-[#f1f4f8] px-4 py-6 sm:px-6 lg:px-8"
        style={{ animation: 'fadeIn 0.25s ease' }}
      >
        <div className="max-w-screen-xl mx-auto space-y-5">

          {/* ── Header ── */}
          <div
            className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4"
            style={{ animation: 'fadeSlideUp 0.35s ease both' }}
          >
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1a3c5e] tracking-tight leading-tight">
                Active Bookings
              </h1>
              <p className="text-sm text-gray-500 mt-0.5">Manage your parked vehicles and their status</p>
            </div>


          </div>

          {/* ── Search + controls bar with single view toggle ── */}
          <div
            className="bg-white rounded-2xl border border-gray-200 shadow-sm px-4 py-3 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center"
            style={{ animation: 'fadeSlideUp 0.4s ease both' }}
          >
            <div className="relative flex-1 max-w-lg">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                <SearchIcon sx={{ fontSize: 19 }} />
              </span>
              <input
                type="text"
                placeholder="Search vehicles..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="w-full pl-10 pr-9 py-2.5 text-sm rounded-xl border border-gray-200 bg-gray-50 outline-none focus:ring-2 focus:ring-[#1a3c5e]/25 focus:border-[#1a3c5e] transition-all placeholder:text-gray-400"
              />
              {searchTerm && (
                <button onClick={clearSearch} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors">
                  <ClearIcon sx={{ fontSize: 16 }} />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 flex-wrap ml-auto">
              {/* Results count */}
              <div className="text-sm text-gray-500 px-2">
                {filteredBookings.length} total
              </div>

              {/* Rows per page selector */}
              <FormControl size="small" sx={{ minWidth: 100 }}>
                <Select
                  value={rowsPerPage}
                  onChange={handleRowsPerPageChange}
                  displayEmpty
                  sx={{
                    fontSize: '0.875rem',
                    '& .MuiSelect-select': { py: 0.75, px: 1.5 }

                  }}
                >
                  <MenuItem value={6}>6 / page</MenuItem>
                  <MenuItem value={12}>12 / page</MenuItem>
                  <MenuItem value={24}>24 / page</MenuItem>
                  <MenuItem value={48}>48 / page</MenuItem>
                </Select>
              </FormControl>

              {/* Single List / Card toggle */}
              <div className="flex  overflow-hidden  ">
                <button
                  onClick={() => {
                    setViewMode(viewMode === 'list' ? 'cards' : 'list');
                    setPage(1);
                  }}
                  className="px-3 py-2 text-sm font-semibold transition-all duration-200  text-gray-600  flex items-center gap-2"
                  title={viewMode === 'list' ? 'Switch to Card View' : 'Switch to List View'}
                >
                  {viewMode === 'list' ? (
                    <>
                      <GridIcon sx={{ fontSize: 18 }} />
                      {/* <span className="text-xs hidden sm:inline">Cards</span> */}
                    </>
                  ) : (
                    <>
                      <ListIcon sx={{ fontSize: 18 }} />
                      {/* <span className="text-xs hidden sm:inline">List</span> */}
                    </>
                  )}
                </button>
              </div>
              {/* Toolbar buttons */}
              <div className="flex items-center flex-wrap">
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setPage(1);
                  }}
                  className="p-2 text-gray-500 transition-all "
                  title="Refresh"
                >
                  <RefreshIcon sx={{ fontSize: 20 }} />
                </button>
              </div>
            </div>
          </div>

          {/* ── Single content div with conditional rendering ── */}
          <div className="pagination-container" style={{ animation: 'fadeSlideUp 0.5s ease both' }}>

            {/* No search results */}
            {filteredBookings.length === 0 && searchTerm && (
              <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border border-gray-200 shadow-sm text-center">
                <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-3">
                  <SearchIcon sx={{ fontSize: 28, color: '#d1d5db' }} />
                </div>
                <p className="font-semibold text-gray-700">No results for "{searchTerm}"</p>
                <p className="text-sm text-gray-400 mt-1">Try a different vehicle number</p>
                <button onClick={clearSearch} className="mt-3 text-sm text-[#1a3c5e] hover:underline font-semibold">
                  Clear search
                </button>
              </div>
            )}

            {/* Empty state */}
            {filteredBookings.length === 0 && !searchTerm && (
              <div className="flex flex-col items-center justify-center py-24 bg-white rounded-2xl border border-gray-200 shadow-sm text-center">
                <div className="w-16 h-16 rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
                  <ParkingIcon sx={{ fontSize: 34, color: '#93c5fd' }} />
                </div>
                <p className="text-base font-bold text-gray-700">No Active Vehicles</p>
                <p className="text-sm text-gray-400 mt-1">No vehicles are currently parked</p>
              </div>
            )}

            {/* LIST VIEW with pagination */}
            {viewMode === 'list' && filteredBookings.length > 0 && (
              <>
                <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-100">
                          {['Vehicle', 'Status', 'Advance', 'In Time'].map((h) => (
                            <th key={h} className="px-5 py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedBookings.map((booking, i) => (
                          <BookingRow key={booking._id} booking={booking} index={i} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pagination controls for list view */}
                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-4 pt-2">
                    <div className="text-sm text-gray-500">
                      Showing {startEntry} to {endEntry} of {filteredBookings.length} entries
                    </div>
                    <Pagination
                      count={totalPages}
                      page={page}
                      onChange={handlePageChange}
                      color="primary"
                      size="large"
                      siblingCount={1}
                      boundaryCount={1}
                      renderItem={(item) => (
                        <PaginationItem
                          slots={{ previous: ChevronLeftIcon, next: ChevronRightIcon }}
                          {...item}
                        />
                      )}
                      sx={{
                        '& .MuiPaginationItem-root': {
                          borderRadius: '10px',
                          fontWeight: 500,
                        },
                        '& .Mui-selected': {
                          backgroundColor: '#1a3c5e !important',
                          color: 'white',
                          '&:hover': {
                            backgroundColor: '#0f2a44 !important',
                          },
                        },
                      }}
                    />
                  </div>
                )}
              </>
            )}

            {/* CARD VIEW with pagination — 4 per row xl, 3 lg, 2 sm, 1 mobile */}
            {viewMode === 'cards' && filteredBookings.length > 0 && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {paginatedBookings.map((booking, i) => (
                    <BookingCard key={booking._id} booking={booking} index={i} />
                  ))}
                </div>

                {/* Pagination controls for card view */}
                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6 pt-2">
                    <div className="text-sm text-gray-500">
                      Showing {startEntry} to {endEntry} of {filteredBookings.length} entries
                    </div>
                    <Pagination
                      count={totalPages}
                      page={page}
                      onChange={handlePageChange}
                      color="primary"
                      size="large"
                      siblingCount={1}
                      boundaryCount={1}
                      renderItem={(item) => (
                        <PaginationItem
                          slots={{ previous: ChevronLeftIcon, next: ChevronRightIcon }}
                          {...item}
                        />
                      )}
                      sx={{
                        '& .MuiPaginationItem-root': {
                          borderRadius: '10px',
                          fontWeight: 500,
                        },
                        '& .Mui-selected': {
                          backgroundColor: '#1a3c5e !important',
                          color: 'white',
                          '&:hover': {
                            backgroundColor: '#0f2a44 !important',
                          },
                        },
                      }}
                    />
                  </div>
                )}
              </>
            )}

          </div>
          {/* ── end single content div ── */}

        </div>
      </div>
    </>
  );
}
