import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  IconButton, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Chip, Avatar,
  TextField, InputAdornment, CircularProgress, Alert, Snackbar,
} from '@mui/material';
import {
  Person as PersonIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Lock as LockIcon,
  LockOpen as LockOpenIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  CameraAlt as CameraIcon,
  PhotoLibrary as PhotoLibraryIcon,
  QrCode as QrCodeIcon,
  Delete as DeleteIcon,
  Close as CloseIcon,
  LocationOn as LocationIcon,
  CalendarToday as CalendarIcon,
  LocalParking as ParkingIcon,
  TwoWheeler as TwoWheelerIcon,
  DirectionsCar as FourWheelerIcon,
  LocalShipping as HeavyVehicleIcon,
  DirectionsBus as BusIcon,
  PedalBike as ThreeWheelerIcon,
  TrendingUp as TrendingUpIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  WarningAmberRounded,
  Storefront as StorefrontIcon,
  CheckCircle as CheckCircleIcon,
} from '@mui/icons-material';

import {
  getProfile, updateAdminProfile, uploadQRPhoto, deleteQRPhoto, resetPassword,
  selectProfile, selectProfileLoading, selectProfileError, selectUploadQRLoading,
  selectDeleteQRLoading, selectPasswordResetLoading, selectSuccessMessage,
  clearProfileError, clearSuccessMessage,
} from '../../../redux/slice/Vendor';

const VEHICLE_TYPES = {
  '2':  { key: 'twoWheeler',   label: 'Two Wheeler',   icon: TwoWheelerIcon,   description: 'Motorcycles, Scooters' },
  '3':  { key: 'threeWheeler', label: 'Three Wheeler', icon: ThreeWheelerIcon, description: 'Auto rickshaws, Tuk-tuks' },
  '4':  { key: 'fourWheeler',  label: 'Four Wheeler',  icon: FourWheelerIcon,  description: 'Cars, SUVs, Sedans' },
  '17': { key: 'heavyVehicle', label: 'Heavy Vehicle', icon: HeavyVehicleIcon, description: 'Trucks, Lorries' },
  '55': { key: 'bus',          label: 'Bus',           icon: BusIcon,          description: 'Buses, Coaches' },
};
const VEHICLES = Object.entries(VEHICLE_TYPES).map(([type, config]) => ({ vehicleType: type, ...config }));

function getInitials(name) {
  return name?.trim().split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'U';
}

// ─── Image Picker Modal ───────────────────────────────────────────────────
const ImagePickerModal = ({ open, onClose, onCamera, onGallery }) => (
  <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth
    PaperProps={{ style: { borderRadius: '20px', maxWidth: 380, padding: '4px' } }}>
    <DialogTitle className="pb-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#e8eef4] flex items-center justify-center">
            <CameraIcon sx={{ color: '#1a3c5e', fontSize: 20 }} />
          </div>
          <span className="font-bold text-lg text-[#1a3c5e]">QR Code Image</span>
        </div>
        <IconButton size="small" onClick={onClose}><CloseIcon sx={{ fontSize: 18, color: '#9ca3af' }} /></IconButton>
      </div>
    </DialogTitle>
    <DialogContent className="pt-4 pb-5">
      <div className="flex flex-col gap-3">
        {[
          { Icon: CameraIcon, label: 'Take Photo', onClick: onCamera },
          { Icon: PhotoLibraryIcon, label: 'Choose from Gallery', onClick: onGallery },
        ].map(({ Icon, label, onClick }) => (
          <button key={label} onClick={onClick}
            className="flex items-center gap-3 w-full px-4 py-3 text-sm font-medium text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition-all text-left">
            <Icon sx={{ fontSize: 18, color: '#9ca3af' }} />
            {label}
          </button>
        ))}
      </div>
    </DialogContent>
  </Dialog>
);

// ─── QR Full View Modal ───────────────────────────────────────────────────
const QRFullViewModal = ({ open, onClose, qrCode }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth
    PaperProps={{ style: { borderRadius: '20px', maxWidth: 420, width: '100%' } }}>
    <DialogContent className="p-6 text-center">
      <div className="flex justify-end mb-2">
        <IconButton onClick={onClose} size="small" className="bg-gray-100">
          <CloseIcon sx={{ fontSize: 16, color: '#6b7280' }} />
        </IconButton>
      </div>
      <h3 className="font-bold text-xl text-gray-800 mb-4">QR Code</h3>
      <div className="w-48 h-48 mx-auto mb-4 bg-gray-50 rounded-2xl flex items-center justify-center border-2 border-gray-200 p-4">
        {qrCode
          ? <img src={qrCode} alt="QR Code" className="w-full h-full object-contain" />
          : <QrCodeIcon sx={{ fontSize: 80, color: '#d1d5db' }} />}
      </div>
      <p className="text-sm text-gray-400">Scan this QR code to access parking details</p>
    </DialogContent>
  </Dialog>
);

// ─── Section Card wrapper ─────────────────────────────────────────────────
const SectionCard = ({ title, action, children, delay = '0s' }) => (
  <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-4 sm:p-6"
    style={{ animation: 'fadeSlideUp 0.4s ease both', animationDelay: delay }}>
    <div className="flex items-center justify-between mb-4 sm:mb-5">
      <h3 className="font-bold text-base sm:text-lg text-[#1a3c5e]">{title}</h3>
      {action}
    </div>
    {children}
  </div>
);

// ─── Info Row ─────────────────────────────────────────────────────────────
const InfoRow = ({ icon: Icon, label, value, border = true }) => (
  <div className={`flex items-center gap-3 py-3 ${border ? 'border-b border-gray-100' : ''}`}>
    <div className="w-9 h-9 rounded-xl bg-[#e8eef4] flex items-center justify-center shrink-0">
      <Icon sx={{ fontSize: 16, color: '#1a3c5e' }} />
    </div>
    <div>
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-0.5">{label}</p>
      <p className="text-sm font-semibold text-gray-800">{value || 'Not set'}</p>
    </div>
  </div>
);

// ─── Edit/Save button pair ────────────────────────────────────────────────
const EditActions = ({ editing, onEdit, onCancel, onSave, loading, saveLabel = 'Save' }) => (
  editing ? (
    <div className="flex gap-2">
      <button onClick={onCancel} disabled={loading}
        className="px-3 py-1.5 text-xs font-semibold border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-all disabled:opacity-50">
        Cancel
      </button>
      <button onClick={onSave} disabled={loading}
        className="px-3 py-1.5 text-xs font-semibold bg-[#1a3c5e] text-white rounded-xl hover:bg-[#0f2a44] transition-all shadow-sm disabled:opacity-50 flex items-center gap-1.5">
        {loading ? <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" /> : <SaveIcon sx={{ fontSize: 14 }} />}
        {loading ? 'Saving...' : saveLabel}
      </button>
    </div>
  ) : (
    <button onClick={onEdit}
      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-all">
      <EditIcon sx={{ fontSize: 14 }} />
      Edit
    </button>
  )
);

// ─── Main Component ───────────────────────────────────────────────────────
export default function Profile() {
  const dispatch = useDispatch();
  const qrFileInput = useRef(null);

  const profileData    = useSelector(selectProfile);
  const loading        = useSelector(selectProfileLoading);
  const uploadLoading  = useSelector(selectUploadQRLoading);
  const deleteLoading  = useSelector(selectDeleteQRLoading);
  const passwordLoading= useSelector(selectPasswordResetLoading);
  const error          = useSelector(selectProfileError);
  const successMessage = useSelector(selectSuccessMessage);

  const [user, setUser]                 = useState(null);
  const [vendorData, setVendorData]     = useState(null);
  const [editing, setEditing]           = useState(false);
  const [editingVehicles, setEditingVehicles] = useState(false);
  const [editingParkingSpot, setEditingParkingSpot] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [showQRPicker, setShowQRPicker] = useState(false);
  const [showQRFull, setShowQRFull]     = useState(false);
  const [showDeleteQR, setShowDeleteQR] = useState(false);
  const [selectedQR, setSelectedQR]     = useState(null);
  const [qrCodeImages, setQrCodeImages] = useState([]);
  const [vehicleRates, setVehicleRates] = useState({});
  const [parkingSpotName, setParkingSpotName] = useState('');
  const [form, setForm]   = useState({ name: '', email: '' });
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [showPass, setShowPass] = useState({ current: false, new: false, confirm: false });
  const [errors, setErrors] = useState({});
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => { dispatch(getProfile()); }, [dispatch]);

  useEffect(() => {
    if (profileData) {
      const admin = profileData.profile || profileData.admin || profileData;
      if (admin) {
        setUser({ id: admin._id, name: admin.name, mobile: admin.mobile, role: admin.role, email: admin.email || '' });
        setVendorData({ name: admin.name, isOneTimeEntry: admin.isOneTimeEntry || false, createdAt: admin.createdAt, location: admin.location || null });
        setParkingSpotName(admin.parkingSpotName || '');
        setQrCodeImages(admin.qrPhotos || []);
        const rates = {};
        (admin.vehicles || []).forEach(v => {
          const info = VEHICLE_TYPES[v.vehicleType];
          if (info) rates[info.key] = v.charges;
        });
        setVehicleRates(rates);
        setForm({ name: admin.name, email: admin.email || '' });
      }
    }
  }, [profileData]);

  useEffect(() => {
    if (successMessage) { setSnackbar({ open: true, message: successMessage, severity: 'success' }); dispatch(clearSuccessMessage()); }
  }, [successMessage, dispatch]);

  useEffect(() => {
    if (error) { setSnackbar({ open: true, message: error, severity: 'error' }); dispatch(clearProfileError()); }
  }, [error, dispatch]);

  const fieldChange = field => e => { setForm(p => ({ ...p, [field]: e.target.value })); setErrors(p => ({ ...p, [field]: '' })); };
  const rateChange  = key   => e => setVehicleRates(p => ({ ...p, [key]: e.target.value === '' ? 0 : Number(e.target.value) }));
  const passChange  = field => e => { setPasswordForm(p => ({ ...p, [field]: e.target.value })); setErrors(p => ({ ...p, [field]: '' })); };
  const togglePass  = field => setShowPass(p => ({ ...p, [field]: !p[field] }));

  const handleQRFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { setSnackbar({ open: true, message: 'Please select an image file', severity: 'error' }); return; }
    if (file.size > 5 * 1024 * 1024) { setSnackbar({ open: true, message: 'File size should be less than 5MB', severity: 'error' }); return; }
    const formData = new FormData();
    formData.append('qrPhoto', file);
    setActionLoading(true);
    const result = await dispatch(uploadQRPhoto(formData));
    setActionLoading(false);
    if (!result.error) { dispatch(getProfile()); setShowQRPicker(false); setSnackbar({ open: true, message: 'QR code uploaded successfully!', severity: 'success' }); }
    e.target.value = '';
  };

  const handleQRRemove = async () => {
    if (!selectedQR) return;
    const result = await dispatch(deleteQRPhoto(selectedQR));
    if (!result.error) { setShowDeleteQR(false); setSelectedQR(null); dispatch(getProfile()); }
  };

  const handleSaveProfile = async () => {
    const e = {};
    if (!form.name?.trim()) e.name = 'Name is required';
    setErrors(e);
    if (Object.keys(e).length) return;
    const update = { name: form.name.trim() };
    if (form.email?.trim()) update.email = form.email.trim();
    const result = await dispatch(updateAdminProfile(update));
    if (!result.error) { setEditing(false); dispatch(getProfile()); }
  };

  const handleSaveParkingSpot = async () => {
    if (!parkingSpotName.trim()) { setErrors(p => ({ ...p, parkingSpotName: 'Required' })); return; }
    const result = await dispatch(updateAdminProfile({ parkingSpotName: parkingSpotName.trim() }));
    if (!result.error) { setEditingParkingSpot(false); dispatch(getProfile()); }
  };

  const handleSaveVehicleRates = async () => {
    const vehicles = Object.entries(vehicleRates)
      .filter(([_, c]) => c > 0)
      .map(([key, charges]) => ({ vehicleType: Object.keys(VEHICLE_TYPES).find(t => VEHICLE_TYPES[t].key === key), charges }));
    const result = await dispatch(updateAdminProfile({ vehicles }));
    if (!result.error) { setEditingVehicles(false); dispatch(getProfile()); }
  };

  const handleSavePassword = async () => {
    const e = {};
    if (!passwordForm.currentPassword) e.currentPassword = 'Required';
    if (!passwordForm.newPassword) e.newPassword = 'Required';
    else if (passwordForm.newPassword.length < 6) e.newPassword = 'Min 6 characters';
    if (!passwordForm.confirmPassword) e.confirmPassword = 'Required';
    else if (passwordForm.newPassword !== passwordForm.confirmPassword) e.confirmPassword = 'Passwords do not match';
    setErrors(e);
    if (Object.keys(e).length) return;
    const result = await dispatch(resetPassword({ oldPassword: passwordForm.currentPassword, newPassword: passwordForm.newPassword }));
    if (!result.error) { setChangingPassword(false); setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' }); }
  };

  const inputSx = { '& .MuiOutlinedInput-root': { borderRadius: '12px', fontSize: '0.875rem' } };

  if (loading && !profileData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#1a3c5e] flex items-center justify-center animate-bounce shadow-lg">
            <PersonIcon sx={{ fontSize: 26, color: '#fff' }} />
          </div>
          <p className="text-sm text-gray-400 animate-pulse font-medium">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes fadeSlideUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      `}</style>

      <input type="file" ref={qrFileInput} onChange={handleQRFileChange} accept="image/*" className="hidden" />

      <div className="min-h-screen bg-[#f1f4f8] px-4 py-4 sm:px-6 lg:px-8" style={{ animation: 'fadeIn 0.25s ease' }}>
        <div className="max-w-screen-lg mx-auto space-y-4 sm:space-y-5">

          {/* ── Header ── */}
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3"
            style={{ animation: 'fadeSlideUp 0.35s ease both' }}>
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-[#1a3c5e] tracking-tight leading-tight">My Profile</h1>
              <p className="text-xs sm:text-sm text-gray-500 mt-0.5">Manage your personal information</p>
            </div>
          </div>

          {/* ── Profile Banner ── */}
          <div className="bg-[#1a3c5e] rounded-xl sm:rounded-2xl p-5 sm:p-7 relative overflow-hidden shadow-sm"
            style={{ animation: 'fadeSlideUp 0.4s ease both' }}>
            <div className="absolute inset-0 opacity-10"
              style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, #fff 0%, transparent 60%)' }} />
            <div className="relative flex items-center gap-4 sm:gap-6">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/20 border-2 border-white/30 flex items-center justify-center text-white font-extrabold text-xl sm:text-2xl shrink-0 backdrop-blur-sm">
                {getInitials(vendorData?.name || user?.name)}
              </div>
              <div className="min-w-0">
                <h2 className="text-xl sm:text-2xl font-extrabold text-white truncate">{vendorData?.name || user?.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <PhoneIcon sx={{ fontSize: 14, color: 'rgba(255,255,255,0.7)' }} />
                  <span className="text-sm text-white/80">{user?.mobile}</span>
                </div>
                {user?.email && (
                  <div className="flex items-center gap-2 mt-0.5">
                    <EmailIcon sx={{ fontSize: 14, color: 'rgba(255,255,255,0.7)' }} />
                    <span className="text-xs text-white/70">{user.email}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ── Stats Row ── */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4" style={{ animation: 'fadeSlideUp 0.45s ease both' }}>
            {[
              { icon: ParkingIcon, bg: '#e8eef4', color: '#1a3c5e', value: Object.keys(vehicleRates).length, label: 'Vehicle Rates' },
              { icon: TrendingUpIcon, bg: '#fef3c7', color: '#d97706', value: vendorData?.isOneTimeEntry ? 'One-Time' : 'Regular', label: 'Booking Type' },
              { icon: CheckCircleIcon, bg: '#d1fae5', color: '#059669', value: 'Active', label: 'Status' },
            ].map(({ icon: Icon, bg, color, value, label }) => (
              <div key={label} className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 p-3 sm:p-4 shadow-sm">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: bg }}>
                    <Icon sx={{ color, fontSize: { xs: 18, sm: 20 } }} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm sm:text-lg font-extrabold text-[#1a3c5e] leading-tight truncate">{value}</p>
                    <p className="text-xs text-gray-400 truncate">{label}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* ── Parking Spot ── */}
          <SectionCard title="Parking Spot" delay="0.5s"
            action={<EditActions editing={editingParkingSpot} onEdit={() => setEditingParkingSpot(true)}
              onCancel={() => { setEditingParkingSpot(false); setErrors(p => ({ ...p, parkingSpotName: '' })); }}
              onSave={handleSaveParkingSpot} loading={loading} />}>
            {editingParkingSpot ? (
              <TextField fullWidth size="small" label="Parking Spot Name" value={parkingSpotName}
                onChange={e => { setParkingSpotName(e.target.value); setErrors(p => ({ ...p, parkingSpotName: '' })); }}
                error={!!errors.parkingSpotName} helperText={errors.parkingSpotName} disabled={loading} sx={inputSx}
                InputProps={{ startAdornment: <InputAdornment position="start"><StorefrontIcon sx={{ fontSize: 18, color: '#9ca3af' }} /></InputAdornment> }} />
            ) : (
              <InfoRow icon={StorefrontIcon} label="Parking Spot Name" value={parkingSpotName || 'Not set'} border={false} />
            )}
          </SectionCard>

          {/* ── QR Codes ── */}
          <SectionCard title={`QR Codes (${qrCodeImages.length}/5)`} delay="0.55s"
            action={qrCodeImages.length < 5 && (
              <button onClick={() => setShowQRPicker(true)} disabled={uploadLoading || actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border border-[#1a3c5e] text-[#1a3c5e] rounded-xl hover:bg-[#e8eef4] transition-all disabled:opacity-50">
                {uploadLoading || actionLoading
                  ? <div className="w-3 h-3 border border-[#1a3c5e] border-t-transparent rounded-full animate-spin" />
                  : <CameraIcon sx={{ fontSize: 14 }} />}
                Add QR
              </button>
            )}>
            {qrCodeImages.length > 0 ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                {qrCodeImages.map((qr, i) => (
                  <div key={i} className="relative">
                    <div onClick={() => { setSelectedQR(qr); setShowQRFull(true); }}
                      className="aspect-square border-2 border-gray-200 rounded-xl overflow-hidden cursor-pointer hover:border-[#1a3c5e] transition-all">
                      <img src={qr} alt={`QR ${i + 1}`} className="w-full h-full object-cover" />
                    </div>
                    <button onClick={() => { setSelectedQR(qr); setShowDeleteQR(true); }} disabled={deleteLoading}
                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-100 flex items-center justify-center shadow hover:bg-red-200 transition-all">
                      <DeleteIcon sx={{ fontSize: 12, color: '#dc2626' }} />
                    </button>
                  </div>
                ))}
                {qrCodeImages.length < 5 && (
                  <button onClick={() => setShowQRPicker(true)}
                    className="aspect-square border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center hover:border-[#1a3c5e] hover:bg-[#f8fafc] transition-all cursor-pointer">
                    <CameraIcon sx={{ fontSize: 24, color: '#d1d5db' }} />
                    <span className="text-xs text-gray-400 mt-1">Add</span>
                  </button>
                )}
              </div>
            ) : (
              <button onClick={() => setShowQRPicker(true)}
                className="w-full border-2 border-dashed border-gray-200 rounded-xl py-8 flex flex-col items-center hover:border-[#1a3c5e] hover:bg-[#f8fafc] transition-all cursor-pointer">
                <QrCodeIcon sx={{ fontSize: 40, color: '#d1d5db', mb: 1 }} />
                <p className="text-sm font-semibold text-gray-700">Add QR Code</p>
                <p className="text-xs text-gray-400 mt-0.5">Upload QR codes for your parking location</p>
              </button>
            )}
          </SectionCard>

          {/* ── Profile Information ── */}
          <SectionCard title="Profile Information" delay="0.6s"
            action={<EditActions editing={editing} onEdit={() => setEditing(true)}
              onCancel={() => { setEditing(false); setForm({ name: vendorData?.name || user?.name || '', email: user?.email || '' }); }}
              onSave={handleSaveProfile} loading={loading} />}>
            {editing ? (
              <div className="flex flex-col gap-3">
                <TextField fullWidth size="small" label="Full Name" value={form.name} onChange={fieldChange('name')}
                  error={!!errors.name} helperText={errors.name} disabled={loading} sx={inputSx}
                  InputProps={{ startAdornment: <InputAdornment position="start"><PersonIcon sx={{ fontSize: 18, color: '#9ca3af' }} /></InputAdornment> }} />
                <TextField fullWidth size="small" label="Email" value={form.email} onChange={fieldChange('email')}
                  disabled={loading} sx={inputSx}
                  InputProps={{ startAdornment: <InputAdornment position="start"><EmailIcon sx={{ fontSize: 18, color: '#9ca3af' }} /></InputAdornment> }} />
              </div>
            ) : (
              <div>
                <InfoRow icon={PersonIcon} label="Full Name" value={vendorData?.name || user?.name} />
                <InfoRow icon={PhoneIcon} label="Mobile Number" value={user?.mobile} />
                {user?.email && <InfoRow icon={EmailIcon} label="Email" value={user.email} border={false} />}
              </div>
            )}
          </SectionCard>

          {/* ── Vehicle Rates ── */}
          {user?.role !== 'WORKER' && (
            <SectionCard title="Vehicle Parking Charges" delay="0.65s"
              action={<EditActions editing={editingVehicles} onEdit={() => setEditingVehicles(true)}
                onCancel={() => setEditingVehicles(false)} onSave={handleSaveVehicleRates} loading={loading} />}>
              <div>
                {VEHICLES.map((vehicle, i) => (
                  <div key={vehicle.vehicleType} className={`flex items-center gap-3 py-3 ${i < VEHICLES.length - 1 ? 'border-b border-gray-100' : ''}`}>
                    <div className="w-9 h-9 rounded-xl bg-[#e8eef4] flex items-center justify-center shrink-0">
                      <vehicle.icon sx={{ fontSize: 18, color: '#1a3c5e' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800">{vehicle.label}</p>
                      <p className="text-xs text-gray-400">{vehicle.description}</p>
                    </div>
                    {editingVehicles ? (
                      <TextField size="small" value={vehicleRates[vehicle.key] || ''} onChange={rateChange(vehicle.key)}
                        disabled={loading} style={{ width: 90 }}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: '10px', fontSize: '0.875rem' } }}
                        InputProps={{ startAdornment: <InputAdornment position="start"><span className="text-sm">₹</span></InputAdornment> }} />
                    ) : (
                      <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#e8eef4] text-[#1a3c5e]">
                        ₹{vehicleRates[vehicle.key] || 0}
                      </span>
                    )}
                  </div>
                ))}
                <div className="flex justify-between pt-3 mt-1 border-t border-gray-100">
                  <span className="text-xs text-gray-400">Rates Configured</span>
                  <span className="text-xs font-bold text-[#1a3c5e]">
                    {Object.values(vehicleRates).filter(r => r && r > 0).length}/{VEHICLES.length}
                  </span>
                </div>
              </div>
            </SectionCard>
          )}

          {/* ── Location ── */}
          {vendorData?.location && (
            <SectionCard title="Location" delay="0.7s">
              <InfoRow icon={LocationIcon} label="Registered Location"
                value={`Lat: ${vendorData.location.latitude}, Lng: ${vendorData.location.longitude}`} border={false} />
            </SectionCard>
          )}

          {/* ── Account Info ── */}
          <SectionCard title="Account Information" delay="0.75s">
            <InfoRow icon={CalendarIcon} label="Member Since"
              value={vendorData?.createdAt ? new Date(vendorData.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'N/A'} />
            <InfoRow icon={ParkingIcon} label="Account Type"
              value={vendorData?.isOneTimeEntry ? 'One-Time Entry' : 'Regular Parking'} border={false} />
          </SectionCard>

          {/* ── Security ── */}
          <SectionCard title="Security" delay="0.8s"
            action={!changingPassword ? (
              <button onClick={() => setChangingPassword(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-all">
                <LockIcon sx={{ fontSize: 14 }} />
                Change Password
              </button>
            ) : (
              <div className="flex gap-2">
                <button onClick={() => { setChangingPassword(false); setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' }); setErrors({}); }}
                  disabled={passwordLoading}
                  className="px-3 py-1.5 text-xs font-semibold border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-all disabled:opacity-50">
                  Cancel
                </button>
                <button onClick={handleSavePassword} disabled={passwordLoading}
                  className="px-3 py-1.5 text-xs font-semibold bg-[#1a3c5e] text-white rounded-xl hover:bg-[#0f2a44] transition-all shadow-sm disabled:opacity-50 flex items-center gap-1.5">
                  {passwordLoading ? <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" /> : null}
                  {passwordLoading ? 'Updating...' : 'Update'}
                </button>
              </div>
            )}>
            {changingPassword ? (
              <div className="flex flex-col gap-3">
                {[
                  { field: 'currentPassword', label: 'Current Password', icon: LockOpenIcon, show: 'current' },
                  { field: 'newPassword',     label: 'New Password',     icon: LockIcon,     show: 'new' },
                  { field: 'confirmPassword', label: 'Confirm Password', icon: LockIcon,     show: 'confirm' },
                ].map(({ field, label, icon: Icon, show }) => (
                  <TextField key={field} fullWidth size="small" label={label}
                    type={showPass[show] ? 'text' : 'password'}
                    value={passwordForm[field]} onChange={passChange(field)}
                    error={!!errors[field]} helperText={errors[field]}
                    disabled={passwordLoading} sx={inputSx}
                    InputProps={{
                      startAdornment: <InputAdornment position="start"><Icon sx={{ fontSize: 18, color: '#9ca3af' }} /></InputAdornment>,
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton size="small" onClick={() => togglePass(show)} edge="end" disabled={passwordLoading}>
                            {showPass[show] ? <VisibilityOffIcon sx={{ fontSize: 18 }} /> : <VisibilityIcon sx={{ fontSize: 18 }} />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }} />
                ))}
              </div>
            ) : (
              <div>
                <InfoRow icon={LockIcon} label="Password" value="••••••••" border={false} />
                <p className="text-xs text-gray-400 mt-1 ml-12">Change your password regularly to keep your account secure</p>
              </div>
            )}
          </SectionCard>

        </div>
      </div>

      {/* ── Modals ── */}
      <ImagePickerModal open={showQRPicker} onClose={() => setShowQRPicker(false)}
        onCamera={() => { setSnackbar({ open: true, message: 'Camera feature coming soon!', severity: 'info' }); setShowQRPicker(false); }}
        onGallery={() => { qrFileInput.current?.click(); setShowQRPicker(false); }} />

      <QRFullViewModal open={showQRFull} onClose={() => setShowQRFull(false)} qrCode={selectedQR} />

      {/* Delete QR Dialog */}
      <Dialog open={showDeleteQR} onClose={() => setShowDeleteQR(false)}
        PaperProps={{ style: { borderRadius: '20px', maxWidth: 380, width: '100%' } }}>
        <DialogContent className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0">
              <DeleteIcon sx={{ fontSize: 20, color: '#dc2626' }} />
            </div>
            <h3 className="font-bold text-lg text-gray-800">Remove QR Code</h3>
          </div>
          <p className="text-sm text-gray-500 mb-5">Are you sure you want to remove this QR code? This action cannot be undone.</p>
          <div className="flex gap-3">
            <button onClick={() => setShowDeleteQR(false)} disabled={deleteLoading}
              className="flex-1 py-2.5 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all text-sm disabled:opacity-50">
              Cancel
            </button>
            <button onClick={handleQRRemove} disabled={deleteLoading}
              className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-all text-sm disabled:opacity-50 flex items-center justify-center gap-2">
              {deleteLoading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : null}
              {deleteLoading ? 'Removing...' : 'Yes, Remove'}
            </button>
          </div>
        </DialogContent>
      </Dialog>

      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
        <Alert severity={snackbar.severity} sx={{ borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}