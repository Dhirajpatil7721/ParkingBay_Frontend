// import React, { useEffect, useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import {
//   getVendorHistory,
//   selectVendorHistoryData,
//   selectVendorHistoryLoading,
//   selectVendorHistoryError,
//   selectHistorySummary,
//   selectHistoryBreakdown,
//   selectHistoryDateRange,
//   selectHistoryPagination,
//   selectTotalAmount,
//   selectTotalBookings,
//   selectAverageAmount,
//   selectPaymentBreakdown,
//   selectVehicleBreakdown,
//   selectDailyBreakdown,
//   selectTopVehiclesByFrequency,
//   selectFormattedHistoryData,
//   setDateRange,
// } from '../../../redux/slice/BookingHistory';

// // ─── Utility ────────────────────────────────────────────────────────────────

// const fmt = (n) =>
//   new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);

// const fmtDate = (d) =>
//   d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

// const fmtTime = (d) =>
//   d ? new Date(d).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';

// // ─── Sub-components ─────────────────────────────────────────────────────────

// function StatCard({ label, value, sub, accent }) {
//   return (
//     <div style={{
//       background: '#fff',
//       border: '1px solid #e5e7eb',
//       borderRadius: 14,
//       padding: '20px 24px',
//       display: 'flex',
//       flexDirection: 'column',
//       gap: 6,
//       boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
//     }}>
//       <span style={{ fontSize: 12, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
//         {label}
//       </span>
//       <span style={{ fontSize: 26, fontWeight: 700, color: accent || '#111827' }}>{value}</span>
//       {sub && <span style={{ fontSize: 12, color: '#9ca3af' }}>{sub}</span>}
//     </div>
//   );
// }

// function Badge({ text, color }) {
//   const colors = {
//     green: { bg: '#dcfce7', text: '#166534' },
//     blue: { bg: '#dbeafe', text: '#1e40af' },
//     orange: { bg: '#ffedd5', text: '#9a3412' },
//     gray: { bg: '#f3f4f6', text: '#374151' },
//   };
//   const c = colors[color] || colors.gray;
//   return (
//     <span style={{
//       background: c.bg, color: c.text,
//       fontSize: 11, fontWeight: 600,
//       padding: '2px 9px', borderRadius: 99,
//       display: 'inline-block',
//     }}>{text}</span>
//   );
// }

// function PaymentBar({ breakdown }) {
//   const cash = breakdown?.CASH || {};
//   const upi = breakdown?.UPI || {};
//   const total = (cash.count || 0) + (upi.count || 0);
//   const cashPct = total ? Math.round((cash.count / total) * 100) : 0;
//   const upiPct = 100 - cashPct;

//   return (
//     <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 14, padding: '20px 24px', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
//       <p style={{ fontSize: 12, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Payment Split</p>
//       <div style={{ display: 'flex', height: 10, borderRadius: 99, overflow: 'hidden', marginBottom: 16 }}>
//         <div style={{ width: `${cashPct}%`, background: '#10b981', transition: 'width .5s' }} />
//         <div style={{ width: `${upiPct}%`, background: '#6366f1' }} />
//       </div>
//       <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//         <div>
//           <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
//             <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#10b981', display: 'inline-block' }} />
//             <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>CASH</span>
//           </div>
//           <div style={{ fontSize: 18, fontWeight: 700, color: '#111827' }}>{fmt(cash.totalAmount)}</div>
//           <div style={{ fontSize: 12, color: '#9ca3af' }}>{cash.count || 0} bookings · {cashPct}%</div>
//         </div>
//         <div style={{ textAlign: 'right' }}>
//           <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4, justifyContent: 'flex-end' }}>
//             <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>UPI</span>
//             <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#6366f1', display: 'inline-block' }} />
//           </div>
//           <div style={{ fontSize: 18, fontWeight: 700, color: '#111827' }}>{fmt(upi.totalAmount)}</div>
//           <div style={{ fontSize: 12, color: '#9ca3af' }}>{upi.count || 0} bookings · {upiPct}%</div>
//         </div>
//       </div>
//     </div>
//   );
// }

// function VehicleBreakdown({ breakdown }) {
//   if (!breakdown || !Object.keys(breakdown).length) return null;
//   const icons = { TWO_WHEELER: '🛵', FOUR_WHEELER: '🚗', BUS: '🚌', TRUCK: '🚛' };

//   return (
//     <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 14, padding: '20px 24px', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
//       <p style={{ fontSize: 12, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Vehicle Types</p>
//       <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
//         {Object.entries(breakdown).map(([type, data]) => (
//           <div key={type} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
//             <span style={{ fontSize: 20 }}>{icons[type] || '🚘'}</span>
//             <div style={{ flex: 1 }}>
//               <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
//                 <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>{type.replace('_', ' ')}</span>
//                 <span style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>{fmt(data.totalAmount)}</span>
//               </div>
//               <div style={{ height: 5, background: '#f3f4f6', borderRadius: 99 }}>
//                 <div style={{ height: '100%', background: '#6366f1', borderRadius: 99, width: `${Math.min((data.count / 50) * 100, 100)}%` }} />
//               </div>
//               <span style={{ fontSize: 11, color: '#9ca3af' }}>{data.count} bookings · avg {fmt(data.averageAmount)}</span>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// function TopVehicles({ vehicles }) {
//   if (!vehicles?.length) return null;
//   return (
//     <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 14, padding: '20px 24px', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
//       <p style={{ fontSize: 12, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Top Vehicles (Frequency)</p>
//       <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
//         {vehicles.slice(0, 5).map((v, i) => (
//           <div key={v.vehicleNo} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
//             <span style={{
//               width: 24, height: 24, borderRadius: '50%', background: i === 0 ? '#fbbf24' : i === 1 ? '#9ca3af' : i === 2 ? '#d97706' : '#e5e7eb',
//               color: i < 3 ? '#fff' : '#374151', fontSize: 11, fontWeight: 700,
//               display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
//             }}>{i + 1}</span>
//             <div style={{ flex: 1 }}>
//               <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                 <span style={{ fontSize: 13, fontWeight: 600, color: '#111827', fontFamily: 'monospace' }}>{v.vehicleNo}</span>
//                 <span style={{ fontSize: 12, color: '#6b7280' }}>{v.count}x · {fmt(v.totalAmount)}</span>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// function Pagination({ pagination, onPageChange }) {
//   if (!pagination || pagination.totalPages <= 1) return null;
//   const { currentPage, totalPages, totalItems, itemsPerPage } = pagination;
//   const start = (currentPage - 1) * itemsPerPage + 1;
//   const end = Math.min(currentPage * itemsPerPage, totalItems);

//   const btnStyle = (active) => ({
//     width: 34, height: 34, borderRadius: 8,
//     border: active ? 'none' : '1px solid #e5e7eb',
//     background: active ? '#6366f1' : '#fff',
//     color: active ? '#fff' : '#374151',
//     cursor: 'pointer', fontSize: 13, fontWeight: 600,
//     display: 'flex', alignItems: 'center', justifyContent: 'center',
//   });

//   const pages = [];
//   for (let i = 1; i <= totalPages; i++) {
//     if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
//       pages.push(i);
//     } else if (pages[pages.length - 1] !== '...') {
//       pages.push('...');
//     }
//   }

//   return (
//     <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', flexWrap: 'wrap', gap: 8 }}>
//       <span style={{ fontSize: 13, color: '#6b7280' }}>
//         Showing {start}–{end} of {totalItems} bookings
//       </span>
//       <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
//         <button
//           style={{ ...btnStyle(false), opacity: !pagination.hasPrevPage ? 0.4 : 1 }}
//           disabled={!pagination.hasPrevPage}
//           onClick={() => onPageChange(currentPage - 1)}
//         >‹</button>
//         {pages.map((p, i) =>
//           p === '...'
//             ? <span key={`e${i}`} style={{ fontSize: 13, color: '#9ca3af', padding: '0 2px' }}>…</span>
//             : <button key={p} style={btnStyle(p === currentPage)} onClick={() => onPageChange(p)}>{p}</button>
//         )}
//         <button
//           style={{ ...btnStyle(false), opacity: !pagination.hasNextPage ? 0.4 : 1 }}
//           disabled={!pagination.hasNextPage}
//           onClick={() => onPageChange(currentPage + 1)}
//         >›</button>
//       </div>
//     </div>
//   );
// }

// // ─── Main Component ──────────────────────────────────────────────────────────

// export default function History() {
//   const dispatch = useDispatch();

//   const historyData = useSelector(selectVendorHistoryData);
//   const formattedData = useSelector(selectFormattedHistoryData);
//   const loading = useSelector(selectVendorHistoryLoading);
//   const error = useSelector(selectVendorHistoryError);
//   const summary = useSelector(selectHistorySummary);
//   const breakdown = useSelector(selectHistoryBreakdown);
//   const dateRange = useSelector(selectHistoryDateRange);
//   const pagination = useSelector(selectHistoryPagination);
//   const totalAmount = useSelector(selectTotalAmount);
//   const totalBookings = useSelector(selectTotalBookings);
//   const avgAmount = useSelector(selectAverageAmount);
//   const payBreakdown = useSelector(selectPaymentBreakdown);
//   const vehBreakdown = useSelector(selectVehicleBreakdown);
//   const topVehicles = useSelector(selectTopVehiclesByFrequency);

//   // Local filter state
//   const [startDate, setStart] = useState('');
//   const [endDate, setEnd] = useState('');
//   const [currentPage, setCurrentPage] = useState(1);
//   const [search, setSearch] = useState('');


//   const [history , setHistory]=useState([])
//   // const vendor_id = localStorage.getItem('vendor_id');
//   const user = JSON.parse(localStorage.getItem('user') || '{}');
//   const vendor_id = user.vendor_id;
//   const fetchHistory = async (page = 1) => {
//     try {
//       const result = await dispatch(getVendorHistory({
//         vendor_id,
//         startDate: startDate || null,
//         endDate: endDate || null,
//         page,
//         limit: 25,
//       })).unwrap();

//       console.log(result);

//       setHistory(result.data)
//       console.log('📊 Full History Response:', history);

//       setCurrentPage(page);
//     } catch (error) {
//       console.error('❌ Error fetching history:', error);
//     }
//   };
//   useEffect(() => {
//     fetchHistory(1);
//   }, [dispatch]);

//   const handleFilter = () => fetchHistory(1);

//   const handleClear = () => {
//     setStart('');
//     setEnd('');
//     dispatch(getVendorHistory({ vendor_id, startDate: null, endDate: null, page: 1, limit: 25 }));
//   };


//   const handlePageChange = (page) => fetchHistory(page);

//   // Filter table rows by search
//   const filteredData = formattedData.filter(b =>
//     !search ||
//     b.vehicleNumber?.toLowerCase().includes(search.toLowerCase()) ||
//     b.vehicleType?.toLowerCase().includes(search.toLowerCase()) ||
//     b.paymentMethod?.toLowerCase().includes(search.toLowerCase())
//   );

//   // ── Styles ────────────────────────────────────────────────────────────────

//   const container = {
//     minHeight: '100vh',
//     background: '#f9fafb',
//     padding: '24px',
//     fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
//   };

//   const card = {
//     background: '#fff',
//     border: '1px solid #e5e7eb',
//     borderRadius: 14,
//     boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
//     overflow: 'hidden',
//   };

//   const inputStyle = {
//     height: 36,
//     padding: '0 12px',
//     border: '1px solid #e5e7eb',
//     borderRadius: 8,
//     fontSize: 13,
//     color: '#374151',
//     outline: 'none',
//     background: '#fff',
//   };

//   const btnPrimary = {
//     height: 36, padding: '0 18px', borderRadius: 8,
//     background: '#6366f1', color: '#fff', border: 'none',
//     fontSize: 13, fontWeight: 600, cursor: 'pointer',
//   };

//   const btnSecondary = {
//     height: 36, padding: '0 18px', borderRadius: 8,
//     background: '#f3f4f6', color: '#374151', border: '1px solid #e5e7eb',
//     fontSize: 13, fontWeight: 600, cursor: 'pointer',
//   };

//   const thStyle = {
//     padding: '12px 16px',
//     textAlign: 'left',
//     fontSize: 11,
//     fontWeight: 700,
//     color: '#6b7280',
//     textTransform: 'uppercase',
//     letterSpacing: '0.05em',
//     background: '#f9fafb',
//     borderBottom: '1px solid #e5e7eb',
//     whiteSpace: 'nowrap',
//   };

//   const tdStyle = {
//     padding: '12px 16px',
//     fontSize: 13,
//     color: '#374151',
//     borderBottom: '1px solid #f3f4f6',
//     whiteSpace: 'nowrap',
//   };

//   return (
//     <div style={container}>

//       {/* ── Header ── */}
//       <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
//         <div>
//           <h1 style={{ fontSize: 22, fontWeight: 700, color: '#111827', margin: 0 }}>Booking History</h1>
//           {dateRange && (
//             <p style={{ fontSize: 13, color: '#6b7280', margin: '4px 0 0' }}>
//               {fmtDate(dateRange.startDate)} — {fmtDate(dateRange.endDate)}
//             </p>
//           )}
//         </div>

//         {/* ── Date Filter ── */}
//         <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
//           <input
//             type="date" value={startDate}
//             onChange={e => setStart(e.target.value)}
//             style={inputStyle}
//           />
//           <span style={{ fontSize: 13, color: '#9ca3af' }}>to</span>
//           <input
//             type="date" value={endDate}
//             onChange={e => setEnd(e.target.value)}
//             style={inputStyle}
//           />
//           <button style={btnPrimary} onClick={handleFilter}>Filter</button>
//           <button style={btnSecondary} onClick={handleClear}>Clear</button>
//         </div>
//       </div>

//       {/* ── Error ── */}
//       {error && (
//         <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 10, padding: '12px 16px', color: '#991b1b', fontSize: 13, marginBottom: 20 }}>
//           ⚠️ {error}
//         </div>
//       )}

//       {/* ── Loading ── */}
//       {loading && (
//         <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 60, color: '#6b7280', fontSize: 14 }}>
//           <div style={{
//             width: 32, height: 32, border: '3px solid #e5e7eb',
//             borderTop: '3px solid #6366f1', borderRadius: '50%',
//             animation: 'spin 0.8s linear infinite', marginRight: 12,
//           }} />
//           Loading history...
//           <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
//         </div>
//       )}

//       {!loading && (
//         <>
//           {/* ── Stat Cards ── */}
//           <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 20 }}>
//             <StatCard label="Total Revenue" value={fmt(totalAmount)} sub={`${totalBookings} bookings`} accent="#111827" />
//             <StatCard label="Total Bookings" value={totalBookings} sub="Completed & paid" accent="#6366f1" />
//             <StatCard label="Average Amount" value={fmt(avgAmount)} sub="Per booking" accent="#10b981" />
//             <StatCard label="Cash Revenue" value={fmt(payBreakdown?.CASH?.totalAmount)} sub={`${payBreakdown?.CASH?.count || 0} transactions`} accent="#f59e0b" />
//             <StatCard label="UPI Revenue" value={fmt(payBreakdown?.UPI?.totalAmount)} sub={`${payBreakdown?.UPI?.count || 0} transactions`} accent="#6366f1" />
//           </div>

//           {/* ── Charts Row ── */}
//           {summary && (
//             <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 14, marginBottom: 20 }}>
//               <PaymentBar breakdown={payBreakdown} />
//               <VehicleBreakdown breakdown={vehBreakdown} />
//               <TopVehicles vehicles={topVehicles} />
//             </div>
//           )}

//           {/* ── Table ── */}
//           {historyData.length > 0 && (
//             <div style={{ ...card }}>
//               {/* Search */}
//               <div style={{ padding: '16px 20px', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
//                 <span style={{ fontSize: 14, fontWeight: 600, color: '#111827' }}>
//                   Transactions
//                   <span style={{ marginLeft: 8, fontSize: 12, color: '#6b7280', fontWeight: 400 }}>({pagination?.totalItems || historyData.length} total)</span>
//                 </span>
//                 <input
//                   placeholder="Search vehicle, type, payment…"
//                   value={search}
//                   onChange={e => setSearch(e.target.value)}
//                   style={{ ...inputStyle, width: 240 }}
//                 />
//               </div>

//               {/* Scrollable Table */}
//               <div style={{ overflowX: 'auto' }}>
//                 <table style={{ width: '100%', borderCollapse: 'collapse' }}>
//                   <thead>
//                     <tr>
//                       <th style={thStyle}>#</th>
//                       <th style={thStyle}>Vehicle No</th>
//                       <th style={thStyle}>Type</th>
//                       <th style={thStyle}>In Time</th>
//                       <th style={thStyle}>Out Time</th>
//                       <th style={thStyle}>Duration</th>
//                       <th style={thStyle}>Amount</th>
//                       <th style={thStyle}>Advance</th>
//                       <th style={thStyle}>Payment</th>
//                       <th style={thStyle}>Created By</th>
//                       <th style={thStyle}>Date</th>
//                       <th style={thStyle}>Status</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {filteredData.map((b, i) => (
//                       <tr key={b.id} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
//                         <td style={{ ...tdStyle, color: '#9ca3af' }}>
//                           {((pagination?.currentPage || 1) - 1) * (pagination?.itemsPerPage || 25) + i + 1}
//                         </td>
//                         <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700, color: '#111827' }}>
//                           {b.vehicleNumber || '—'}
//                         </td>
//                         <td style={tdStyle}>
//                           <Badge
//                             text={b.vehicleType?.replace('_', ' ') || '—'}
//                             color={b.vehicleType === 'TWO_WHEELER' ? 'blue' : b.vehicleType === 'FOUR_WHEELER' ? 'green' : 'gray'}
//                           />
//                         </td>
//                         <td style={tdStyle}>{fmtTime(b.inTime)}</td>
//                         <td style={tdStyle}>{fmtTime(b.outTime)}</td>
//                         <td style={tdStyle}>{b.duration ? `${b.duration} min` : '—'}</td>
//                         <td style={{ ...tdStyle, fontWeight: 700, color: '#111827' }}>{fmt(b.amount)}</td>
//                         <td style={tdStyle}>{b.advance ? fmt(b.advance) : '—'}</td>
//                         <td style={tdStyle}>
//                           <Badge
//                             text={b.paymentMethod || '—'}
//                             color={b.paymentMethod === 'CASH' ? 'green' : b.paymentMethod === 'UPI' ? 'blue' : 'gray'}
//                           />
//                         </td>
//                         <td style={tdStyle}>{b.createdBy || '—'}</td>
//                         <td style={tdStyle}>{fmtDate(b.createdAt)}</td>
//                         <td style={tdStyle}>
//                           <Badge text={b.status} color={b.status === 'Completed' ? 'green' : 'orange'} />
//                         </td>
//                       </tr>
//                     ))}
//                     {filteredData.length === 0 && (
//                       <tr>
//                         <td colSpan={12} style={{ ...tdStyle, textAlign: 'center', padding: 40, color: '#9ca3af' }}>
//                           No results found
//                         </td>
//                       </tr>
//                     )}
//                   </tbody>
//                 </table>
//               </div>

//               {/* Pagination */}
//               <div style={{ padding: '0 20px' }}>
//                 <Pagination pagination={pagination} onPageChange={handlePageChange} />
//               </div>
//             </div>
//           )}

//           {/* ── Empty State ── */}
//           {!loading && historyData.length === 0 && !error && (
//             <div style={{
//               ...card,
//               padding: 60,
//               textAlign: 'center',
//               color: '#9ca3af',
//             }}>
//               <div style={{ fontSize: 48, marginBottom: 12 }}>📭</div>
//               <p style={{ fontSize: 16, fontWeight: 600, color: '#374151', margin: '0 0 6px' }}>No bookings found</p>
//               <p style={{ fontSize: 13, margin: 0 }}>Try adjusting the date range or clear filters.</p>
//             </div>
//           )}
//         </>
//       )}
//     </div>
//   );
// }

// import React, { useEffect, useState, useCallback } from 'react';
// import { useDispatch } from 'react-redux';
// import { getVendorHistory, deleteHistoryByAmount } from '../../../redux/slice/BookingHistory';

// export default function History() {
//   const dispatch = useDispatch();
//   const [historyData, setHistoryData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   // Filter states
//   const [startDate, setStartDate] = useState('');
//   const [endDate, setEndDate] = useState('');
//   const [search, setSearch] = useState('');
//   const [currentPage, setCurrentPage] = useState(1);
//   const [itemsPerPage] = useState(25);

//   // Delete Modal states
//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [deleteAmount, setDeleteAmount] = useState('');
//   const [deleteStartDate, setDeleteStartDate] = useState('');
//   const [deleteEndDate, setDeleteEndDate] = useState('');
//   const [deleting, setDeleting] = useState(false);
//   const [deleteSuccess, setDeleteSuccess] = useState(null);
//   const [deleteError, setDeleteError] = useState(null);
//   // const [vendorid, setvendorid] = useState()
//   const user = JSON.parse(localStorage.getItem('user') || '{}');
//   const vendor_id = user.vendor_id;
//   // setvendorid(vendor_id)
//   const fetchHistory = useCallback(async (page = 1) => {
//     if (!vendor_id) {
//       setError('Vendor ID not found');
//       return;
//     }

//     setLoading(true);
//     try {
//       const result = await dispatch(getVendorHistory({
//         vendor_id,
//         startDate: startDate || null,
//         endDate: endDate || null,
//         page,
//         limit: itemsPerPage,
//       })).unwrap();

//       console.log('📊 Full Response:', result);
//       setHistoryData(result);
//       setCurrentPage(page);
//     } catch (error) {
//       console.error('❌ Error:', error);
//       setError(error.message || 'Failed to fetch history');
//     } finally {
//       setLoading(false);
//     }
//   }, [dispatch, vendor_id, startDate, endDate, itemsPerPage]);

//   useEffect(() => {
//     fetchHistory(1);
//   }, [fetchHistory]);

//   // Handle filter application
//   const handleFilter = () => {
//     setCurrentPage(1);
//     fetchHistory(1);
//   };

//   // Handle clear filters
//   const handleClear = () => {
//     setStartDate('');
//     setEndDate('');
//     setSearch('');
//     setCurrentPage(1);
//     fetchHistory(1);
//   };

//   // Handle page change
//   const handlePageChange = (page) => {
//     fetchHistory(page);
//   };
// console.log(vendor_id);

// // Handle delete history
// const handleDeleteHistory = async () => {
//   if (!deleteAmount || deleteAmount <= 0) {
//     setDeleteError('Please enter a valid amount');
//     return;
//   }

//   setDeleting(true);
//   setDeleteError(null);

//   // Debug: Log the data being sent
//   const payload = {
//     vendor_id: vendor_id,
//     amount: parseFloat(deleteAmount),
//     startDate: deleteStartDate || null,
//     endDate: deleteEndDate || null,
//   };
  
//   console.log('🔍 Sending delete request with payload:', payload);
//   console.log('🔍 Vendor ID type:', typeof vendor_id);
//   console.log('🔍 Vendor ID value:', vendor_id);

//   try {
//     const result = await dispatch(deleteHistoryByAmount(payload)).unwrap();
//     console.log('Delete Result:', result);
//     setDeleteSuccess(result.message || 'History deleted successfully');

//     setTimeout(() => {
//       fetchHistory(1);
//       closeDeleteModal();
//     }, 2000);

//   } catch (error) {
//     console.error('Delete Error:', error);
//     setDeleteError(error.message || 'Failed to delete history');
//   } finally {
//     setDeleting(false);
//   }
// };

//   // Open delete modal
//   const openDeleteModal = () => {
//     setDeleteAmount('');
//     setDeleteStartDate(startDate);
//     setDeleteEndDate(endDate);
//     setDeleteSuccess(null);
//     setDeleteError(null);
//     setShowDeleteModal(true);
//   };

//   // Close delete modal
//   const closeDeleteModal = () => {
//     setShowDeleteModal(false);
//     setDeleteAmount('');
//     setDeleteSuccess(null);
//     setDeleteError(null);
//   };

//   // Format functions
//   const formatDate = (date) => {
//     return new Date(date).toLocaleDateString('en-IN', {
//       day: '2-digit',
//       month: 'short',
//       year: 'numeric'
//     });
//   };

//   const formatDateTime = (date) => {
//     if (!date) return '—';
//     return new Date(date).toLocaleString('en-IN', {
//       day: '2-digit',
//       month: 'short',
//       hour: '2-digit',
//       minute: '2-digit'
//     });
//   };

//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       maximumFractionDigits: 0
//     }).format(amount || 0);
//   };

//   // Filter data based on search (client-side filtering)
//   const getFilteredData = () => {
//     if (!historyData?.data) return [];
//     if (!search) return historyData.data;

//     return historyData.data.filter(booking =>
//       booking.vehicleNo?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.vehicleType?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.paymentMethod?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.createdBy?.name?.toLowerCase().includes(search.toLowerCase())
//     );
//   };

//   const filteredData = getFilteredData();
//   const { summary, pagination, dateRange } = historyData || {};

//   if (loading) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px' }}>
//         <div>Loading bookings...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px', color: 'red' }}>
//         <div>Error: {error}</div>
//       </div>
//     );
//   }

//   if (!historyData) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px' }}>
//         <div>No data available</div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <div style={{ padding: '24px', background: '#f9fafb', minHeight: '100vh' }}>
//         {/* Header with Filters and Delete Button */}
//         <div style={{ marginBottom: '24px' }}>
//           <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
//             <div>
//               <h1
//                 style={{
//                   fontSize: '24px',
//                   fontWeight: 'bold',
//                   margin: '0 0 8px 0',
//                   cursor: 'pointer',
//                   display: 'inline-block'
//                 }}
//                 onClick={openDeleteModal}
//               >
//                 Booking History
//               </h1>
//               {dateRange?.startDate && dateRange?.endDate && (
//                 <p style={{ color: '#6b7280', margin: '4px 0 0 0', fontSize: '13px' }}>
//                   Showing data from {formatDate(dateRange.startDate)} to {formatDate(dateRange.endDate)}
//                 </p>
//               )}
//             </div>
//           </div>

//           {/* Filters Row */}
//           <div style={{
//             display: 'flex',
//             gap: '12px',
//             flexWrap: 'wrap',
//             alignItems: 'center',
//             marginTop: '16px'
//           }}>
//             {/* Date Filters */}
//             <input
//               type="date"
//               value={startDate}
//               onChange={(e) => setStartDate(e.target.value)}
//               placeholder="Start Date"
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 outline: 'none'
//               }}
//             />
//             <span>to</span>
//             <input
//               type="date"
//               value={endDate}
//               onChange={(e) => setEndDate(e.target.value)}
//               placeholder="End Date"
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 outline: 'none'
//               }}
//             />

//             {/* Search Box */}
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search by vehicle, type, payment..."
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 width: '250px',
//                 outline: 'none'
//               }}
//             />

//             {/* Buttons */}
//             <button
//               onClick={handleFilter}
//               style={{
//                 padding: '8px 16px',
//                 background: '#6366f1',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '8px',
//                 cursor: 'pointer',
//                 fontSize: '14px',
//                 fontWeight: '500'
//               }}
//             >
//               Apply Filters
//             </button>

//             <button
//               onClick={handleClear}
//               style={{
//                 padding: '8px 16px',
//                 background: '#f3f4f6',
//                 color: '#374151',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 cursor: 'pointer',
//                 fontSize: '14px',
//                 fontWeight: '500'
//               }}
//             >
//               Clear All
//             </button>
//           </div>
//         </div>

//         {/* Summary Cards */}
//         {summary && (
//           <div style={{
//             display: 'grid',
//             gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
//             gap: '16px',
//             marginBottom: '24px'
//           }}>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Total Revenue</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(summary.totalAmount)}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>{summary.totalBookings} bookings</div>
//             </div>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Total Bookings</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{summary.totalBookings}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>Completed transactions</div>
//             </div>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Average Amount</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(summary.averageAmount)}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>Per booking</div>
//             </div>
//           </div>
//         )}

//         {/* Bookings Table */}
//         {filteredData.length > 0 ? (
//           <div style={{
//             background: 'white',
//             borderRadius: '12px',
//             boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
//             overflow: 'hidden'
//           }}>
//             <div style={{ padding: '20px', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//               <h3 style={{ margin: 0, fontSize: '16px' }}>
//                 Transactions ({filteredData.length} of {pagination?.totalItems || historyData.data?.length || 0} total)
//               </h3>
//               {search && (
//                 <span style={{ fontSize: '12px', color: '#6b7280' }}>
//                   Showing {filteredData.length} matching results
//                 </span>
//               )}
//             </div>
//             <div style={{ overflowX: 'auto' }}>
//               <table style={{ width: '100%', borderCollapse: 'collapse' }}>
//                 <thead>
//                   <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>#</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Vehicle No</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Type</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>In Time</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Out Time</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Duration</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Amount</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Advance</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Payment</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Created By</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Date</th>
//                     <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Status</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {filteredData.map((booking, index) => (
//                     <tr key={booking._id} style={{ borderBottom: '1px solid #f3f4f6' }}>
//                       <td style={{ padding: '12px 16px', fontSize: '13px', color: '#6b7280' }}>
//                         {(currentPage - 1) * itemsPerPage + index + 1}
//                       </td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: '500' }}>{booking.vehicleNo}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.vehicleType}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{formatDateTime(booking.inTime)}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.outTime ? formatDateTime(booking.outTime) : '—'}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.total_min ? `${booking.total_min} min` : '—'}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: 'bold', color: '#2c7da0' }}>
//                         {formatCurrency(booking.amount)}
//                       </td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.advance ? formatCurrency(booking.advance) : '—'}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>
//                         <span style={{
//                           background: booking.paymentMethod === 'CASH' ? '#dcfce7' : '#dbeafe',
//                           color: booking.paymentMethod === 'CASH' ? '#166534' : '#1e40af',
//                           padding: '4px 8px',
//                           borderRadius: '12px',
//                           fontSize: '11px',
//                           fontWeight: '600'
//                         }}>
//                           {booking.paymentMethod || '—'}
//                         </span>
//                       </td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.createdBy?.name || '—'}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>{formatDate(booking.createdAt)}</td>
//                       <td style={{ padding: '12px 16px', fontSize: '13px' }}>
//                         <span style={{
//                           background: booking.paymentSucsess ? '#dcfce7' : '#fed7aa',
//                           color: booking.paymentSucsess ? '#166534' : '#9a3412',
//                           padding: '4px 8px',
//                           borderRadius: '12px',
//                           fontSize: '11px',
//                           fontWeight: '600'
//                         }}>
//                           {booking.paymentSucsess ? 'Completed' : 'Pending'}
//                         </span>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>

//             {/* Pagination */}
//             {pagination && pagination.totalPages > 0 && !search && (
//               <div style={{
//                 padding: '16px 20px',
//                 borderTop: '1px solid #e5e7eb',
//                 display: 'flex',
//                 justifyContent: 'space-between',
//                 alignItems: 'center',
//                 flexWrap: 'wrap',
//                 gap: '12px'
//               }}>
//                 <div style={{ fontSize: '13px', color: '#6b7280' }}>
//                   Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, pagination.totalItems)} of {pagination.totalItems} bookings
//                 </div>
//                 <div style={{ display: 'flex', gap: '8px' }}>
//                   <button
//                     onClick={() => handlePageChange(currentPage - 1)}
//                     disabled={!pagination.hasPrevPage}
//                     style={{
//                       padding: '6px 12px',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '6px',
//                       background: 'white',
//                       cursor: pagination.hasPrevPage ? 'pointer' : 'not-allowed',
//                       opacity: pagination.hasPrevPage ? 1 : 0.5,
//                       fontSize: '13px'
//                     }}
//                   >
//                     Previous
//                   </button>
//                   <span style={{ padding: '6px 12px', fontSize: '13px', color: '#374151' }}>
//                     Page {currentPage} of {pagination.totalPages}
//                   </span>
//                   <button
//                     onClick={() => handlePageChange(currentPage + 1)}
//                     disabled={!pagination.hasNextPage}
//                     style={{
//                       padding: '6px 12px',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '6px',
//                       background: 'white',
//                       cursor: pagination.hasNextPage ? 'pointer' : 'not-allowed',
//                       opacity: pagination.hasNextPage ? 1 : 0.5,
//                       fontSize: '13px'
//                     }}
//                   >
//                     Next
//                   </button>
//                 </div>
//               </div>
//             )}
//           </div>
//         ) : (
//           <div style={{
//             background: 'white',
//             padding: '60px',
//             borderRadius: '12px',
//             textAlign: 'center',
//             color: '#9ca3af'
//           }}>
//             <div style={{ fontSize: '48px', marginBottom: '12px' }}>📭</div>
//             <p style={{ fontSize: '16px', fontWeight: '600', color: '#374151', margin: '0 0 6px' }}>
//               No bookings found
//             </p>
//             <p style={{ fontSize: '13px', margin: 0 }}>
//               {search || startDate || endDate
//                 ? 'Try adjusting your search or date filters'
//                 : 'No booking history available'}
//             </p>
//           </div>
//         )}
//       </div>

//       {/* Delete History Modal */}
//       {showDeleteModal && (
//         <div style={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           right: 0,
//           bottom: 0,
//           background: 'rgba(0, 0, 0, 0.5)',
//           display: 'flex',
//           alignItems: 'center',
//           justifyContent: 'center',
//           zIndex: 1000
//         }}>
//           <div style={{
//             background: 'white',
//             borderRadius: '12px',
//             padding: '24px',
//             width: '90%',
//             maxWidth: '500px',
//             maxHeight: '90vh',
//             overflow: 'auto'
//           }}>
//             <h2 style={{ margin: '0 0 8px 0', fontSize: '20px', fontWeight: 'bold' }}>
//               Delete Booking History
//             </h2>
//             <p style={{ color: '#6b7280', marginBottom: '20px', fontSize: '14px' }}>
//               Delete all bookings with total amount matching the specified value
//             </p>

//             {deleteSuccess ? (
//               <div style={{
//                 background: '#dcfce7',
//                 color: '#166534',
//                 padding: '12px',
//                 borderRadius: '8px',
//                 marginBottom: '20px'
//               }}>
//                 ✅ {deleteSuccess}
//               </div>
//             ) : (
//               <>
//                 {/* Amount Input */}
//                 <div style={{ marginBottom: '16px' }}>
//                   <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', fontSize: '14px' }}>
//                     Amount to Delete *
//                   </label>
//                   <input
//                     type="number"
//                     value={deleteAmount}
//                     onChange={(e) => setDeleteAmount(e.target.value)}
//                     placeholder="Enter amount (e.g., 500)"
//                     style={{
//                       width: '100%',
//                       padding: '10px',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '8px',
//                       fontSize: '14px',
//                       outline: 'none'
//                     }}
//                   />
//                 </div>

//                 {/* Date Range (Optional) */}
//                 <div style={{ marginBottom: '16px' }}>
//                   <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', fontSize: '14px' }}>
//                     Date Range (Optional)
//                   </label>
//                   <div style={{ display: 'flex', gap: '12px' }}>
//                     <input
//                       type="date"
//                       value={deleteStartDate}
//                       onChange={(e) => setDeleteStartDate(e.target.value)}
//                       style={{
//                         flex: 1,
//                         padding: '10px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '8px',
//                         fontSize: '14px',
//                         outline: 'none'
//                       }}
//                     />
//                     <span>to</span>
//                     <input
//                       type="date"
//                       value={deleteEndDate}
//                       onChange={(e) => setDeleteEndDate(e.target.value)}
//                       style={{
//                         flex: 1,
//                         padding: '10px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '8px',
//                         fontSize: '14px',
//                         outline: 'none'
//                       }}
//                     />
//                   </div>
//                   <p style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
//                     Leave empty to search across all dates
//                   </p>
//                 </div>

//                 {/* Warning Message */}
//                 <div style={{
//                   background: '#fee2e2',
//                   padding: '12px',
//                   borderRadius: '8px',
//                   marginBottom: '20px',
//                   fontSize: '13px',
//                   color: '#991b1b'
//                 }}>
//                   ⚠️ Warning: This action will permanently delete all bookings that match the exact total amount. This cannot be undone!
//                 </div>

//                 {deleteError && (
//                   <div style={{
//                     background: '#fee2e2',
//                     color: '#991b1b',
//                     padding: '12px',
//                     borderRadius: '8px',
//                     marginBottom: '16px',
//                     fontSize: '13px'
//                   }}>
//                     ❌ {deleteError}
//                   </div>
//                 )}

//                 {/* Modal Buttons */}
//                 <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
//                   <button
//                     onClick={closeDeleteModal}
//                     disabled={deleting}
//                     style={{
//                       padding: '10px 20px',
//                       background: '#f3f4f6',
//                       color: '#374151',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '8px',
//                       cursor: deleting ? 'not-allowed' : 'pointer',
//                       fontSize: '14px',
//                       fontWeight: '500'
//                     }}
//                   >
//                     Cancel
//                   </button>
//                   <button
//                     onClick={handleDeleteHistory}
//                     disabled={deleting || !deleteAmount}
//                     style={{
//                       padding: '10px 20px',
//                       background: '#ef4444',
//                       color: 'white',
//                       border: 'none',
//                       borderRadius: '8px',
//                       cursor: deleting || !deleteAmount ? 'not-allowed' : 'pointer',
//                       fontSize: '14px',
//                       fontWeight: '500',
//                       opacity: deleting || !deleteAmount ? 0.6 : 1
//                     }}
//                   >
//                     {deleting ? 'Deleting...' : 'Delete History'}
//                   </button>
//                 </div>
//               </>
//             )}

//             {deleteSuccess && (
//               <button
//                 onClick={closeDeleteModal}
//                 style={{
//                   width: '100%',
//                   padding: '10px',
//                   background: '#6366f1',
//                   color: 'white',
//                   border: 'none',
//                   borderRadius: '8px',
//                   cursor: 'pointer',
//                   fontSize: '14px',
//                   fontWeight: '500',
//                   marginTop: '12px'
//                 }}
//               >
//                 Close
//               </button>
//             )}
//           </div>
//         </div>
//       )}
//     </>
//   );
// }















// import React, { useEffect, useState, useCallback } from 'react';
// import { useDispatch } from 'react-redux';
// import { getVendorHistory, deleteHistoryByAmount, generateVendorHistoryPDF } from '../../../redux/slice/BookingHistory';

// export default function History() {
//   const dispatch = useDispatch();
//   const [historyData, setHistoryData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [pdfLoading, setPdfLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [viewMode, setViewMode] = useState('list'); // 'list' or 'card'

//   // Filter states
//   const [startDate, setStartDate] = useState('');
//   const [endDate, setEndDate] = useState('');
//   const [search, setSearch] = useState('');
//   const [currentPage, setCurrentPage] = useState(1);
//   const [itemsPerPage] = useState(25);

//   // Delete Modal states
//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [deleteAmount, setDeleteAmount] = useState('');
//   const [deleteStartDate, setDeleteStartDate] = useState('');
//   const [deleteEndDate, setDeleteEndDate] = useState('');
//   const [deleting, setDeleting] = useState(false);
//   const [deleteSuccess, setDeleteSuccess] = useState(null);
//   const [deleteError, setDeleteError] = useState(null);

//   const user = JSON.parse(localStorage.getItem('user') || '{}');
//   const vendor_id = user.vendor_id;

//   const fetchHistory = useCallback(async (page = 1) => {
//     if (!vendor_id) {
//       setError('Vendor ID not found');
//       return;
//     }

//     setLoading(true);
//     try {
//       const result = await dispatch(getVendorHistory({
//         vendor_id,
//         startDate: startDate || null,
//         endDate: endDate || null,
//         page,
//         limit: itemsPerPage,
//       })).unwrap();

//       console.log('📊 Full Response:', result);
//       setHistoryData(result);
//       setCurrentPage(page);
//     } catch (error) {
//       console.error('❌ Error:', error);
//       setError(error.message || 'Failed to fetch history');
//     } finally {
//       setLoading(false);
//     }
//   }, [dispatch, vendor_id, startDate, endDate, itemsPerPage]);

//   useEffect(() => {
//     fetchHistory(1);
//   }, [fetchHistory]);

//   // Handle filter application
//   const handleFilter = () => {
//     setCurrentPage(1);
//     fetchHistory(1);
//   };

//   // Handle clear filters
//   const handleClear = () => {
//     setStartDate('');
//     setEndDate('');
//     setSearch('');
//     setCurrentPage(1);
//     fetchHistory(1);
//   };

//   // Handle page change
//   const handlePageChange = (page) => {
//     fetchHistory(page);
//   };

//   // Handle PDF download
//   const handleDownloadPDF = async () => {
//     if (!historyData?.data || historyData.data.length === 0) {
//       setError('No data available to generate PDF');
//       setTimeout(() => setError(null), 3000);
//       return;
//     }

//     setPdfLoading(true);
//     try {
//       const result = await dispatch(generateVendorHistoryPDF({
//         vendor_id,
//         startDate: startDate || null,
//         endDate: endDate || null
//       })).unwrap();

//       const url = window.URL.createObjectURL(result);
//       const link = document.createElement('a');
//       const dateRangeStr = startDate && endDate 
//         ? `${startDate}_to_${endDate}`
//         : new Date().toISOString().slice(0, 7);
//       link.href = url;
//       link.setAttribute('download', `booking_report_${dateRangeStr}.pdf`);
//       document.body.appendChild(link);
//       link.click();
      
//       link.remove();
//       window.URL.revokeObjectURL(url);
      
//       console.log('PDF downloaded successfully');
//     } catch (error) {
//       console.error('PDF Download Error:', error);
//       setError(error || 'Failed to download PDF');
//       setTimeout(() => setError(null), 3000);
//     } finally {
//       setPdfLoading(false);
//     }
//   };

//   // Handle delete history
//   const handleDeleteHistory = async () => {
//     if (!deleteAmount || deleteAmount <= 0) {
//       setDeleteError('Please enter a valid amount');
//       return;
//     }

//     setDeleting(true);
//     setDeleteError(null);

//     const payload = {
//       vendor_id: vendor_id,
//       amount: parseFloat(deleteAmount),
//       startDate: deleteStartDate || null,
//       endDate: deleteEndDate || null,
//     };
    
//     console.log('🔍 Sending delete request with payload:', payload);

//     try {
//       const result = await dispatch(deleteHistoryByAmount(payload)).unwrap();
//       console.log('Delete Result:', result);
//       setDeleteSuccess(result.message || 'History deleted successfully');

//       setTimeout(() => {
//         fetchHistory(1);
//         closeDeleteModal();
//       }, 2000);

//     } catch (error) {
//       console.error('Delete Error:', error);
//       setDeleteError(error.message || 'Failed to delete history');
//     } finally {
//       setDeleting(false);
//     }
//   };

//   // Open delete modal
//   const openDeleteModal = () => {
//     setDeleteAmount('');
//     setDeleteStartDate(startDate);
//     setDeleteEndDate(endDate);
//     setDeleteSuccess(null);
//     setDeleteError(null);
//     setShowDeleteModal(true);
//   };

//   // Close delete modal
//   const closeDeleteModal = () => {
//     setShowDeleteModal(false);
//     setDeleteAmount('');
//     setDeleteSuccess(null);
//     setDeleteError(null);
//   };

//   // Format functions
//   const formatDate = (date) => {
//     return new Date(date).toLocaleDateString('en-IN', {
//       day: '2-digit',
//       month: 'short',
//       year: 'numeric'
//     });
//   };

//   const formatDateTime = (date) => {
//     if (!date) return '—';
//     return new Date(date).toLocaleString('en-IN', {
//       day: '2-digit',
//       month: 'short',
//       hour: '2-digit',
//       minute: '2-digit'
//     });
//   };

//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       maximumFractionDigits: 0
//     }).format(amount || 0);
//   };

//   // Filter data based on search (client-side filtering)
//   const getFilteredData = () => {
//     if (!historyData?.data) return [];
//     if (!search) return historyData.data;

//     return historyData.data.filter(booking =>
//       booking.vehicleNo?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.vehicleType?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.paymentMethod?.toLowerCase().includes(search.toLowerCase()) ||
//       booking.createdBy?.name?.toLowerCase().includes(search.toLowerCase())
//     );
//   };

//   const filteredData = getFilteredData();
//   const { summary, pagination, dateRange } = historyData || {};

//   // Get status color
//   const getStatusColor = (status) => {
//     return status === 'Completed' ? '#10b981' : '#f59e0b';
//   };

//   // Get payment method color
//   const getPaymentColor = (method) => {
//     return method === 'CASH' ? '#10b981' : '#6366f1';
//   };

//   if (loading) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px' }}>
//         <div>Loading bookings...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px', color: 'red' }}>
//         <div>Error: {error}</div>
//       </div>
//     );
//   }

//   if (!historyData) {
//     return (
//       <div style={{ textAlign: 'center', padding: '50px' }}>
//         <div>No data available</div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <div style={{ padding: '24px', background: '#f9fafb', minHeight: '100vh' }}>
//         {/* Header with Filters and Buttons */}
//         <div style={{ marginBottom: '24px' }}>
//           <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
//             <div>
//               <h1
//                 style={{
//                   fontSize: '24px',
//                   fontWeight: 'bold',
//                   margin: '0 0 8px 0',
//                   cursor: 'pointer',
//                   display: 'inline-block'
//                 }}
//                 onClick={openDeleteModal}
//               >
//                 Booking History 🗑️
//               </h1>
//               {dateRange?.startDate && dateRange?.endDate && (
//                 <p style={{ color: '#6b7280', margin: '4px 0 0 0', fontSize: '13px' }}>
//                   Showing data from {formatDate(dateRange.startDate)} to {formatDate(dateRange.endDate)}
//                 </p>
//               )}
//             </div>
            
//             <div style={{ display: 'flex', gap: '12px' }}>
//               {/* View Toggle Buttons */}
//               <div style={{
//                 display: 'flex',
//                 background: '#f3f4f6',
//                 borderRadius: '8px',
//                 padding: '2px'
//               }}>
//                 <button
//                   onClick={() => setViewMode('list')}
//                   style={{
//                     padding: '8px 16px',
//                     background: viewMode === 'list' ? '#6366f1' : 'transparent',
//                     color: viewMode === 'list' ? 'white' : '#374151',
//                     border: 'none',
//                     borderRadius: '6px',
//                     cursor: 'pointer',
//                     fontSize: '14px',
//                     fontWeight: '500',
//                     transition: 'all 0.2s'
//                   }}
//                 >
//                   📋 List View
//                 </button>
//                 <button
//                   onClick={() => setViewMode('card')}
//                   style={{
//                     padding: '8px 16px',
//                     background: viewMode === 'card' ? '#6366f1' : 'transparent',
//                     color: viewMode === 'card' ? 'white' : '#374151',
//                     border: 'none',
//                     borderRadius: '6px',
//                     cursor: 'pointer',
//                     fontSize: '14px',
//                     fontWeight: '500',
//                     transition: 'all 0.2s'
//                   }}
//                 >
//                   🃏 Card View
//                 </button>
//               </div>

//               {/* PDF Download Button */}
//               <button
//                 onClick={handleDownloadPDF}
//                 disabled={pdfLoading || !historyData?.data?.length}
//                 style={{
//                   padding: '8px 16px',
//                   background: pdfLoading ? '#9ca3af' : '#10b981',
//                   color: 'white',
//                   border: 'none',
//                   borderRadius: '8px',
//                   cursor: pdfLoading || !historyData?.data?.length ? 'not-allowed' : 'pointer',
//                   fontSize: '14px',
//                   fontWeight: '500',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '8px',
//                   opacity: pdfLoading || !historyData?.data?.length ? 0.6 : 1
//                 }}
//               >
//                 {pdfLoading ? '⏳ Generating PDF...' : '📄 Download PDF'}
//               </button>
//             </div>
//           </div>

//           {/* Filters Row */}
//           <div style={{
//             display: 'flex',
//             gap: '12px',
//             flexWrap: 'wrap',
//             alignItems: 'center',
//             marginTop: '16px'
//           }}>
//             {/* Date Filters */}
//             <input
//               type="date"
//               value={startDate}
//               onChange={(e) => setStartDate(e.target.value)}
//               placeholder="Start Date"
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 outline: 'none'
//               }}
//             />
//             <span>to</span>
//             <input
//               type="date"
//               value={endDate}
//               onChange={(e) => setEndDate(e.target.value)}
//               placeholder="End Date"
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 outline: 'none'
//               }}
//             />

//             {/* Search Box */}
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search by vehicle, type, payment..."
//               style={{
//                 padding: '8px 12px',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 fontSize: '14px',
//                 width: '250px',
//                 outline: 'none'
//               }}
//             />

//             {/* Buttons */}
//             <button
//               onClick={handleFilter}
//               style={{
//                 padding: '8px 16px',
//                 background: '#6366f1',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '8px',
//                 cursor: 'pointer',
//                 fontSize: '14px',
//                 fontWeight: '500'
//               }}
//             >
//               Apply Filters
//             </button>

//             <button
//               onClick={handleClear}
//               style={{
//                 padding: '8px 16px',
//                 background: '#f3f4f6',
//                 color: '#374151',
//                 border: '1px solid #e5e7eb',
//                 borderRadius: '8px',
//                 cursor: 'pointer',
//                 fontSize: '14px',
//                 fontWeight: '500'
//               }}
//             >
//               Clear All
//             </button>
//           </div>
//         </div>

//         {/* Summary Cards */}
//         {summary && (
//           <div style={{
//             display: 'grid',
//             gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
//             gap: '16px',
//             marginBottom: '24px'
//           }}>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Total Revenue</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(summary.totalAmount)}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>{summary.totalBookings} bookings</div>
//             </div>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Total Bookings</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{summary.totalBookings}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>Completed transactions</div>
//             </div>
//             <div style={{ background: 'white', padding: '20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>Average Amount</div>
//               <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(summary.averageAmount)}</div>
//               <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>Per booking</div>
//             </div>
//           </div>
//         )}

//         {/* Bookings Display - Toggle between List and Card View */}
//         {filteredData.length > 0 ? (
//           viewMode === 'list' ? (
//             // List View - Table
//             <div style={{
//               background: 'white',
//               borderRadius: '12px',
//               boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
//               overflow: 'hidden'
//             }}>
//               <div style={{ padding: '20px', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                 <h3 style={{ margin: 0, fontSize: '16px' }}>
//                   Transactions ({filteredData.length} of {pagination?.totalItems || historyData.data?.length || 0} total)
//                 </h3>
//                 {search && (
//                   <span style={{ fontSize: '12px', color: '#6b7280' }}>
//                     Showing {filteredData.length} matching results
//                   </span>
//                 )}
//               </div>
//               <div style={{ overflowX: 'auto' }}>
//                 <table style={{ width: '100%', borderCollapse: 'collapse' }}>
//                   <thead>
//                     <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>#</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Vehicle No</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Type</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>In Time</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Out Time</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Duration</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Amount</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Advance</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Payment</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Created By</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Date</th>
//                       <th style={{ padding: '12px 16px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#6b7280' }}>Status</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {filteredData.map((booking, index) => (
//                       <tr key={booking._id} style={{ borderBottom: '1px solid #f3f4f6' }}>
//                         <td style={{ padding: '12px 16px', fontSize: '13px', color: '#6b7280' }}>
//                           {(currentPage - 1) * itemsPerPage + index + 1}
//                         </td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: '500' }}>{booking.vehicleNo}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.vehicleType}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{formatDateTime(booking.inTime)}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.outTime ? formatDateTime(booking.outTime) : '—'}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.total_min ? `${booking.total_min} min` : '—'}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: 'bold', color: '#2c7da0' }}>
//                           {formatCurrency(booking.amount)}
//                         </td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.advance ? formatCurrency(booking.advance) : '—'}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>
//                           <span style={{
//                             background: booking.paymentMethod === 'CASH' ? '#dcfce7' : '#dbeafe',
//                             color: booking.paymentMethod === 'CASH' ? '#166534' : '#1e40af',
//                             padding: '4px 8px',
//                             borderRadius: '12px',
//                             fontSize: '11px',
//                             fontWeight: '600'
//                           }}>
//                             {booking.paymentMethod || '—'}
//                           </span>
//                         </td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{booking.createdBy?.name || '—'}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>{formatDate(booking.createdAt)}</td>
//                         <td style={{ padding: '12px 16px', fontSize: '13px' }}>
//                           <span style={{
//                             background: booking.paymentSucsess ? '#dcfce7' : '#fed7aa',
//                             color: booking.paymentSucsess ? '#166534' : '#9a3412',
//                             padding: '4px 8px',
//                             borderRadius: '12px',
//                             fontSize: '11px',
//                             fontWeight: '600'
//                           }}>
//                             {booking.paymentSucsess ? 'Completed' : 'Pending'}
//                           </span>
//                         </td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>

//               {/* Pagination */}
//               {pagination && pagination.totalPages > 0 && !search && (
//                 <div style={{
//                   padding: '16px 20px',
//                   borderTop: '1px solid #e5e7eb',
//                   display: 'flex',
//                   justifyContent: 'space-between',
//                   alignItems: 'center',
//                   flexWrap: 'wrap',
//                   gap: '12px'
//                 }}>
//                   <div style={{ fontSize: '13px', color: '#6b7280' }}>
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, pagination.totalItems)} of {pagination.totalItems} bookings
//                   </div>
//                   <div style={{ display: 'flex', gap: '8px' }}>
//                     <button
//                       onClick={() => handlePageChange(currentPage - 1)}
//                       disabled={!pagination.hasPrevPage}
//                       style={{
//                         padding: '6px 12px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '6px',
//                         background: 'white',
//                         cursor: pagination.hasPrevPage ? 'pointer' : 'not-allowed',
//                         opacity: pagination.hasPrevPage ? 1 : 0.5,
//                         fontSize: '13px'
//                       }}
//                     >
//                       Previous
//                     </button>
//                     <span style={{ padding: '6px 12px', fontSize: '13px', color: '#374151' }}>
//                       Page {currentPage} of {pagination.totalPages}
//                     </span>
//                     <button
//                       onClick={() => handlePageChange(currentPage + 1)}
//                       disabled={!pagination.hasNextPage}
//                       style={{
//                         padding: '6px 12px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '6px',
//                         background: 'white',
//                         cursor: pagination.hasNextPage ? 'pointer' : 'not-allowed',
//                         opacity: pagination.hasNextPage ? 1 : 0.5,
//                         fontSize: '13px'
//                       }}
//                     >
//                       Next
//                     </button>
//                   </div>
//                 </div>
//               )}
//             </div>
//           ) : (
//             // Card View
//             <div>
//               <div style={{ padding: '16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                 <h3 style={{ margin: 0, fontSize: '16px' }}>
//                   Transactions ({filteredData.length} of {pagination?.totalItems || historyData.data?.length || 0} total)
//                 </h3>
//                 {search && (
//                   <span style={{ fontSize: '12px', color: '#6b7280' }}>
//                     Showing {filteredData.length} matching results
//                   </span>
//                 )}
//               </div>
//               <div style={{
//                 display: 'grid',
//                 gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))',
//                 gap: '16px'
//               }}>
//                 {filteredData.map((booking, index) => (
//                   <div
//                     key={booking._id}
//                     style={{
//                       background: 'white',
//                       borderRadius: '12px',
//                       boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
//                       overflow: 'hidden',
//                       transition: 'transform 0.2s, box-shadow 0.2s',
//                       cursor: 'pointer'
//                     }}
//                     onMouseEnter={(e) => {
//                       e.currentTarget.style.transform = 'translateY(-2px)';
//                       e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
//                     }}
//                     onMouseLeave={(e) => {
//                       e.currentTarget.style.transform = 'translateY(0)';
//                       e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
//                     }}
//                   >
//                     {/* Card Header */}
//                     <div style={{
//                       padding: '16px',
//                       background: '#f9fafb',
//                       borderBottom: '1px solid #e5e7eb',
//                       display: 'flex',
//                       justifyContent: 'space-between',
//                       alignItems: 'center'
//                     }}>
//                       <div>
//                         <span style={{
//                           fontSize: '12px',
//                           color: '#6b7280'
//                         }}>
//                           #{ (currentPage - 1) * itemsPerPage + index + 1 }
//                         </span>
//                         <h3 style={{
//                           margin: '4px 0 0 0',
//                           fontSize: '18px',
//                           fontWeight: 'bold',
//                           fontFamily: 'monospace'
//                         }}>
//                           {booking.vehicleNo}
//                         </h3>
//                       </div>
//                       <div style={{
//                         padding: '4px 12px',
//                         borderRadius: '20px',
//                         background: booking.paymentSucsess ? '#dcfce7' : '#fed7aa',
//                         color: booking.paymentSucsess ? '#166534' : '#9a3412',
//                         fontSize: '12px',
//                         fontWeight: '600'
//                       }}>
//                         {booking.paymentSucsess ? '✓ Completed' : '⏳ Pending'}
//                       </div>
//                     </div>

//                     {/* Card Body */}
//                     <div style={{ padding: '16px' }}>
//                       {/* Vehicle Type */}
//                       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>Vehicle Type</span>
//                         <span style={{ fontSize: '13px', fontWeight: '500' }}>{booking.vehicleType}</span>
//                       </div>

//                       {/* Time Info */}
//                       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>In Time</span>
//                         <span style={{ fontSize: '13px' }}>{formatDateTime(booking.inTime)}</span>
//                       </div>
//                       {booking.outTime && (
//                         <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                           <span style={{ fontSize: '13px', color: '#6b7280' }}>Out Time</span>
//                           <span style={{ fontSize: '13px' }}>{formatDateTime(booking.outTime)}</span>
//                         </div>
//                       )}
//                       {booking.total_min && (
//                         <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                           <span style={{ fontSize: '13px', color: '#6b7280' }}>Duration</span>
//                           <span style={{ fontSize: '13px' }}>{booking.total_min} minutes</span>
//                         </div>
//                       )}

//                       {/* Amount */}
//                       <div style={{
//                         display: 'flex',
//                         justifyContent: 'space-between',
//                         marginBottom: '12px',
//                         paddingTop: '8px',
//                         borderTop: '1px solid #e5e7eb'
//                       }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>Amount</span>
//                         <span style={{ fontSize: '18px', fontWeight: 'bold', color: '#2c7da0' }}>
//                           {formatCurrency(booking.amount)}
//                         </span>
//                       </div>

//                       {/* Advance */}
//                       {booking.advance > 0 && (
//                         <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                           <span style={{ fontSize: '13px', color: '#6b7280' }}>Advance Paid</span>
//                           <span style={{ fontSize: '13px', fontWeight: '500', color: '#10b981' }}>
//                             {formatCurrency(booking.advance)}
//                           </span>
//                         </div>
//                       )}

//                       {/* Payment Method */}
//                       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>Payment Method</span>
//                         <span style={{
//                           padding: '2px 8px',
//                           borderRadius: '12px',
//                           background: booking.paymentMethod === 'CASH' ? '#dcfce7' : '#dbeafe',
//                           color: booking.paymentMethod === 'CASH' ? '#166534' : '#1e40af',
//                           fontSize: '11px',
//                           fontWeight: '600'
//                         }}>
//                           {booking.paymentMethod || '—'}
//                         </span>
//                       </div>

//                       {/* Created By */}
//                       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>Created By</span>
//                         <span style={{ fontSize: '13px' }}>{booking.createdBy?.name || '—'}</span>
//                       </div>

//                       {/* Date */}
//                       <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                         <span style={{ fontSize: '13px', color: '#6b7280' }}>Date</span>
//                         <span style={{ fontSize: '13px' }}>{formatDate(booking.createdAt)}</span>
//                       </div>
//                     </div>
//                   </div>
//                 ))}
//               </div>

//               {/* Pagination for Card View */}
//               {pagination && pagination.totalPages > 0 && !search && (
//                 <div style={{
//                   padding: '16px 20px',
//                   marginTop: '20px',
//                   background: 'white',
//                   borderRadius: '12px',
//                   display: 'flex',
//                   justifyContent: 'space-between',
//                   alignItems: 'center',
//                   flexWrap: 'wrap',
//                   gap: '12px'
//                 }}>
//                   <div style={{ fontSize: '13px', color: '#6b7280' }}>
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, pagination.totalItems)} of {pagination.totalItems} bookings
//                   </div>
//                   <div style={{ display: 'flex', gap: '8px' }}>
//                     <button
//                       onClick={() => handlePageChange(currentPage - 1)}
//                       disabled={!pagination.hasPrevPage}
//                       style={{
//                         padding: '6px 12px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '6px',
//                         background: 'white',
//                         cursor: pagination.hasPrevPage ? 'pointer' : 'not-allowed',
//                         opacity: pagination.hasPrevPage ? 1 : 0.5,
//                         fontSize: '13px'
//                       }}
//                     >
//                       Previous
//                     </button>
//                     <span style={{ padding: '6px 12px', fontSize: '13px', color: '#374151' }}>
//                       Page {currentPage} of {pagination.totalPages}
//                     </span>
//                     <button
//                       onClick={() => handlePageChange(currentPage + 1)}
//                       disabled={!pagination.hasNextPage}
//                       style={{
//                         padding: '6px 12px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '6px',
//                         background: 'white',
//                         cursor: pagination.hasNextPage ? 'pointer' : 'not-allowed',
//                         opacity: pagination.hasNextPage ? 1 : 0.5,
//                         fontSize: '13px'
//                       }}
//                     >
//                       Next
//                     </button>
//                   </div>
//                 </div>
//               )}
//             </div>
//           )
//         ) : (
//           <div style={{
//             background: 'white',
//             padding: '60px',
//             borderRadius: '12px',
//             textAlign: 'center',
//             color: '#9ca3af'
//           }}>
//             <div style={{ fontSize: '48px', marginBottom: '12px' }}>📭</div>
//             <p style={{ fontSize: '16px', fontWeight: '600', color: '#374151', margin: '0 0 6px' }}>
//               No bookings found
//             </p>
//             <p style={{ fontSize: '13px', margin: 0 }}>
//               {search || startDate || endDate
//                 ? 'Try adjusting your search or date filters'
//                 : 'No booking history available'}
//             </p>
//           </div>
//         )}
//       </div>

//       {/* Delete History Modal */}
//       {showDeleteModal && (
//         <div style={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           right: 0,
//           bottom: 0,
//           background: 'rgba(0, 0, 0, 0.5)',
//           display: 'flex',
//           alignItems: 'center',
//           justifyContent: 'center',
//           zIndex: 1000
//         }}>
//           <div style={{
//             background: 'white',
//             borderRadius: '12px',
//             padding: '24px',
//             width: '90%',
//             maxWidth: '500px',
//             maxHeight: '90vh',
//             overflow: 'auto'
//           }}>
//             <h2 style={{ margin: '0 0 8px 0', fontSize: '20px', fontWeight: 'bold' }}>
//               Delete Booking History
//             </h2>
//             <p style={{ color: '#6b7280', marginBottom: '20px', fontSize: '14px' }}>
//               Delete all bookings with total amount matching the specified value
//             </p>

//             {deleteSuccess ? (
//               <div style={{
//                 background: '#dcfce7',
//                 color: '#166534',
//                 padding: '12px',
//                 borderRadius: '8px',
//                 marginBottom: '20px'
//               }}>
//                 ✅ {deleteSuccess}
//               </div>
//             ) : (
//               <>
//                 {/* Amount Input */}
//                 <div style={{ marginBottom: '16px' }}>
//                   <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', fontSize: '14px' }}>
//                     Amount to Delete *
//                   </label>
//                   <input
//                     type="number"
//                     value={deleteAmount}
//                     onChange={(e) => setDeleteAmount(e.target.value)}
//                     placeholder="Enter amount (e.g., 500)"
//                     style={{
//                       width: '100%',
//                       padding: '10px',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '8px',
//                       fontSize: '14px',
//                       outline: 'none'
//                     }}
//                   />
//                 </div>

//                 {/* Date Range (Optional) */}
//                 <div style={{ marginBottom: '16px' }}>
//                   <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', fontSize: '14px' }}>
//                     Date Range (Optional)
//                   </label>
//                   <div style={{ display: 'flex', gap: '12px' }}>
//                     <input
//                       type="date"
//                       value={deleteStartDate}
//                       onChange={(e) => setDeleteStartDate(e.target.value)}
//                       style={{
//                         flex: 1,
//                         padding: '10px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '8px',
//                         fontSize: '14px',
//                         outline: 'none'
//                       }}
//                     />
//                     <span>to</span>
//                     <input
//                       type="date"
//                       value={deleteEndDate}
//                       onChange={(e) => setDeleteEndDate(e.target.value)}
//                       style={{
//                         flex: 1,
//                         padding: '10px',
//                         border: '1px solid #e5e7eb',
//                         borderRadius: '8px',
//                         fontSize: '14px',
//                         outline: 'none'
//                       }}
//                     />
//                   </div>
//                   <p style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
//                     Leave empty to search across all dates
//                   </p>
//                 </div>

//                 {/* Warning Message */}
//                 <div style={{
//                   background: '#fee2e2',
//                   padding: '12px',
//                   borderRadius: '8px',
//                   marginBottom: '20px',
//                   fontSize: '13px',
//                   color: '#991b1b'
//                 }}>
//                   ⚠️ Warning: This action will permanently delete all bookings that match the exact total amount. This cannot be undone!
//                 </div>

//                 {deleteError && (
//                   <div style={{
//                     background: '#fee2e2',
//                     color: '#991b1b',
//                     padding: '12px',
//                     borderRadius: '8px',
//                     marginBottom: '16px',
//                     fontSize: '13px'
//                   }}>
//                     ❌ {deleteError}
//                   </div>
//                 )}

//                 {/* Modal Buttons */}
//                 <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
//                   <button
//                     onClick={closeDeleteModal}
//                     disabled={deleting}
//                     style={{
//                       padding: '10px 20px',
//                       background: '#f3f4f6',
//                       color: '#374151',
//                       border: '1px solid #e5e7eb',
//                       borderRadius: '8px',
//                       cursor: deleting ? 'not-allowed' : 'pointer',
//                       fontSize: '14px',
//                       fontWeight: '500'
//                     }}
//                   >
//                     Cancel
//                   </button>
//                   <button
//                     onClick={handleDeleteHistory}
//                     disabled={deleting || !deleteAmount}
//                     style={{
//                       padding: '10px 20px',
//                       background: '#ef4444',
//                       color: 'white',
//                       border: 'none',
//                       borderRadius: '8px',
//                       cursor: deleting || !deleteAmount ? 'not-allowed' : 'pointer',
//                       fontSize: '14px',
//                       fontWeight: '500',
//                       opacity: deleting || !deleteAmount ? 0.6 : 1
//                     }}
//                   >
//                     {deleting ? 'Deleting...' : 'Delete History'}
//                   </button>
//                 </div>
//               </>
//             )}

//             {deleteSuccess && (
//               <button
//                 onClick={closeDeleteModal}
//                 style={{
//                   width: '100%',
//                   padding: '10px',
//                   background: '#6366f1',
//                   color: 'white',
//                   border: 'none',
//                   borderRadius: '8px',
//                   cursor: 'pointer',
//                   fontSize: '14px',
//                   fontWeight: '500',
//                   marginTop: '12px'
//                 }}
//               >
//                 Close
//               </button>
//             )}
//           </div>
//         </div>
//       )}
//     </>
//   );
// }
import React, { useEffect, useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { getVendorHistory, deleteHistoryByAmount, generateVendorHistoryPDF } from '../../../redux/slice/BookingHistory';
import {
  Pagination,
  PaginationItem,
  Select,
  MenuItem,
  FormControl,
  Chip,
  Tooltip,
  Alert,
  Snackbar,
} from '@mui/material';
import {
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Refresh as RefreshIcon,
  Download as DownloadIcon,
  Delete as DeleteIcon,
  ViewList as ListIcon,
  GridView as GridIcon,
  LocalParking as ParkingIcon,
  Receipt as ReceiptIcon,
  TrendingUp as TrendingUpIcon,
  Payment as PaymentIcon,
  FilterAlt as FilterIcon,
  CalendarToday as CalendarIcon,
} from '@mui/icons-material';

export default function History() {
  const dispatch = useDispatch();
  const [historyData, setHistoryData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [viewMode, setViewMode] = useState('list');
  const [showFilters, setShowFilters] = useState(false);

  // Filter states
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  // Delete Modal states
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteAmount, setDeleteAmount] = useState('');
  const [deleteStartDate, setDeleteStartDate] = useState('');
  const [deleteEndDate, setDeleteEndDate] = useState('');
  const [deleting, setDeleting] = useState(false);

  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const vendor_id = user.vendor_id;

  const showNotification = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  const fetchHistory = useCallback(async (page = 1) => {
    if (!vendor_id) {
      setError('Vendor ID not found');
      return;
    }

    setLoading(true);
    try {
      const result = await dispatch(getVendorHistory({
        vendor_id,
        startDate: startDate || null,
        endDate: endDate || null,
        page,
        limit: itemsPerPage,
      })).unwrap();

      setHistoryData(result);
      setCurrentPage(page);
    } catch (error) {
      console.error('❌ Error:', error);
      setError(error.message || 'Failed to fetch history');
      showNotification(error.message || 'Failed to fetch history', 'error');
    } finally {
      setLoading(false);
    }
  }, [dispatch, vendor_id, startDate, endDate, itemsPerPage]);

  useEffect(() => {
    fetchHistory(1);
  }, [fetchHistory]);

  const handleFilter = () => {
    setCurrentPage(1);
    fetchHistory(1);
    showNotification('Filters applied successfully', 'success');
  };

  const handleClear = () => {
    setStartDate('');
    setEndDate('');
    setSearch('');
    setCurrentPage(1);
    fetchHistory(1);
    showNotification('Filters cleared', 'info');
  };

  const handlePageChange = (event, newPage) => {
    fetchHistory(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRowsPerPageChange = (event) => {
    setItemsPerPage(parseInt(event.target.value, 10));
    setCurrentPage(1);
    fetchHistory(1);
  };

  const handleDownloadPDF = async () => {
    if (!historyData?.data || historyData.data.length === 0) {
      showNotification('No data available to generate PDF', 'warning');
      return;
    }

    setPdfLoading(true);
    try {
      const result = await dispatch(generateVendorHistoryPDF({
        vendor_id,
        startDate: startDate || null,
        endDate: endDate || null
      })).unwrap();

      const url = window.URL.createObjectURL(result);
      const link = document.createElement('a');
      const dateRangeStr = startDate && endDate 
        ? `${startDate}_to_${endDate}`
        : new Date().toISOString().slice(0, 7);
      link.href = url;
      link.setAttribute('download', `booking_report_${dateRangeStr}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      showNotification('PDF downloaded successfully', 'success');
    } catch (error) {
      console.error('PDF Download Error:', error);
      showNotification(error || 'Failed to download PDF', 'error');
    } finally {
      setPdfLoading(false);
    }
  };

  const handleDeleteHistory = async () => {
    if (!deleteAmount || deleteAmount <= 0) {
      showNotification('Please enter a valid amount', 'error');
      return;
    }

    setDeleting(true);
    const payload = {
      vendor_id: vendor_id,
      amount: parseFloat(deleteAmount),
      startDate: deleteStartDate || null,
      endDate: deleteEndDate || null,
    };

    try {
      const result = await dispatch(deleteHistoryByAmount(payload)).unwrap();
      showNotification(result.message || 'History deleted successfully', 'success');
      setTimeout(() => {
        fetchHistory(1);
        closeDeleteModal();
      }, 2000);
    } catch (error) {
      console.error('Delete Error:', error);
      showNotification(error.message || 'Failed to delete history', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const openDeleteModal = () => {
    setDeleteAmount('');
    setDeleteStartDate(startDate);
    setDeleteEndDate(endDate);
    setShowDeleteModal(true);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setDeleteAmount('');
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatDateTime = (date) => {
    if (!date) return '—';
    return new Date(date).toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount || 0);
  };

  const getFilteredData = () => {
    if (!historyData?.data) return [];
    if (!search) return historyData.data;
    return historyData.data.filter(booking =>
      booking.vehicleNo?.toLowerCase().includes(search.toLowerCase()) ||
      booking.vehicleType?.toLowerCase().includes(search.toLowerCase()) ||
      booking.paymentMethod?.toLowerCase().includes(search.toLowerCase()) ||
      booking.createdBy?.name?.toLowerCase().includes(search.toLowerCase())
    );
  };

  const filteredData = getFilteredData();
  const { summary, pagination, dateRange } = historyData || {};
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startEntry = (currentPage - 1) * itemsPerPage + 1;
  const endEntry = Math.min(currentPage * itemsPerPage, filteredData.length);

  // Helper function for avatar colors (matching ActiveBookings)
  const AVATAR_COLORS = [
    { bg: '#dbeafe', text: '#1d4ed8' },
    { bg: '#fce7f3', text: '#be185d' },
    { bg: '#d1fae5', text: '#065f46' },
    { bg: '#fef3c7', text: '#92400e' },
    { bg: '#ede9fe', text: '#5b21b6' },
    { bg: '#fee2e2', text: '#991b1b' },
  ];
  const getAvatarColor = (str) => AVATAR_COLORS[(str ? str.charCodeAt(0) : 0) % AVATAR_COLORS.length];

  // Loading
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#1a3c5e] flex items-center justify-center animate-bounce shadow-lg">
            <ReceiptIcon sx={{ fontSize: 26, color: '#fff' }} />
          </div>
          <p className="text-sm text-gray-400 animate-pulse font-medium">Loading history...</p>
        </div>
      </div>
    );
  }

  // Error
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="text-center p-8 bg-white rounded-2xl shadow border border-red-100 max-w-sm mx-4">
          <div className="w-12 h-12 mx-auto rounded-xl bg-red-50 flex items-center justify-center mb-3">
            <ClearIcon sx={{ fontSize: 26, color: '#ef4444' }} />
          </div>
          <p className="font-semibold text-gray-800">Error loading history</p>
          <p className="text-sm text-gray-400 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  if (!historyData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f1f4f8]">
        <div className="text-center p-8 bg-white rounded-2xl shadow max-w-sm mx-4">
          <p className="text-gray-600">No data available</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @media (max-width: 640px) {
          .hide-on-mobile {
            display: none;
          }
        }
      `}</style>

      <div
        className="min-h-screen bg-[#f1f4f8] px-4 py-4 sm:px-6 lg:px-8"
        style={{ animation: 'fadeIn 0.25s ease' }}
      >
        <div className="max-w-screen-xl mx-auto space-y-4 sm:space-y-5">

          {/* ── Header ── */}
          <div
            className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4"
            style={{ animation: 'fadeSlideUp 0.35s ease both' }}
          >
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-[#1a3c5e] tracking-tight leading-tight">
                Booking History
              </h1>
              {dateRange?.startDate && dateRange?.endDate && (
                <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
                  Showing data from {formatDate(dateRange.startDate)} to {formatDate(dateRange.endDate)}
                </p>
              )}
            </div>

            {/* Toolbar buttons - Responsive */}
            <div className="flex items-center gap-2">
              <Tooltip title="Delete History">
                <button
                  onClick={openDeleteModal}
                  className="p-1.5 sm:p-2 rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 transition-all shadow-sm"
                >
                  <DeleteIcon sx={{ fontSize: { xs: 18, sm: 20 } }} />
                </button>
              </Tooltip>
              
              <Tooltip title="Download Report">
                <button
                  onClick={handleDownloadPDF}
                  disabled={pdfLoading}
                  className="p-1.5 sm:p-2 rounded-xl border border-green-200 bg-green-50 text-green-600 hover:bg-green-100 transition-all shadow-sm disabled:opacity-50"
                >
                  {pdfLoading ? (
                    <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <DownloadIcon sx={{ fontSize: { xs: 18, sm: 20 } }} />
                  )}
                </button>
              </Tooltip>
              
              <Tooltip title="Refresh">
                <button 
                  onClick={() => fetchHistory(currentPage)}
                  className="p-1.5 sm:p-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-500 transition-all shadow-sm" 
                >
                  <RefreshIcon sx={{ fontSize: { xs: 18, sm: 20 } }} />
                </button>
              </Tooltip>
            </div>
          </div>

          {/* ── Summary Cards - Responsive ── */}
          {summary && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4" style={{ animation: 'fadeSlideUp 0.4s ease both' }}>
              <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 p-4 sm:p-5 shadow-sm">
                <p className="text-xs sm:text-sm text-gray-500 mb-1 sm:mb-2">Total Revenue</p>
                <p className="text-xl sm:text-2xl font-bold text-[#1a3c5e]">{formatCurrency(summary.totalAmount)}</p>
                <p className="text-xs text-gray-400 mt-1">{summary.totalBookings} bookings</p>
              </div>
              <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 p-4 sm:p-5 shadow-sm">
                <p className="text-xs sm:text-sm text-gray-500 mb-1 sm:mb-2">Total Bookings</p>
                <p className="text-xl sm:text-2xl font-bold text-[#1a3c5e]">{summary.totalBookings}</p>
                <p className="text-xs text-gray-400 mt-1">Completed transactions</p>
              </div>
              <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 p-4 sm:p-5 shadow-sm sm:col-span-2 lg:col-span-1">
                <p className="text-xs sm:text-sm text-gray-500 mb-1 sm:mb-2">Average Amount</p>
                <p className="text-xl sm:text-2xl font-bold text-[#1a3c5e]">{formatCurrency(summary.averageAmount)}</p>
                <p className="text-xs text-gray-400 mt-1">Per booking</p>
              </div>
            </div>
          )}

          {/* ── Search + controls bar - Fully Responsive ── */}
          <div
            className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm p-3 sm:p-4"
            style={{ animation: 'fadeSlideUp 0.45s ease both' }}
          >
            {/* Search Row - Mobile First */}
            <div className="relative w-full mb-3 sm:mb-0">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                <SearchIcon sx={{ fontSize: { xs: 18, sm: 19 } }} />
              </span>
              <input
                type="text"
                placeholder="Search vehicles, type, payment..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-9 py-2 sm:py-2.5 text-sm rounded-xl border border-gray-200 bg-gray-50 outline-none focus:ring-2 focus:ring-[#1a3c5e]/25 focus:border-[#1a3c5e] transition-all placeholder:text-gray-400"
              />
              {search && (
                <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors">
                  <ClearIcon sx={{ fontSize: { xs: 14, sm: 16 } }} />
                </button>
              )}
            </div>

            {/* Filters and Controls Row - Responsive Grid */}
            <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center">
              {/* Date Filters */}
              <div className="flex items-center gap-2 flex-wrap">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="flex-1 min-w-[120px] px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm rounded-xl border border-gray-200 bg-gray-50 outline-none focus:ring-2 focus:ring-[#1a3c5e]/25"
                />
                <span className="text-gray-400 text-xs sm:text-sm">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="flex-1 min-w-[120px] px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm rounded-xl border border-gray-200 bg-gray-50 outline-none focus:ring-2 focus:ring-[#1a3c5e]/25"
                />

                <button
                  onClick={handleFilter}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold rounded-xl bg-[#1a3c5e] text-white hover:bg-[#0f2a44] transition-all shadow-sm"
                >
                  Apply
                </button>

                <button
                  onClick={handleClear}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold rounded-xl border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 transition-all"
                >
                  Clear
                </button>
              </div>

              {/* Right side controls - Responsive */}
              <div className="flex items-center justify-between lg:justify-end gap-2 lg:ml-auto">
                <div className="text-xs sm:text-sm text-gray-500 px-2 hide-on-mobile">
                  {filteredData.length} total
                </div>

                <FormControl size="small" sx={{ minWidth: { xs: 90, sm: 100 } }}>
                  <Select
                    value={itemsPerPage}
                    onChange={handleRowsPerPageChange}
                    sx={{
                      fontSize: { xs: '0.75rem', sm: '0.875rem' },
                      '& .MuiSelect-select': { py: { xs: 0.5, sm: 0.75 }, px: { xs: 1, sm: 1.5 } }
                    }}
                  >
                    <MenuItem value={15}>15 / page</MenuItem>
                    <MenuItem value={25}>25 / page</MenuItem>
                    <MenuItem value={50}>50 / page</MenuItem>
                    <MenuItem value={100}>100 / page</MenuItem>
                  </Select>
                </FormControl>

                <div className="flex rounded-xl overflow-hidden border border-gray-200">
                  <button
                    onClick={() => setViewMode('list')}
                    className={`px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-1 sm:gap-2 ${
                      viewMode === 'list' ? 'bg-[#1a3c5e] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <ListIcon sx={{ fontSize: { xs: 16, sm: 18 } }} />
                    <span className="text-xs hide-on-mobile">List</span>
                  </button>
                  <button
                    onClick={() => setViewMode('card')}
                    className={`px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-1 sm:gap-2 ${
                      viewMode === 'card' ? 'bg-[#1a3c5e] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <GridIcon sx={{ fontSize: { xs: 16, sm: 18 } }} />
                    <span className="text-xs hide-on-mobile">Cards</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ── Content Section ── */}
          <div className="history-content" style={{ animation: 'fadeSlideUp 0.5s ease both' }}>

            {/* No search results */}
            {filteredData.length === 0 && search && (
              <div className="flex flex-col items-center justify-center py-12 sm:py-20 bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm text-center">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-3">
                  <SearchIcon sx={{ fontSize: { xs: 24, sm: 28 }, color: '#d1d5db' }} />
                </div>
                <p className="font-semibold text-gray-700 text-sm sm:text-base">No results for "{search}"</p>
                <p className="text-xs sm:text-sm text-gray-400 mt-1">Try a different search term</p>
                <button onClick={() => setSearch('')} className="mt-3 text-xs sm:text-sm text-[#1a3c5e] hover:underline font-semibold">
                  Clear search
                </button>
              </div>
            )}

            {/* Empty state */}
            {filteredData.length === 0 && !search && historyData?.data?.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 sm:py-24 bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm text-center">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
                  <ReceiptIcon sx={{ fontSize: { xs: 28, sm: 34 }, color: '#93c5fd' }} />
                </div>
                <p className="text-base sm:text-lg font-bold text-gray-700">No Booking History</p>
                <p className="text-xs sm:text-sm text-gray-400 mt-1">No completed bookings found</p>
              </div>
            )}

            {/* LIST VIEW */}
            {viewMode === 'list' && filteredData.length > 0 && (
              <>
                <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-100">
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">#</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">Vehicle No</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Type</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">In Time</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Out Time</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">Amount</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Payment</th>
                          <th className="px-3 sm:px-5 py-2 sm:py-3.5 text-left text-xs font-bold text-gray-400 uppercase tracking-wider hide-on-mobile">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredData.slice(startEntry - 1, endEntry).map((booking, idx) => (
                          <tr key={booking._id} className="border-b border-gray-100 hover:bg-slate-50 transition-colors duration-150">
                            <td className="px-3 sm:px-5 py-2 sm:py-4 text-xs sm:text-sm text-gray-500">{startEntry + idx}</td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4">
                              <div>
                                <p className="text-xs sm:text-sm font-semibold text-gray-900">{booking.vehicleNo}</p>
                                <p className="text-xs text-gray-400">{booking.createdBy?.name || '—'}</p>
                              </div>
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 text-xs sm:text-sm text-gray-600 hide-on-mobile">{booking.vehicleType}</td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 text-xs sm:text-sm text-gray-600 hide-on-mobile">{formatDateTime(booking.inTime)}</td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 text-xs sm:text-sm text-gray-600 hide-on-mobile">{booking.outTime ? formatDateTime(booking.outTime) : '—'}</td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4">
                              <p className="text-xs sm:text-sm font-bold text-[#1a3c5e]">{formatCurrency(booking.amount)}</p>
                              {booking.advance > 0 && (
                                <p className="text-xs text-green-600">Adv: {formatCurrency(booking.advance)}</p>
                              )}
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 hide-on-mobile">
                              <span className={`text-xs font-semibold px-2 sm:px-3 py-1 rounded-full ${
                                booking.paymentMethod === 'CASH' ? 'bg-green-100 text-green-700' : 'bg-indigo-100 text-indigo-700'
                              }`}>
                                {booking.paymentMethod || '—'}
                              </span>
                            </td>
                            <td className="px-3 sm:px-5 py-2 sm:py-4 hide-on-mobile">
                              <span className={`text-xs font-semibold px-2 sm:px-3 py-1 rounded-full ${
                                booking.paymentSucsess ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                              }`}>
                                {booking.paymentSucsess ? 'Completed' : 'Pending'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {totalPages > 1 && (
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 mt-3 sm:mt-4 pt-2 px-3 sm:px-5 py-3 sm:py-4 border-t border-gray-100">
                      <div className="text-xs sm:text-sm text-gray-500 order-2 sm:order-1">
                        Showing {startEntry} to {endEntry} of {filteredData.length} entries
                      </div>
                      <div className="order-1 sm:order-2">
                        <Pagination
                          count={totalPages}
                          page={currentPage}
                          onChange={handlePageChange}
                          color="primary"
                          size="medium"
                          siblingCount={0}
                          boundaryCount={1}
                          renderItem={(item) => (
                            <PaginationItem
                              slots={{ previous: ChevronLeftIcon, next: ChevronRightIcon }}
                              {...item}
                            />
                          )}
                          sx={{
                            '& .MuiPaginationItem-root': {
                              borderRadius: '8px',
                              fontWeight: 500,
                              fontSize: { xs: '12px', sm: '14px' },
                              padding: { xs: '4px 8px', sm: '6px 12px' },
                            },
                            '& .Mui-selected': {
                              backgroundColor: '#1a3c5e !important',
                              color: 'white',
                            },
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* CARD VIEW - Matching ActiveBookings style exactly */}
            {viewMode === 'card' && filteredData.length > 0 && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {filteredData.slice(startEntry - 1, endEntry).map((booking, idx) => {
                    const av = getAvatarColor(booking.vehicleNo);
                    const initial = booking.vehicleNo ? booking.vehicleNo[0].toUpperCase() : '?';
                    
                    return (
                      <div
                        key={booking._id}
                        className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col gap-3 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 cursor-default"
                        style={{ animation: 'fadeSlideUp 0.4s ease both', animationDelay: `${idx * 55}ms` }}
                      >
                        {/* Avatar + vehicle info */}
                        <div className="flex items-center gap-3">
                          <div
                            className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0 select-none"
                            style={{ background: av.bg, color: av.text }}
                          >
                            {initial}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-gray-900 text-sm leading-tight truncate">{booking.vehicleNo}</p>
                            <p className="text-xs text-gray-400 truncate mt-0.5">{booking.vehicleType}</p>
                          </div>
                        </div>

                        <div className="h-px bg-gray-100" />

                        {/* Status */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Status</span>
                          <span className={`inline-flex items-center text-xs font-semibold px-3 py-1 rounded-full ${
                            booking.paymentSucsess ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                          }`}>
                            {booking.paymentSucsess ? 'Completed' : 'Pending'}
                          </span>
                        </div>

                        {/* Amount */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Amount</span>
                          <span className="text-sm font-bold text-gray-900">{formatCurrency(booking.amount)}</span>
                        </div>

                        {/* Advance */}
                        {booking.advance > 0 && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Advance</span>
                            <span className="text-sm font-semibold text-green-600">{formatCurrency(booking.advance)}</span>
                          </div>
                        )}

                        {/* In Time */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">In Time</span>
                          <span className="text-sm font-semibold text-gray-700">{formatDateTime(booking.inTime)}</span>
                        </div>

                        {/* Out Time */}
                        {booking.outTime && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Out Time</span>
                            <span className="text-sm font-semibold text-gray-700">{formatDateTime(booking.outTime)}</span>
                          </div>
                        )}

                        {/* Payment Method */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Payment</span>
                          <span className={`inline-flex items-center text-xs font-semibold px-3 py-1 rounded-full ${
                            booking.paymentMethod === 'CASH' ? 'bg-green-100 text-green-700' : 'bg-indigo-100 text-indigo-700'
                          }`}>
                            {booking.paymentMethod || '—'}
                          </span>
                        </div>

                        {/* Created By */}
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Created By</span>
                          <span className="text-sm font-semibold text-gray-700">{booking.createdBy?.name || '—'}</span>
                        </div>

                        <div className="h-px bg-gray-100" />
                      </div>
                    );
                  })}
                </div>

                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 mt-5 sm:mt-6 pt-2">
                    <div className="text-xs sm:text-sm text-gray-500 order-2 sm:order-1">
                      Showing {startEntry} to {endEntry} of {filteredData.length} entries
                    </div>
                    <div className="order-1 sm:order-2">
                      <Pagination
                        count={totalPages}
                        page={currentPage}
                        onChange={handlePageChange}
                        color="primary"
                        size="medium"
                        siblingCount={0}
                        boundaryCount={1}
                        renderItem={(item) => (
                          <PaginationItem
                            slots={{ previous: ChevronLeftIcon, next: ChevronRightIcon }}
                            {...item}
                          />
                        )}
                        sx={{
                          '& .MuiPaginationItem-root': {
                            borderRadius: '8px',
                            fontWeight: 500,
                            fontSize: { xs: '12px', sm: '14px' },
                            padding: { xs: '4px 8px', sm: '6px 12px' },
                          },
                          '& .Mui-selected': {
                            backgroundColor: '#1a3c5e !important',
                            color: 'white',
                          },
                        }}
                      />
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Delete Modal - Responsive */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-3 sm:p-4" style={{ animation: 'fadeIn 0.2s ease' }}>
          <div className="bg-white rounded-xl sm:rounded-2xl w-full max-w-md shadow-xl mx-3 sm:mx-0">
            <div className="p-4 sm:p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-red-100 flex items-center justify-center">
                  <DeleteIcon sx={{ fontSize: { xs: 18, sm: 20 }, color: '#dc2626' }} />
                </div>
                <h2 className="text-base sm:text-lg font-bold text-gray-900">Delete History</h2>
              </div>
              
              <p className="text-xs sm:text-sm text-gray-500 mb-4 sm:mb-5">
                This action will permanently delete booking records matching the criteria below.
              </p>
              
              <div className="space-y-3 sm:space-y-4">
                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1 sm:mb-1.5">Amount *</label>
                  <input
                    type="number"
                    value={deleteAmount}
                    onChange={(e) => setDeleteAmount(e.target.value)}
                    placeholder="Enter exact amount"
                    className="w-full px-3 py-2 text-sm border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1 sm:mb-1.5">Date Range (Optional)</label>
                  <div className="flex gap-2">
                    <input
                      type="date"
                      value={deleteStartDate}
                      onChange={(e) => setDeleteStartDate(e.target.value)}
                      className="flex-1 px-2 sm:px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none text-xs sm:text-sm"
                    />
                    <span className="text-gray-400 self-center text-xs sm:text-sm">to</span>
                    <input
                      type="date"
                      value={deleteEndDate}
                      onChange={(e) => setDeleteEndDate(e.target.value)}
                      className="flex-1 px-2 sm:px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none text-xs sm:text-sm"
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-4 sm:mt-5 p-2 sm:p-3 bg-amber-50 rounded-xl border border-amber-200">
                <p className="text-xs text-amber-800">
                  ⚠️ Warning: This action is irreversible. All bookings matching the exact amount will be permanently deleted.
                </p>
              </div>
              
              <div className="flex gap-2 sm:gap-3 mt-4 sm:mt-6">
                <button
                  onClick={closeDeleteModal}
                  className="flex-1 px-3 sm:px-4 py-2 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteHistory}
                  disabled={deleting || !deleteAmount}
                  className="flex-1 px-3 sm:px-4 py-2 bg-red-600 text-white rounded-xl font-medium hover:bg-red-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  {deleting ? 'Deleting...' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert severity={snackbar.severity} sx={{ borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}